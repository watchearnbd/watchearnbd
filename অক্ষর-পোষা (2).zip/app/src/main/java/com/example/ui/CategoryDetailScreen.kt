package com.example.ui

import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.platform.LocalContext
import android.speech.tts.TextToSpeech
import java.util.Locale
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Create
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.foundation.clickable
import android.widget.Toast
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CategoryDetailScreen(
    categoryId: String,
    onNavigateBack: () -> Unit,
    onNavigateToPractice: (String) -> Unit
) {
    val context = LocalContext.current
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }
    var isTtsReady by remember { mutableStateOf(false) }
    
    DisposableEffect(context) {
        var textToSpeech: TextToSpeech? = null
        textToSpeech = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val localeBn = Locale("bn", "BD")
                val result = textToSpeech?.setLanguage(localeBn) ?: TextToSpeech.LANG_NOT_SUPPORTED
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    textToSpeech?.language = Locale.ENGLISH
                }
                textToSpeech?.setPitch(1.8f)
                textToSpeech?.setSpeechRate(0.7f)
                isTtsReady = true
            } else {
                Toast.makeText(context, "TTS Initialization failed", Toast.LENGTH_SHORT).show()
            }
        }
        tts = textToSpeech
        onDispose {
            textToSpeech?.stop()
            textToSpeech?.shutdown()
        }
    }
    val (title, itemsList) = when (categoryId) {
        "vowels" -> "বাংলা স্বরবর্ণ" to listOf("অ", "আ", "ই", "ঈ", "উ", "ঊ", "ঋ", "এ", "ঐ", "ও", "ঔ")
        "consonants" -> "বাংলা ব্যঞ্জনবর্ণ" to listOf("ক", "খ", "গ", "ঘ", "ঙ", "চ", "ছ", "জ", "ঝ", "ঞ", "ট", "ঠ", "ড", "ঢ", "ণ", "ত", "থ", "দ", "ধ", "ন", "প", "ফ", "ব", "ভ", "ম", "য", "র", "ল", "শ", "ষ", "স", "হ", "ড়", "ঢ়", "য়", "ৎ", "ং", "ঃ", "ঁ")
        "english_cap" -> "ইংরেজি বড় হাতের অক্ষর" to ('A'..'Z').map { it.toString() }
        "english_small" -> "ইংরেজি ছোট হাতের অক্ষর" to ('a'..'z').map { it.toString() }
        "numbers" -> "সংখ্যা শিখি" to (1..100).map { convertToBengaliNumber(it) }
        else -> "শেখার বিষয়" to listOf()
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    titleContentColor = MaterialTheme.colorScheme.onBackground
                ),
                title = { Text(title, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = MaterialTheme.colorScheme.primary)
                    }
                }
            )
        }
    ) { paddingValues ->
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(vertical = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(itemsList) { itemStr ->
                LetterTile(
                    letter = itemStr,
                    isTtsReady = isTtsReady,
                    onPractice = { onNavigateToPractice(itemStr) },
                    onSpeak = {
                        if (isTtsReady) {
                            val spokenText = getSpokenName(itemStr)
                            tts?.speak(spokenText, TextToSpeech.QUEUE_FLUSH, null, null)
                        } else {
                            Toast.makeText(context, "ভয়েস সেটআপ হচ্ছে...", Toast.LENGTH_SHORT).show()
                        }
                    }
                )
            }
        }
    }
}

@Composable
fun LetterTile(
    letter: String,
    isTtsReady: Boolean,
    onPractice: () -> Unit,
    onSpeak: () -> Unit
) {
    val details = getLetterDetails(letter)
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(0.7f)
            .clickable { onSpeak() },
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(2.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = letter,
                    fontSize = 80.sp,
                    fontWeight = FontWeight.Black,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(text = details.emoji, fontSize = 48.sp)
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = details.bnName,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = androidx.compose.ui.graphics.Color(0xFF4CAF50)
                )
                if (details.enName != null) {
                    Text(
                        text = details.enName,
                        fontSize = 16.sp,
                        color = androidx.compose.ui.graphics.Color.Gray
                    )
                }
            }
            
            // Actions Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.primaryContainer)
                    .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                IconButton(onClick = onSpeak) {
                    Icon(
                        imageVector = if (isTtsReady) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                        contentDescription = "শুনুন",
                        tint = if (isTtsReady) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                        modifier = Modifier.size(32.dp)
                    )
                }
                IconButton(onClick = onPractice) {
                    Icon(
                        imageVector = Icons.Default.Create,
                        contentDescription = "লিখুন",
                        tint = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.size(32.dp)
                    )
                }
            }
        }
    }
}

data class LetterDetails(val emoji: String, val bnName: String, val enName: String? = null)

fun getLetterDetails(letter: String): LetterDetails {
    return when (letter) {
        // English Capitals
        "A" -> LetterDetails("🍎", "আপেল", "Apple")
        "B" -> LetterDetails("⚽", "বল", "Ball")
        "C" -> LetterDetails("🐱", "বিড়াল", "Cat")
        "D" -> LetterDetails("🐶", "কুকুর", "Dog")
        "E" -> LetterDetails("🐘", "হাতি", "Elephant")
        "F" -> LetterDetails("🐟", "মাছ", "Fish")
        "G" -> LetterDetails("🍇", "আঙুর", "Grapes")
        "H" -> LetterDetails("🏠", "বাড়ি", "House")
        "I" -> LetterDetails("🍦", "আইসক্রিম", "Ice cream")
        "J" -> LetterDetails("🤹", "জাদু", "Juggle")
        "K" -> LetterDetails("🪁", "ঘুড়ি", "Kite")
        "L" -> LetterDetails("🦁", "সিংহ", "Lion")
        "M" -> LetterDetails("🌙", "চাঁদ", "Moon")
        "N" -> LetterDetails("📓", "খাতা", "Notebook")
        "O" -> LetterDetails("🍊", "কমলা", "Orange")
        "P" -> LetterDetails("🐧", "পেঙ্গুইন", "Penguin")
        "Q" -> LetterDetails("👸", "রানি", "Queen")
        "R" -> LetterDetails("🌹", "গোলাপ", "Rose")
        "S" -> LetterDetails("☀️", "সূর্য", "Sun")
        "T" -> LetterDetails("🐯", "বাঘ", "Tiger")
        "U" -> LetterDetails("☂️", "ছাতা", "Umbrella")
        "V" -> LetterDetails("🎻", "বেহালা", "Violin")
        "W" -> LetterDetails("🐋", "তিমি", "Whale")
        "X" -> LetterDetails("🎸", "জাইলোফোন", "Xylophone")
        "Y" -> LetterDetails("🪀", "ইয়ো-ইয়ো", "Yo-yo")
        "Z" -> LetterDetails("🦓", "জেব্রা", "Zebra")

        // Bengali Vowels
        "অ" -> LetterDetails("🦆", "অজগর", null)
        "আ" -> LetterDetails("🥭", "আম", null)
        "ই" -> LetterDetails("🐭", "ইঁদুর", null)
        "ঈ" -> LetterDetails("🦅", "ঈগল", null)
        "উ" -> LetterDetails("🐪", "উট", null)
        "ঊ" -> LetterDetails("🌊", "ঊর্মি", null)
        "ঋ" -> LetterDetails("🐻", "ঋক্ষ", null)
        "এ" -> LetterDetails("✏️", "এক", null)
        "ঐ" -> LetterDetails("🪞", "ঐনা", null)
        "ও" -> LetterDetails("💊", "ওষুধ", null)
        "ঔ" -> LetterDetails("🌿", "ঔষধ", null)

        // Numbers
        "১" -> LetterDetails("☝️", "এক", null)
        "২" -> LetterDetails("✌️", "দুই", null)
        "৩" -> LetterDetails("🤟", "তিন", null)
        "৪" -> LetterDetails("🖖", "চার", null)
        "৫" -> LetterDetails("🖐️", "পাঁচ", null)
        "৬" -> LetterDetails("🕕", "ছয়", null)
        "৭" -> LetterDetails("🕖", "সাত", null)
        "৮" -> LetterDetails("🕗", "আট", null)
        "৯" -> LetterDetails("🕘", "নয়", null)
        "১০" -> LetterDetails("🔟", "দশ", null)
        
        else -> LetterDetails("🌟", "শেখা", null)
    }
}

fun convertToBengaliNumber(number: Int): String {
    val englishToBengaliMap = mapOf(
        '0' to '০', '1' to '১', '2' to '২', '3' to '৩', '4' to '৪',
        '5' to '৫', '6' to '৬', '7' to '৭', '8' to '৮', '9' to '৯'
    )
    return number.toString().map { englishToBengaliMap[it] ?: it }.joinToString("")
}
