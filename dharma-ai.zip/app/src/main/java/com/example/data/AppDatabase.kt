package com.example.data

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [
        ChatSession::class, 
        ChatMessage::class, 
        SavedItem::class,
        KnowledgeEntity::class,
        UserPreferenceEntity::class,
        ReportEntity::class
    ], 
    version = 2, 
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun chatDao(): ChatDao
    abstract fun savedItemDao(): SavedItemDao
    abstract fun knowledgeDao(): KnowledgeDao
    abstract fun userPreferenceDao(): UserPreferenceDao
    abstract fun reportDao(): ReportDao
}
