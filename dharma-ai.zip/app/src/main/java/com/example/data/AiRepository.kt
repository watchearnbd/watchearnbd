package com.example.data

import com.example.engine.AiEngine
import com.example.engine.AiResponse
import com.example.engine.GeminiProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class AiRepository(private val knowledgeDao: KnowledgeDao) {
    // Modular AI Engine, currently using Gemini but can be swapped
    private val aiEngine: AiEngine = GeminiProvider()

    suspend fun getChatResponse(
        history: List<ChatMessage>, 
        prompt: String,
        responseStyle: String = "Normal",
        isKidsMode: Boolean = false
    ): AiResponse = withContext(Dispatchers.IO) {
        
        // 1. Question Analysis & Keyword Semantic Search
        val contextEnrichedPrompt = enrichPromptWithKnowledgeBase(prompt)
        
        // 2. AI Answer Generation via AiEngine
        val aiResponse = aiEngine.generateResponse(contextEnrichedPrompt, history, responseStyle, isKidsMode)
        
        // 3. Source Validation & Formatting
        aiResponse
    }

    suspend fun analyzeImage(imageUri: String, prompt: String): AiResponse {
        return aiEngine.analyzeImage(imageUri, prompt)
    }

    private suspend fun enrichPromptWithKnowledgeBase(prompt: String): String {
        // Query the local Room Database (KnowledgeEntity)
        val retrievedKnowledge = knowledgeDao.searchKnowledge(prompt)
        if (retrievedKnowledge.isNotEmpty()) {
            val contextText = retrievedKnowledge.take(3).joinToString("\n") { 
                "Source: ${it.source ?: "Unknown"} - ${it.title}\nContent: ${it.content}" 
            }
            return "Context from Dharma Knowledge Base:\n$contextText\n\nUser Question: $prompt\n\nEnsure to base your answer accurately on the provided context if relevant."
        }
        return prompt
    }
}
