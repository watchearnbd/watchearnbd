package com.example.data

import android.content.Context
import androidx.room.Room

object AppContainer {
    private var _database: AppDatabase? = null
    
    val database: AppDatabase
        get() = _database ?: throw IllegalStateException("Database not initialized")

    fun getDatabase(context: Context): AppDatabase {
        if (_database == null) {
            _database = Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                "dharma_database"
            )
            .fallbackToDestructiveMigration(dropAllTables = true)
            .build()
        }
        return _database!!
    }

    val aiRepository by lazy { AiRepository(database.knowledgeDao()) }
}
