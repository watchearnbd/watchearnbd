package com.example.ui.puja

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PujaGuideDetailScreen(guideName: String, onBack: () -> Unit, onAskAi: (String) -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(guideName, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { onAskAi("$guideName এর সম্পূর্ণ বিধি সম্পর্কে জানতে চাই") },
                icon = { Icon(Icons.Filled.AutoAwesome, "Ask AI") },
                text = { Text("Ask AI") }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text("পরিচিতি", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Text(
                    "$guideName - হিন্দু ধর্মাবলম্বীদের অত্যন্ত পবিত্র একটি আরাধনা।",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
            
            item {
                Text("প্রয়োজনীয় উপকরণ", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Text(
                    "• মূর্তি বা ছবি\n• ফুল, বেলপাতা, তুলসী\n• চন্দন, সিঁদুর\n• ধূপ, প্রদীপ\n• নৈবেদ্য বা প্রসাদ",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
            
            item {
                Text("প্রস্তুতি ও ধাপ", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Text(
                    "১. স্থান পবিত্র করা\n২. সংকল্প গ্রহণ\n৩. আসন শুদ্ধি\n৪. আবাহন ও পূজা\n৫. আরতি ও পুষ্পাঞ্জলি\n৬. প্রসাদ বিতরণ",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
            
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
                ) {
                    Text(
                        "গুরুত্বপূর্ণ নোট: অঞ্চল ও সম্প্রদায়ভেদে পূজার পদ্ধতি এবং মন্ত্র কিছুটা পরিবর্তিত হতে পারে। বিস্তারিত ও সঠিক মন্ত্রের জন্য একজন পুরোহিতের পরামর্শ নেওয়া ভালো।",
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }
            
            item { Spacer(modifier = Modifier.height(64.dp)) } // Space for FAB
        }
    }
}
