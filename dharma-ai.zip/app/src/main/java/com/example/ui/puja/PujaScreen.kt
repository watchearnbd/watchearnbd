package com.example.ui.puja

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R

import androidx.navigation.NavController

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PujaScreen(navController: NavController) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Puja & Festivals", fontWeight = FontWeight.Bold) }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Box(modifier = Modifier.height(160.dp)) {
                        Image(
                            painter = painterResource(id = R.drawable.img_hero_puja_1786548262497),
                            contentDescription = "Puja",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(MaterialTheme.colorScheme.scrim.copy(alpha = 0.3f))
                        )
                        Text(
                            "Upcoming Festivals",
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.onError,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(16.dp)
                        )
                    }
                }
            }

            item {
                Text("Festivals", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            }

            val festivals = listOf(
                "🪔 দীপাবলি" to "আলোর উৎসব",
                "🌺 দুর্গাপূজা" to "দেবী দুর্গার আরাধনা",
                "🐘 গণেশ চতুর্থী" to "গণেশের জন্মতিথি",
                "🎨 হোলি" to "রঙের উৎসব"
            )

            items(festivals.size) { index ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Row(
                        modifier = Modifier
                            .padding(16.dp)
                            .fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(festivals[index].first, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text(festivals[index].second, style = MaterialTheme.typography.bodyMedium)
                        }
                        Button(onClick = { navController.navigate("festival/${festivals[index].first}") }) {
                            Text("Details")
                        }
                    }
                }
            }
            
            item {
                Spacer(modifier = Modifier.height(8.dp))
                Text("Puja Guides", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            }
            
            val guides = listOf("লক্ষ্মী পূজা", "সরস্বতী পূজা", "শিব পূজা", "সাধারণ পূজা")
            items(guides.size) { index ->
                OutlinedCard(
                    modifier = Modifier.fillMaxWidth(),
                    onClick = { navController.navigate("puja_guide/${guides[index]}") }
                ) {
                    Text(
                        guides[index],
                        modifier = Modifier.padding(16.dp),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
            
            item { Spacer(modifier = Modifier.height(16.dp)) }
        }
    }
}
