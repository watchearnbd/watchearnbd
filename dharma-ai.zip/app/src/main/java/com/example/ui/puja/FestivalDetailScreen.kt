package com.example.ui.puja

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FestivalDetailScreen(festivalName: String, onBack: () -> Unit, onAskAi: (String) -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(festivalName, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { onAskAi("$festivalName সম্পর্কে আরও বিস্তারিত জানতে চাই") },
                icon = { Icon(Icons.Filled.AutoAwesome, "Ask AI") },
                text = { Text("Ask AI") }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text("পরিচিতি", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Text(
                    "এটি হিন্দু ধর্মের অন্যতম প্রধান একটি উৎসব যা অত্যন্ত ভক্তি ও আনন্দের সাথে পালিত হয়।",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
            
            item {
                Text("ধর্মীয় গুরুত্ব", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Text(
                    "এই উৎসবটি অশুভ শক্তির বিনাশ এবং শুভ শক্তির বিজয়ের প্রতীক। এই দিনে বিশেষ পূজা ও আরাধনা করা হয়।",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
            
            item {
                Text("প্রচলিত প্রথা ও আচার", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Text(
                    "• সকালে স্নান করে পবিত্র হওয়া\n• মন্দিরে বা বাড়িতে পূজার আয়োজন\n• বিশেষ প্রসাদ তৈরি ও বিতরণ\n• পরিবার ও পরিজনদের সাথে আনন্দ ভাগ করে নেওয়া",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
            
            item { Spacer(modifier = Modifier.height(64.dp)) } // Space for FAB
        }
    }
}
