package com.example.ui

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Celebration
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ui.chat.ChatScreen
import com.example.ui.dharma.DharmaScreen
import com.example.ui.home.HomeScreen
import com.example.ui.profile.ProfileScreen
import com.example.ui.puja.PujaScreen
import com.example.ui.quiz.QuizScreen
import com.example.ui.puja.FestivalDetailScreen
import com.example.ui.puja.PujaGuideDetailScreen
import androidx.navigation.NavType
import androidx.navigation.navArgument

@Composable
fun MainApp() {
    val navController = rememberNavController()

    Scaffold(
        bottomBar = {
            androidx.compose.material3.Surface(
                shadowElevation = 8.dp,
                color = androidx.compose.material3.MaterialTheme.colorScheme.surface,
                contentColor = androidx.compose.material3.MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.fillMaxWidth()
            ) {
                androidx.compose.foundation.layout.Column {
                    androidx.compose.material3.HorizontalDivider(
                        color = androidx.compose.material3.MaterialTheme.colorScheme.outline,
                        thickness = 1.dp
                    )
                    NavigationBar(
                        containerColor = androidx.compose.material3.MaterialTheme.colorScheme.surface,
                        contentColor = androidx.compose.material3.MaterialTheme.colorScheme.onSurface
                    ) {
                        val navBackStackEntry by navController.currentBackStackEntryAsState()
                        val currentDestination = navBackStackEntry?.destination

                        val items = listOf(
                            Triple("home", "Home", Icons.Filled.Home),
                            Triple("chat", "Chat", Icons.Filled.AutoAwesome),
                            Triple("dharma", "Dharma", Icons.Filled.Book),
                            Triple("puja", "Puja", Icons.Filled.Celebration),
                            Triple("profile", "Profile", Icons.Filled.Person)
                        )

                        items.forEach { (route, label, icon) ->
                            NavigationBarItem(
                                icon = { Icon(icon, contentDescription = label) },
                                label = { Text(label, style = androidx.compose.material3.MaterialTheme.typography.labelSmall) },
                                selected = currentDestination?.hierarchy?.any { it.route == route } == true,
                                onClick = {
                                    navController.navigate(route) {
                                        popUpTo(navController.graph.findStartDestination().id) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                                colors = androidx.compose.material3.NavigationBarItemDefaults.colors(
                                    selectedIconColor = androidx.compose.material3.MaterialTheme.colorScheme.primary,
                                    selectedTextColor = androidx.compose.material3.MaterialTheme.colorScheme.primary,
                                    indicatorColor = androidx.compose.ui.graphics.Color.Transparent,
                                    unselectedIconColor = androidx.compose.material3.MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f),
                                    unselectedTextColor = androidx.compose.material3.MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
                                )
                            )
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = "home",
            modifier = Modifier.padding(innerPadding)
        ) {
            composable("home") { HomeScreen(navController) }
            composable(
                route = "chat?prompt={prompt}",
                arguments = listOf(navArgument("prompt") { 
                    type = NavType.StringType
                    defaultValue = "" 
                })
            ) { backStackEntry ->
                val prompt = backStackEntry.arguments?.getString("prompt") ?: ""
                ChatScreen(initialPrompt = prompt) 
            }
            composable("dharma") { DharmaScreen() }
            composable("puja") { PujaScreen(navController) }
            composable("profile") { ProfileScreen(navController) }
            composable("saved_items") {
                com.example.ui.profile.SavedItemsScreen(onBack = { navController.navigateUp() })
            }
            composable("chat_history") {
                com.example.ui.profile.ChatHistoryScreen(
                    onBack = { navController.navigateUp() },
                    onChatSelected = { sessionId -> 
                        // Simplified: normally you'd pass session ID to chat screen
                        navController.navigate("chat")
                    }
                )
            }
            composable("admin_dashboard") {
                com.example.ui.profile.AdminDashboardScreen(onBack = { navController.navigateUp() })
            }
            composable("quiz") { 
                QuizScreen(onBack = { navController.navigateUp() }) 
            }
            composable(
                route = "festival/{name}",
                arguments = listOf(navArgument("name") { type = NavType.StringType })
            ) { backStackEntry ->
                val name = backStackEntry.arguments?.getString("name") ?: ""
                FestivalDetailScreen(
                    festivalName = name,
                    onBack = { navController.navigateUp() },
                    onAskAi = { prompt -> navController.navigate("chat") } // Simplified for now
                )
            }
            composable(
                route = "puja_guide/{name}",
                arguments = listOf(navArgument("name") { type = NavType.StringType })
            ) { backStackEntry ->
                val name = backStackEntry.arguments?.getString("name") ?: ""
                PujaGuideDetailScreen(
                    guideName = name,
                    onBack = { navController.navigateUp() },
                    onAskAi = { prompt -> navController.navigate("chat") }
                )
            }
        }
    }
}
