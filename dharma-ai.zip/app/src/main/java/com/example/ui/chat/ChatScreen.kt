package com.example.ui.chat

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.filled.ThumbDown
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.AppContainer
import com.example.data.ChatMessage
import com.example.data.SavedItem
import com.example.data.ReportEntity
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.util.Locale
import com.example.data.ChatSession

class ChatViewModel : ViewModel() {
    private val aiRepository = AppContainer.aiRepository
    private val savedItemDao = AppContainer.database.savedItemDao()
    private val reportDao = AppContainer.database.reportDao()
    private val chatDao = AppContainer.database.chatDao()

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading
    
    private var currentSessionId: Int = 0

    init {
        viewModelScope.launch {
            // Check if there are any existing sessions, otherwise create one
            val sessions = chatDao.getAllSessions().first()
            if (sessions.isEmpty()) {
                currentSessionId = chatDao.insertSession(ChatSession(title = "New Chat")).toInt()
                val welcomeMessage = ChatMessage(
                    sessionId = currentSessionId,
                    role = "model",
                    text = "নমস্কার! 🙏 আমি Dharma AI। হিন্দু ধর্ম, গীতা, পূজা, বা আধ্যাত্মিকতা সম্পর্কে আপনার যেকোনো প্রশ্ন করতে পারেন।"
                )
                chatDao.insertMessage(welcomeMessage)
            } else {
                currentSessionId = sessions.first().id
            }
            chatDao.getMessagesForSession(currentSessionId).collect { msgs ->
                _messages.value = msgs
            }
        }
    }

    fun sendMessage(text: String) {
        if (text.isBlank()) return

        val userMessage = ChatMessage(sessionId = currentSessionId, role = "user", text = text)
        _isLoading.value = true

        viewModelScope.launch {
            chatDao.insertMessage(userMessage)
            
            // Get history up to this point
            val history = _messages.value.filter { it.role != "user" || it.text == userMessage.text }
            val response = aiRepository.getChatResponse(history, text, "Normal", false)
            
            val aiMessage = ChatMessage(sessionId = currentSessionId, role = "model", text = response.text)
            chatDao.insertMessage(aiMessage)
            _isLoading.value = false
        }
    }
    
    fun saveMessage(message: ChatMessage) {
        viewModelScope.launch {
            savedItemDao.insertSavedItem(
                SavedItem(
                    type = "chat",
                    title = "AI Answer",
                    content = message.text
                )
            )
        }
    }
    
    fun reportMessage(message: ChatMessage) {
        viewModelScope.launch {
            val lastUserMsg = _messages.value.findLast { it.role == "user" }?.text ?: "Unknown"
            reportDao.insertReport(
                ReportEntity(
                    userQuestion = lastUserMsg,
                    aiAnswer = message.text,
                    reason = "User reported"
                )
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(viewModel: ChatViewModel = viewModel(), initialPrompt: String = "") {
    val messages by viewModel.messages.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()
    var inputText by remember { mutableStateOf("") }
    val context = LocalContext.current
    
    // TTS initialization
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }
    DisposableEffect(context) {
        @Suppress("DEPRECATION")
        val textToSpeech = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("bn", "BD")
            }
        }
        tts = textToSpeech
        onDispose {
            textToSpeech.stop()
            textToSpeech.shutdown()
        }
    }

    // Voice Input launcher
    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            val data = result.data
            val matches = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            if (!matches.isNullOrEmpty()) {
                inputText = matches[0]
            }
        }
    }

    LaunchedEffect(initialPrompt) {
        if (initialPrompt.isNotBlank()) {
            viewModel.sendMessage(initialPrompt)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Dharma AI", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(messages) { message ->
                    ChatBubble(
                        message = message,
                        onReadAloud = {
                            tts?.speak(message.text, TextToSpeech.QUEUE_FLUSH, null, null)
                        },
                        onCopy = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("AI Answer", message.text))
                            Toast.makeText(context, "Copied to clipboard", Toast.LENGTH_SHORT).show()
                        },
                        onShare = {
                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_TEXT, message.text)
                            }
                            context.startActivity(Intent.createChooser(shareIntent, "Share via"))
                        },
                        onSave = {
                            viewModel.saveMessage(message)
                            Toast.makeText(context, "Saved to Favorites", Toast.LENGTH_SHORT).show()
                        },
                        onReport = {
                            viewModel.reportMessage(message)
                            Toast.makeText(context, "Report submitted", Toast.LENGTH_SHORT).show()
                        }
                    )
                }
                if (isLoading) {
                    item {
                        Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.CenterStart) {
                            CircularProgressIndicator(modifier = Modifier.size(24.dp))
                        }
                    }
                }
            }

            // Input Box
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 4.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { 
                        Toast.makeText(context, "বর্তমানে ছবি বিশ্লেষণ ফিচারটি ডেভেলপমেন্ট পর্যায়ে আছে।", Toast.LENGTH_SHORT).show()
                    }) {
                        Icon(Icons.Filled.PhotoCamera, contentDescription = "Camera")
                    }
                    IconButton(onClick = {
                        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
                            putExtra(RecognizerIntent.EXTRA_PROMPT, "কথা বলুন...")
                        }
                        try {
                            speechLauncher.launch(intent)
                        } catch (e: Exception) {
                            Toast.makeText(context, "আপনার ডিভাইসে Speech Recognition সাপোর্ট নেই।", Toast.LENGTH_SHORT).show()
                        }
                    }) {
                        Icon(Icons.Filled.Mic, contentDescription = "Mic")
                    }
                    OutlinedTextField(
                        value = inputText,
                        onValueChange = { inputText = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("প্রশ্ন লিখুন...") },
                        shape = RoundedCornerShape(24.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
                        )
                    )
                    IconButton(
                        onClick = {
                            viewModel.sendMessage(inputText)
                            inputText = ""
                        },
                        enabled = inputText.isNotBlank() && !isLoading
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
    }
}

@Composable
fun ChatBubble(
    message: ChatMessage,
    onReadAloud: () -> Unit = {},
    onCopy: () -> Unit = {},
    onShare: () -> Unit = {},
    onSave: () -> Unit = {},
    onReport: () -> Unit = {}
) {
    val isUser = message.role == "user"
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        Surface(
            color = if (isUser) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondaryContainer,
            contentColor = if (isUser) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSecondaryContainer,
            shape = RoundedCornerShape(
                topStart = 16.dp,
                topEnd = 16.dp,
                bottomStart = if (isUser) 16.dp else 0.dp,
                bottomEnd = if (isUser) 0.dp else 16.dp
            ),
            modifier = Modifier.widthIn(max = 300.dp)
        ) {
            Text(
                text = message.text,
                modifier = Modifier.padding(12.dp),
                style = MaterialTheme.typography.bodyLarge
            )
        }
        
        if (!isUser) {
            Row(
                modifier = Modifier.padding(top = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                IconButton(onClick = onReadAloud, modifier = Modifier.size(24.dp)) { Icon(Icons.AutoMirrored.Filled.VolumeUp, "Read Aloud", modifier = Modifier.size(16.dp)) }
                IconButton(onClick = onCopy, modifier = Modifier.size(24.dp)) { Icon(Icons.Filled.ContentCopy, "Copy", modifier = Modifier.size(16.dp)) }
                IconButton(onClick = onShare, modifier = Modifier.size(24.dp)) { Icon(Icons.Filled.Share, "Share", modifier = Modifier.size(16.dp)) }
                IconButton(onClick = onSave, modifier = Modifier.size(24.dp)) { Icon(Icons.Filled.BookmarkBorder, "Save", modifier = Modifier.size(16.dp)) }
                IconButton(onClick = { /* TODO Helpful */ }, modifier = Modifier.size(24.dp)) { Icon(Icons.Filled.ThumbUp, "Helpful", modifier = Modifier.size(16.dp)) }
                IconButton(onClick = { /* TODO Not Helpful */ }, modifier = Modifier.size(24.dp)) { Icon(Icons.Filled.ThumbDown, "Not Helpful", modifier = Modifier.size(16.dp)) }
                IconButton(onClick = onReport, modifier = Modifier.size(24.dp)) { Icon(Icons.Filled.Warning, "Report", modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.error) }
            }
        }
    }
}

