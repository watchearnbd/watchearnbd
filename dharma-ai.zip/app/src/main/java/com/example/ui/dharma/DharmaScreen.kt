package com.example.ui.dharma

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.AppContainer
import com.example.data.KnowledgeEntity
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DharmaScreen() {
    val knowledgeDao = AppContainer.database.knowledgeDao()
    val scope = rememberCoroutineScope()
    var searchQuery by remember { mutableStateOf("") }
    var searchResults by remember { mutableStateOf<List<KnowledgeEntity>>(emptyList()) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Dharma Knowledge", fontWeight = FontWeight.Bold) }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { 
                    searchQuery = it 
                    scope.launch {
                        if (it.length > 2) {
                            searchResults = knowledgeDao.searchKnowledge(it)
                        } else {
                            searchResults = emptyList()
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                placeholder = { Text("Search knowledge (e.g., কর্মযোগ)...") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = "Search") },
                shape = RoundedCornerShape(24.dp)
            )

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                if (searchQuery.length > 2) {
                    if (searchResults.isEmpty()) {
                        item {
                            Text("No results found. Tap the button below to ask Dharma AI.")
                            Spacer(modifier = Modifier.height(8.dp))
                            // Ideally, navigate to chat, but for now we keep it simple since we don't have navController here.
                            // To fix this properly, DharmaScreen needs navController.
                        }
                    } else {
                        items(searchResults) { result ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Text(result.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(result.content, style = MaterialTheme.typography.bodyMedium)
                                    if (result.source != null) {
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text("Source: ${result.source}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                                    }
                                }
                            }
                        }
                    }
                } else {
                    val categories = listOf(
                        "🕉️ Hindu Dharma" to "হিন্দু ধর্মের ইতিহাস, দর্শন ও মৌলিক ধারণা।",
                        "📖 Bhagavad Gita" to "গীতার শিক্ষা, কর্মযোগ, জ্ঞানযোগ, ভক্তিযোগ ইত্যাদি।",
                        "📚 Vedas" to "বেদ সম্পর্কে পরিচিতি ও মৌলিক তথ্য।",
                        "📜 Upanishads" to "উপনিষদের দর্শন ও ধারণা।",
                        "📕 Ramayana" to "রামায়ণের চরিত্র, শিক্ষা ও গুরুত্বপূর্ণ ঘটনা।",
                        "📗 Mahabharata" to "মহাভারতের চরিত্র, শিক্ষা ও দর্শন।",
                        "🔱 Shiva" to "শিব সম্পর্কিত ধর্মীয় ধারণা ও ঐতিহ্য।",
                        "🪷 Vishnu" to "বিষ্ণু সম্পর্কিত তথ্য।",
                        "🛕 Devi" to "দেবী ও শক্তি-উপাসনা সম্পর্কিত তথ্য।",
                        "🧘 Yoga & Meditation" to "যোগ, ধ্যান ও আধ্যাত্মিক অনুশীলনের সাধারণ তথ্য।"
                    )

                    items(categories) { category ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(category.first, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(category.second, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                }
                item { Spacer(modifier = Modifier.height(16.dp)) }
            }
        }
    }
}
