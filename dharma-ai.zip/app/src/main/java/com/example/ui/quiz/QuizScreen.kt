package com.example.ui.quiz

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

data class QuizQuestion(
    val question: String,
    val options: List<String>,
    val correctIndex: Int,
    val explanation: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuizScreen(onBack: () -> Unit) {
    var currentQuestionIndex by remember { mutableStateOf(0) }
    var selectedAnswer by remember { mutableStateOf<Int?>(null) }
    var showExplanation by remember { mutableStateOf(false) }
    var score by remember { mutableStateOf(0) }
    var quizFinished by remember { mutableStateOf(false) }

    val questions = remember {
        listOf(
            QuizQuestion(
                question = "ভগবদ্গীতার জ্ঞান ভগবান শ্রীকৃষ্ণ অর্জুনকে কোথায় দিয়েছিলেন?",
                options = listOf("হস্তিনাপুরে", "কুরুক্ষেত্রের যুদ্ধক্ষেত্রে", "দ্বারকায়", "মথুরায়"),
                correctIndex = 1,
                explanation = "কুরুক্ষেত্রের যুদ্ধের ঠিক আগে যখন অর্জুন বিষাদগ্রস্ত হয়ে পড়েছিলেন, তখন ভগবান শ্রীকৃষ্ণ তাঁকে এই মহান জ্ঞান দান করেন যা ভগবদ্গীতা নামে পরিচিত।"
            ),
            QuizQuestion(
                question = "রামায়ণে রামের প্রধান অস্ত্র কী ছিল?",
                options = listOf("গদা", "তলোয়ার", "ধনুক (কোদণ্ড)", "ত্রিশূল"),
                correctIndex = 2,
                explanation = "ভগবান রামের প্রধান অস্ত্র ছিল ধনুক, যার নাম ছিল কোদণ্ড।"
            ),
            QuizQuestion(
                question = "মহাভারতে কৌরবদের মধ্যে জ্যেষ্ঠ কে ছিলেন?",
                options = listOf("দুঃশাসন", "দুর্যোধন", "বিকর্ণ", "যুযুৎসু"),
                correctIndex = 1,
                explanation = "ধৃতরাষ্ট্র ও গান্ধারীর একশত পুত্রের মধ্যে জ্যেষ্ঠ ছিলেন দুর্যোধন।"
            )
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Dharma Quiz", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        if (quizFinished) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(16.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally
            ) {
                Text("Quiz Completed!", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(16.dp))
                Text("Your Score: $score / ${questions.size}", style = MaterialTheme.typography.titleLarge)
                Spacer(modifier = Modifier.height(32.dp))
                Button(onClick = {
                    currentQuestionIndex = 0
                    score = 0
                    quizFinished = false
                    selectedAnswer = null
                    showExplanation = false
                }) {
                    Text("Restart Quiz")
                }
            }
        } else {
            val currentQuestion = questions[currentQuestionIndex]
            
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text("Question ${currentQuestionIndex + 1} of ${questions.size}", style = MaterialTheme.typography.labelLarge)
                
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Text(
                        text = currentQuestion.question,
                        style = MaterialTheme.typography.titleLarge,
                        modifier = Modifier.padding(16.dp),
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }

                currentQuestion.options.forEachIndexed { index, text ->
                    val isSelected = selectedAnswer == index
                    val isCorrect = index == currentQuestion.correctIndex
                    val backgroundColor = when {
                        !showExplanation -> if (isSelected) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface
                        isCorrect -> androidx.compose.ui.graphics.Color(0xFF4CAF50).copy(alpha = 0.2f)
                        isSelected && !isCorrect -> MaterialTheme.colorScheme.errorContainer
                        else -> MaterialTheme.colorScheme.surface
                    }

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = backgroundColor),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        onClick = {
                            if (!showExplanation) {
                                selectedAnswer = index
                            }
                        }
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = isSelected,
                                onClick = null
                            )
                            Spacer(modifier = Modifier.width(16.dp))
                            Text(text, style = MaterialTheme.typography.bodyLarge)
                        }
                    }
                }

                if (selectedAnswer != null && !showExplanation) {
                    Button(
                        onClick = { 
                            showExplanation = true
                            if (selectedAnswer == currentQuestion.correctIndex) {
                                score++
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Submit")
                    }
                }

                if (showExplanation) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                if (selectedAnswer == currentQuestion.correctIndex) "সঠিক উত্তর! 🎉" else "ভুল উত্তর।",
                                fontWeight = FontWeight.Bold,
                                color = if (selectedAnswer == currentQuestion.correctIndex) androidx.compose.ui.graphics.Color(0xFF4CAF50) else MaterialTheme.colorScheme.error
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("ব্যাখ্যা: ${currentQuestion.explanation}")
                        }
                    }
                    
                    Button(
                        onClick = { 
                            if (currentQuestionIndex < questions.size - 1) {
                                currentQuestionIndex++
                                selectedAnswer = null
                                showExplanation = false
                            } else {
                                quizFinished = true
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(if (currentQuestionIndex < questions.size - 1) "Next Question" else "View Score")
                    }
                }
            }
        }
    }
}
