package com.example.ui.profile

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(navController: NavController) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Profile & Settings", fontWeight = FontWeight.Bold) }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        Icons.Filled.Person,
                        contentDescription = "Profile",
                        modifier = Modifier.size(80.dp),
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("Devotee", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text("devotee@example.com", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            item { HorizontalDivider() }
            
            item {
                SettingsItem(icon = Icons.Filled.Language, title = "Language", subtitle = "বাংলা (Bengali)") {}
                SettingsItem(icon = Icons.Filled.DarkMode, title = "Appearance", subtitle = "System Default") {}
                SettingsItem(icon = Icons.Filled.QuestionAnswer, title = "AI Response Style", subtitle = "Detailed") {}
                SettingsItem(icon = Icons.Filled.Face, title = "Kids Mode", subtitle = "Off") {}
                SettingsItem(icon = Icons.Filled.Notifications, title = "Notifications", subtitle = "On") {}
                SettingsItem(icon = Icons.Filled.Bookmark, title = "Saved Items", subtitle = "Manage your saved items") {
                    navController.navigate("saved_items")
                }
                SettingsItem(icon = Icons.Filled.History, title = "Chat History", subtitle = "Manage your history") {
                    navController.navigate("chat_history")
                }
                SettingsItem(icon = Icons.Filled.Security, title = "Privacy", subtitle = "Data management") {}
                SettingsItem(icon = Icons.Filled.AdminPanelSettings, title = "Admin Dashboard", subtitle = "Manage Knowledge Base") {
                    navController.navigate("admin_dashboard")
                }
                SettingsItem(icon = Icons.Filled.Info, title = "About Dharma AI", subtitle = "Version 1.0.0") {}
            }
        }
    }
}

@Composable
fun SettingsItem(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = title, tint = MaterialTheme.colorScheme.primary)
        Spacer(modifier = Modifier.width(16.dp))
        Column {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Medium)
            Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
