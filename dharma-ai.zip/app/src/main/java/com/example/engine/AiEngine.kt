package com.example.engine

import com.example.data.ChatMessage

data class AiResponse(
    val text: String,
    val sourceName: String? = null,
    val sourceChapter: String? = null,
    val isVerified: Boolean = false,
    val isFallback: Boolean = false
)

interface AiEngine {
    suspend fun generateResponse(
        prompt: String, 
        history: List<ChatMessage>, 
        responseStyle: String = "Normal",
        isKidsMode: Boolean = false
    ): AiResponse
    
    suspend fun analyzeImage(
        imageUri: String, 
        prompt: String
    ): AiResponse
}
