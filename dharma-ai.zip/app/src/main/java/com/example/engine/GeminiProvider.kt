package com.example.engine

import com.example.BuildConfig
import com.example.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class GeminiProvider : AiEngine {
    private val apiKey = BuildConfig.GEMINI_API_KEY
    private val service = RetrofitClient.service

    override suspend fun generateResponse(
        prompt: String,
        history: List<ChatMessage>,
        responseStyle: String,
        isKidsMode: Boolean
    ): AiResponse = withContext(Dispatchers.IO) {
        val contents = mutableListOf<Content>()
        
        for (msg in history) {
            contents.add(
                Content(
                    role = msg.role,
                    parts = listOf(Part(text = msg.text))
                )
            )
        }
        
        contents.add(
            Content(
                role = "user",
                parts = listOf(Part(text = prompt))
            )
        )

        var systemPrompt = """
            You are Dharma AI (Hindu Dharma AI). 
            Your purpose is to answer questions about Hindu Dharma, philosophy, spirituality, scriptures, culture, festivals, and traditions in a simple, professional, and accessible language. 
            Always use a respectful and neutral tone. 
            Do not make up scriptures or verses. If you don't know, state it clearly: 'এই বিষয়ে নিশ্চিত তথ্য আমার Knowledge Base-এ পাওয়া যায়নি।'
            Provide answers in Bengali if asked in Bengali, or English if asked in English. The default language is Bengali.
            Structure your answers nicely using Markdown. Use emojis appropriately.
        """.trimIndent()

        if (isKidsMode) {
            systemPrompt += "\nKIDS MODE ENABLED: Explain things very simply, like talking to a 7-year-old child. Keep it short, safe, and educational."
        }

        systemPrompt += "\nRESPONSE STYLE: $responseStyle"

        val systemInstruction = Content(
            parts = listOf(Part(text = systemPrompt))
        )

        val request = GenerateContentRequest(
            contents = contents,
            systemInstruction = systemInstruction,
            generationConfig = GenerationConfig(
                temperature = 0.3f // Lower temperature for more factual responses
            )
        )

        try {
            val response = service.generateContent(apiKey, request)
            val responseText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text 
                ?: "কোনো উত্তর পাওয়া যায়নি।"
            
            // In a real RAG system, we would extract source info here or from the retrieval engine.
            // For now, we mock the source extraction or leave it null for the provider to just return text.
            AiResponse(
                text = responseText,
                sourceName = null, // To be populated by RAG/Knowledge layer
                isVerified = false
            )
        } catch (e: Exception) {
            android.util.Log.e("GeminiProvider", "Error generating response", e)
            AiResponse(
                text = "দুঃখিত, এই মুহূর্তে AI উত্তর তৈরি করতে পারছে না। Error: ${e.message}",
                isFallback = true
            )
        }
    }

    override suspend fun analyzeImage(imageUri: String, prompt: String): AiResponse {
        return AiResponse(
            text = "বর্তমানে ছবি বিশ্লেষণ করার ফিচারটি ডেভেলপমেন্ট পর্যায়ে আছে। দয়া করে আপনার প্রশ্নটি টেক্সট হিসেবে লিখে জানান।",
            isFallback = true
        )
    }
}
