package com.example

import android.app.Application
import com.example.data.AppContainer

class DharmaApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        AppContainer.getDatabase(this) // Initialize DB
    }
}
