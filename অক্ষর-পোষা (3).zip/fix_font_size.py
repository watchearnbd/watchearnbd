with open('./app/src/main/java/com/example/ui/CategoryDetailScreen.kt', 'r') as f:
    content = f.read()

content = content.replace("Text(text = details.emoji, fontSize = 48.sp)", "Text(text = details.emoji, fontSize = 50.sp)")
content = content.replace('text = details.bnName,\n                    fontSize = 20.sp', 'text = details.bnName,\n                    fontSize = 16.sp')

with open('./app/src/main/java/com/example/ui/CategoryDetailScreen.kt', 'w') as f:
    f.write(content)
