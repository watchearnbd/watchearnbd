with open('./app/src/main/java/com/example/ui/MainViewModel.kt', 'r') as f:
    content = f.read()

content = content.replace("val totalGamesFlowMapped = kotlinx.coroutines.flow.map(repository.totalGamesFlow) { it ?: 0 }", "val totalGamesFlowMapped = repository.totalGamesFlow.map { it ?: 0 }")
content = content.replace("val totalScoreFlowMapped = kotlinx.coroutines.flow.map(repository.totalScoreFlow) { it ?: 0 }", "val totalScoreFlowMapped = repository.totalScoreFlow.map { it ?: 0 }")

with open('./app/src/main/java/com/example/ui/MainViewModel.kt', 'w') as f:
    f.write(content)
