import re

with open('/app/applet/app/src/main/java/com/example/ui/CategoryDetailScreen.kt', 'r') as f:
    content = f.read()

# Add namata to itemsList
content = content.replace('"numbers" -> "সংখ্যা শিখি" to (1..100).map { convertToBengaliNumber(it) }', 
'''"numbers" -> "সংখ্যা শিখি" to (1..100).map { convertToBengaliNumber(it) }
        "namata" -> "নামতা শিখি" to (1..10).map { convertToBengaliNumber(it) }''')

# Change GridCells
content = content.replace('columns = GridCells.Fixed(2),', 'columns = GridCells.Fixed(if (categoryId == "namata") 1 else 2),')

# Change item renderer
item_renderer = """
            items(itemsList) { itemStr ->
                if (categoryId == "namata") {
                    NamataTile(
                        numberStr = itemStr,
                        isTtsReady = isTtsReady,
                        onSpeak = {
                            if (isTtsReady) {
                                val namataText = getNamataSpokenText(itemStr)
                                val parts = namataText.split("।").filter { it.isNotBlank() }
                                if (parts.isNotEmpty()) {
                                    tts?.speak(parts[0], TextToSpeech.QUEUE_FLUSH, null, null)
                                    for (i in 1 until parts.size) {
                                        tts?.speak(parts[i], TextToSpeech.QUEUE_ADD, null, null)
                                    }
                                }
                            } else {
                                Toast.makeText(context, "ভয়েস সেটআপ হচ্ছে...", Toast.LENGTH_SHORT).show()
                            }
                        }
                    )
                } else {
                    LetterTile(
                        letter = itemStr,
                        isTtsReady = isTtsReady,
                        onPractice = { onNavigateToPractice(itemStr) },
                        onSpeak = {
                            if (isTtsReady) {
                                val spokenText = getSpokenName(itemStr)
                                val parts = spokenText.split("।").filter { it.isNotBlank() }
                                if (parts.isNotEmpty()) {
                                    tts?.speak(parts[0], TextToSpeech.QUEUE_FLUSH, null, null)
                                    for (i in 1 until parts.size) {
                                        tts?.speak(parts[i], TextToSpeech.QUEUE_ADD, null, null)
                                    }
                                }
                            } else {
                                Toast.makeText(context, "ভয়েস সেটআপ হচ্ছে...", Toast.LENGTH_SHORT).show()
                            }
                        }
                    )
                }
            }
"""

content = re.sub(r'items\(itemsList\) \{ itemStr ->.*?\}\n\s*\}\n\s*\}\n\s*\}', item_renderer.strip() + '\n        }\n    }\n}', content, flags=re.DOTALL)

with open('/app/applet/app/src/main/java/com/example/ui/CategoryDetailScreen.kt', 'w') as f:
    f.write(content)
