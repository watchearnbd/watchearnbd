with open('./app/src/main/java/com/example/ui/CategoryDetailScreen.kt', 'r') as f:
    content = f.read()

new_speak = """                            val spokenText = getSpokenName(itemStr)
                            val parts = spokenText.split("।").filter { it.isNotBlank() }
                            if (parts.isNotEmpty()) {
                                tts?.speak(parts[0], TextToSpeech.QUEUE_FLUSH, null, null)
                                for (i in 1 until parts.size) {
                                    tts?.speak(parts[i], TextToSpeech.QUEUE_ADD, null, null)
                                }
                            }"""

content = content.replace("                            val spokenText = getSpokenName(itemStr)\n                            tts?.speak(spokenText, TextToSpeech.QUEUE_FLUSH, null, null)", new_speak)

with open('./app/src/main/java/com/example/ui/CategoryDetailScreen.kt', 'w') as f:
    f.write(content)
