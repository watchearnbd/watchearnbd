import re

with open('/app/applet/app/src/main/java/com/example/ui/CategoryDetailScreen.kt', 'r') as f:
    content = f.read()

# Replace columns = GridCells.Fixed(...) with columns = GridCells.Fixed(2)
content = re.sub(
    r'columns = GridCells\.Fixed\(if \(categoryId == "namata"\) 1 else 2\),',
    'columns = GridCells.Fixed(2),',
    content
)

# Replace the items(itemsList) logic
old_items_logic = """
            items(itemsList) { itemStr ->
                if (categoryId == "namata") {
                    NamataTile(
                        numberStr = itemStr,
                        isTtsReady = isTtsReady,
                        onSpeak = {
                            if (isTtsReady) {
                                val namataText = getNamataSpokenText(itemStr)
                                val parts = namataText.split("।").filter { it.isNotBlank() }
                                if (parts.isNotEmpty()) {
                                    tts?.speak(parts[0], TextToSpeech.QUEUE_FLUSH, null, null)
                                    for (i in 1 until parts.size) {
                                        tts?.speak(parts[i], TextToSpeech.QUEUE_ADD, null, null)
                                    }
                                }
                            } else {
                                Toast.makeText(context, "ভয়েস সেটআপ হচ্ছে...", Toast.LENGTH_SHORT).show()
                            }
                        }
                    )
                } else {
                    LetterTile(
                        letter = itemStr,
                        isTtsReady = isTtsReady,
                        onPractice = { onNavigateToPractice(itemStr) },
                        onSpeak = {
                            if (isTtsReady) {
                                val spokenText = getSpokenName(itemStr)
                                val parts = spokenText.split("।").filter { it.isNotBlank() }
                                if (parts.isNotEmpty()) {
                                    tts?.speak(parts[0], TextToSpeech.QUEUE_FLUSH, null, null)
                                    for (i in 1 until parts.size) {
                                        tts?.speak(parts[i], TextToSpeech.QUEUE_ADD, null, null)
                                    }
                                }
                            } else {
                                Toast.makeText(context, "ভয়েস সেটআপ হচ্ছে...", Toast.LENGTH_SHORT).show()
                            }
                        }
                    )
                }
            }
"""

new_items_logic = """
            items(itemsList) { itemStr ->
                if (categoryId == "namata") {
                    NamataFolderTile(
                        numberStr = itemStr,
                        onClick = { onNavigateToPractice("namata_$itemStr") }
                    )
                } else {
                    LetterTile(
                        letter = itemStr,
                        isTtsReady = isTtsReady,
                        onPractice = { onNavigateToPractice(itemStr) },
                        onSpeak = {
                            if (isTtsReady) {
                                val spokenText = getSpokenName(itemStr)
                                val parts = spokenText.split("।").filter { it.isNotBlank() }
                                if (parts.isNotEmpty()) {
                                    tts?.speak(parts[0], TextToSpeech.QUEUE_FLUSH, null, null)
                                    for (i in 1 until parts.size) {
                                        tts?.speak(parts[i], TextToSpeech.QUEUE_ADD, null, null)
                                    }
                                }
                            } else {
                                Toast.makeText(context, "ভয়েস সেটআপ হচ্ছে...", Toast.LENGTH_SHORT).show()
                            }
                        }
                    )
                }
            }
"""

content = content.replace(old_items_logic.strip(), new_items_logic.strip())

# Add NamataFolderTile composable
namata_folder_tile = """
@Composable
fun NamataFolderTile(
    numberStr: String,
    onClick: () -> Unit
) {
    val numberInt = numberStr.map { it - '০' }.joinToString("").toIntOrNull() ?: 1
    
    val folderColors = listOf(
        androidx.compose.ui.graphics.Color(0xFFFFA726), // 1 -> Orange
        androidx.compose.ui.graphics.Color(0xFF66BB6A), // 2 -> Green
        androidx.compose.ui.graphics.Color(0xFF42A5F5), // 3 -> Blue
        androidx.compose.ui.graphics.Color(0xFFAB47BC), // 4 -> Purple
        androidx.compose.ui.graphics.Color(0xFFEF5350), // 5 -> Red
        androidx.compose.ui.graphics.Color(0xFFFFCA28), // 6 -> Yellow
        androidx.compose.ui.graphics.Color(0xFF26C6DA), // 7 -> Cyan
        androidx.compose.ui.graphics.Color(0xFFF48FB1), // 8 -> Pink
        androidx.compose.ui.graphics.Color(0xFF8D6E63), // 9 -> Brown
        androidx.compose.ui.graphics.Color(0xFF2E7D32)  // 10 -> Dark Green
    )
    val colorIndex = (numberInt - 1).coerceIn(0, 9)
    val folderColor = folderColors[colorIndex]
    
    Card(
        modifier = Modifier.fillMaxWidth().aspectRatio(0.85f).clickable { onClick() },
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(2.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    androidx.compose.material.icons.Icons.Default.Folder,
                    contentDescription = "Folder",
                    tint = folderColor,
                    modifier = Modifier.size(80.dp)
                )
                Text(
                    text = numberStr,
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Black,
                    color = androidx.compose.ui.graphics.Color.White,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text("$numberStr এর নামতা", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = MaterialTheme.colorScheme.onSurface)
        }
    }
}
"""

if "fun NamataFolderTile" not in content:
    content += namata_folder_tile

# Remove the old NamataTile
content = re.sub(r'@Composable\s*fun NamataTile.*?\}\n\s*\}\n\s*\}', '', content, flags=re.DOTALL)

with open('/app/applet/app/src/main/java/com/example/ui/CategoryDetailScreen.kt', 'w') as f:
    f.write(content)
