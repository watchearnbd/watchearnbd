with open('./app/src/main/java/com/example/ui/CategoryDetailScreen.kt', 'r') as f:
    content = f.read()

content = content.replace('"১৩" -> LetterDetails("🍎", "তেরো", null)', '"১৩" -> LetterDetails("🌠", "তেরো", null)')
content = content.replace('"২৪" -> LetterDetails("🍎", "চব্বিশ", null)', '"২৪" -> LetterDetails("🪴", "চব্বিশ", null)')
content = content.replace('"৫১" -> LetterDetails("🍎", "একান্ন", null)', '"৫১" -> LetterDetails("🍁", "একান্ন", null)')
content = content.replace('"৫৫" -> LetterDetails("🍎", "পঞ্চান্ন", null)', '"৫৫" -> LetterDetails("🍄", "পঞ্চান্ন", null)')
content = content.replace('"৮১" -> LetterDetails("🍎", "একাশি", null)', '"৮১" -> LetterDetails("🍒", "একাশি", null)')
content = content.replace('"৮৫" -> LetterDetails("🍎", "পঁচাশি", null)', '"৮৫" -> LetterDetails("🍕", "পঁচাশি", null)')
content = content.replace('else -> LetterDetails("🍎", "শেখা", null)', 'else -> LetterDetails("🧩", "শেখা", null)')

with open('./app/src/main/java/com/example/ui/CategoryDetailScreen.kt', 'w') as f:
    f.write(content)
