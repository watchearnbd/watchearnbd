with open('/app/applet/app/src/main/java/com/example/ui/CategoryDetailScreen.kt', 'r') as f:
    content = f.read()

content = content.replace(
    'import androidx.compose.material.icons.filled.VolumeUp',
    'import androidx.compose.material.icons.filled.VolumeUp\nimport androidx.compose.material.icons.automirrored.filled.VolumeUp'
)

with open('/app/applet/app/src/main/java/com/example/ui/CategoryDetailScreen.kt', 'w') as f:
    f.write(content)
