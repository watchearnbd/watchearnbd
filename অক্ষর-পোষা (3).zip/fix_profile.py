import re

with open('./app/src/main/java/com/example/ui/ProfileScreen.kt', 'r') as f:
    content = f.read()

# Add game history states at the top of ProfileScreen
state_str = """    val state = uiState ?: return
    
    val gameHistory by viewModel.gameHistory.collectAsStateWithLifecycle()
    val totalGames by viewModel.totalGamesPlayed.collectAsStateWithLifecycle()
    val totalCorrect by viewModel.totalCorrectAnswers.collectAsStateWithLifecycle()"""

content = content.replace("    val state = uiState ?: return", state_str)

# Add the Game History UI
history_ui = """
            // SECTION: আমার গেমের ইতিহাস
            Text("আমার গেমের ইতিহাস", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp).fillMaxWidth()) {
                    if (gameHistory.isEmpty()) {
                        Text("এখনো কোনো গেম খেলা হয়নি।", color = Color.Gray)
                    } else {
                        gameHistory.forEachIndexed { index, history ->
                            val isToday = index == 0 // Assuming sorted by latest, simplistic approach
                            val dayLabel = when(index) {
                                0 -> "আজকে"
                                1 -> "গতকাল"
                                else -> "${index + 1} দিন আগে"
                            }
                            val statusIcon = when (history.score) {
                                history.totalGames -> "✅"
                                0 -> "❌"
                                else -> "🟡"
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("$dayLabel:")
                                Text("${history.score}/${history.totalGames} গেম $statusIcon", fontWeight = FontWeight.Medium)
                            }
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(16.dp))
                    HorizontalDivider()
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("মোট গেম খেলেছি:", fontWeight = FontWeight.Bold)
                        Text("${totalGames}টি", fontWeight = FontWeight.Bold)
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("মোট সঠিক উত্তর:", fontWeight = FontWeight.Bold)
                        Text("${totalCorrect}টি", fontWeight = FontWeight.Bold)
                    }
                }
            }

            // SECTION 4: সেটিংস"""

content = content.replace("            // SECTION 4: সেটিংস", history_ui)

with open('./app/src/main/java/com/example/ui/ProfileScreen.kt', 'w') as f:
    f.write(content)
