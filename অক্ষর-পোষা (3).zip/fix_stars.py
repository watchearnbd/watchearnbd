with open('./app/src/main/java/com/example/ui/CategoryDetailScreen.kt', 'r') as f:
    content = f.read()

content = content.replace('"⭐"', '"🍎"')
content = content.replace('"🌟"', '"🍎"')
content = content.replace('"৭۸"', '"৭৮"') # I also noticed a typo in the python script 78 where I had a Persian 8 "۷۸" because of the copy-paste maybe? Wait!

with open('./app/src/main/java/com/example/ui/CategoryDetailScreen.kt', 'w') as f:
    f.write(content)
