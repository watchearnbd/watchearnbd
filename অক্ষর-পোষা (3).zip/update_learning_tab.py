with open('/app/applet/app/src/main/java/com/example/ui/LearningTabScreen.kt', 'r') as f:
    content = f.read()

new_item = """            item {
                CategoryCard(
                    title = "সংখ্যা শিখি",
                    icon = "🔢",
                    subtitle = "১ থেকে ১০০ পর্যন্ত",
                    onClick = { onNavigateToCategory("numbers") }
                )
            }
            item {
                CategoryCard(
                    title = "নামতা শিখি",
                    icon = "✖️",
                    subtitle = "১ থেকে ১০ পর্যন্ত",
                    onClick = { onNavigateToCategory("namata") }
                )
            }"""

content = content.replace('            item {\n                CategoryCard(\n                    title = "সংখ্যা শিখি",\n                    icon = "🔢",\n                    subtitle = "১ থেকে ১০০ পর্যন্ত",\n                    onClick = { onNavigateToCategory("numbers") }\n                )\n            }', new_item)

with open('/app/applet/app/src/main/java/com/example/ui/LearningTabScreen.kt', 'w') as f:
    f.write(content)
