import re

with open('/app/applet/app/src/main/java/com/example/ui/TtsUtils.kt', 'r') as f:
    content = f.read()

new_func = """
fun convertToBengaliNumberForNamata(number: Int): String {
    val bengaliDigits = arrayOf('০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯')
    return number.toString().map { if (it.isDigit()) bengaliDigits[it - '0'] else it }.joinToString("")
}

fun getNamataSpokenText(numberStr: String): String {
    val num = numberStr.map { it - '০' }.joinToString("").toIntOrNull() ?: 1
    val baseNames = arrayOf("", "এক", "দুই", "তিন", "চার", "পাঁচ", "ছয়", "সাত", "আট", "নয়", "দশ")
    val multNames = arrayOf("", "একে", "দুগুণে", "তিনে", "চারে", "পাঁচে", "ছয়ে", "সাতে", "আটে", "নয়ে", "দশে")
    
    val baseName = if (num in 1..10) baseNames[num] else getSpokenName(numberStr)
    
    val results = mutableListOf<String>()
    for (i in 1..10) {
        val multName = multNames[i]
        val resultNumStr = convertToBengaliNumberForNamata(num * i)
        val resultName = getSpokenName(resultNumStr)
        results.add("$baseName $multName $resultName")
    }
    return results.joinToString("। ") + "।"
}
"""

if "getNamataSpokenText" not in content:
    with open('/app/applet/app/src/main/java/com/example/ui/TtsUtils.kt', 'a') as f:
        f.write(new_func)
