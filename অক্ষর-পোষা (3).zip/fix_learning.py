with open('./app/src/main/java/com/example/ui/LearningScreen.kt', 'r') as f:
    content = f.read()

content = content.replace('tts?.speak("সোনামণি কিছু লেখোনি!", TextToSpeech.QUEUE_FLUSH, null, null)', '')
content = content.replace('tts?.speak("দারুণ হয়েছে! তুমি খুব সুন্দর লিখেছ!", TextToSpeech.QUEUE_FLUSH, null, null)', '')
content = content.replace('tts?.speak("চেষ্টা করেছ সোনামণি! আরেকটু বড় করে লেখো!", TextToSpeech.QUEUE_FLUSH, null, null)', '')
content = content.replace('tts?.speak("আরেকটু ভালো করে লেখো সোনামণি!", TextToSpeech.QUEUE_FLUSH, null, null)', '')

with open('./app/src/main/java/com/example/ui/LearningScreen.kt', 'w') as f:
    f.write(content)
