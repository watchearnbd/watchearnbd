with open('/app/applet/app/src/main/java/com/example/ui/CategoryDetailScreen.kt', 'r') as f:
    content = f.read()

namata_tile = """
@Composable
fun NamataTile(
    numberStr: String,
    isTtsReady: Boolean,
    onSpeak: () -> Unit
) {
    val numberInt = numberStr.map { it - '০' }.joinToString("").toIntOrNull() ?: 1
    Card(
        modifier = Modifier.fillMaxWidth().clickable { onSpeak() },
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(2.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("$numberStr এর নামতা", fontWeight = FontWeight.Bold, fontSize = 24.sp, color = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.height(16.dp))
            for (i in 1..10) {
                val multStr = convertToBengaliNumber(i)
                val resultStr = convertToBengaliNumber(numberInt * i)
                Text(
                    text = "$numberStr × $multStr = $resultStr",
                    fontSize = 20.sp,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
            }
            Spacer(modifier = Modifier.height(16.dp))
            IconButton(
                onClick = onSpeak,
                modifier = Modifier
                    .size(56.dp)
                    .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(16.dp))
            ) {
                Icon(
                    Icons.AutoMirrored.Filled.VolumeUp,
                    contentDescription = "শোনো",
                    tint = if (isTtsReady) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.outline,
                    modifier = Modifier.size(32.dp)
                )
            }
        }
    }
}
"""

if "fun NamataTile" not in content:
    content += namata_tile
    with open('/app/applet/app/src/main/java/com/example/ui/CategoryDetailScreen.kt', 'w') as f:
        f.write(content)
