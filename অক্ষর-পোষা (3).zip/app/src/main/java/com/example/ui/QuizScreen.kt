package com.example.ui

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class GameCategory(
    val icon: String,
    val title: String,
    val totalGames: Int = 10
)

val gameCategories = listOf(
    GameCategory("🔤", "বাংলা বর্ণ"),
    GameCategory("🔢", "সংখ্যা"),
    GameCategory("🔡", "ইংরেজি বর্ণ"),
    GameCategory("🐾", "প্রাণী"),
    GameCategory("🌈", "রঙ শিখি"),
    GameCategory("🍎", "ফল-সবজি")
)

data class GameItem(
    val title: String,
    val isLocked: Boolean
)

val sampleGames = listOf(
    GameItem("অক্ষর চেনো কুইজ", isLocked = false),
    GameItem("অক্ষর মেলাও", isLocked = false),
    GameItem("শব্দ সাজাও", isLocked = true),
    GameItem("অক্ষর খোঁজো", isLocked = true),
    GameItem("ছবি দেখে বলো", isLocked = true)
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuizScreen(viewModel: MainViewModel) {
    var selectedCategory by remember { mutableStateOf<GameCategory?>(null) }
    val context = LocalContext.current

    BackHandler(enabled = selectedCategory != null) {
        selectedCategory = null
    }

    Scaffold(
        containerColor = DarkBg,
        topBar = {
            if (selectedCategory != null) {
                TopAppBar(
                    title = { Text("${selectedCategory!!.icon} ${selectedCategory!!.title} গেমস", color = TextWhite) },
                    navigationIcon = {
                        IconButton(onClick = { selectedCategory = null }) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "ফিরে যাও", tint = TextWhite)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBg)
                )
            } else {
                TopAppBar(
                    title = { Text("গেমস", color = TextWhite, fontWeight = FontWeight.Bold) },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBg)
                )
            }
        }
    ) { padding ->
        Box(modifier = Modifier.padding(padding).fillMaxSize()) {
            if (selectedCategory == null) {
                // Category Folders Grid
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    contentPadding = PaddingValues(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    items(gameCategories) { category ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .aspectRatio(1f)
                                .clickable { selectedCategory = category },
                            shape = RoundedCornerShape(24.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Column(
                                modifier = Modifier.fillMaxSize().padding(16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Text(text = category.icon, fontSize = 48.sp)
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(
                                    text = category.title,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    textAlign = TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "${category.totalGames}টি গেম",
                                    fontSize = 14.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                                )
                            }
                        }
                    }
                }
            } else {
                // Games List for Category
                Column(
                    modifier = Modifier.fillMaxSize().padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    sampleGames.forEach { game ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable(enabled = !game.isLocked) {
                                    Toast.makeText(context, "${game.title} শুরু হচ্ছে...", Toast.LENGTH_SHORT).show()
                                },
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Row(
                                modifier = Modifier.padding(16.dp).fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = if (game.isLocked) "🔒" else "✅",
                                        fontSize = 20.sp
                                    )
                                    Spacer(modifier = Modifier.width(16.dp))
                                    Text(
                                        text = game.title,
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = if (game.isLocked) Color.Gray else MaterialTheme.colorScheme.onSurface
                                    )
                                }
                                if (game.isLocked) {
                                    Icon(Icons.Default.Lock, contentDescription = "Locked", tint = Color.Gray)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
