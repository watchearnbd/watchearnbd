package com.example.ui

import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.platform.LocalContext
import android.speech.tts.TextToSpeech
import java.util.Locale
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Create
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.foundation.clickable
import android.widget.Toast
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CategoryDetailScreen(
    categoryId: String,
    onNavigateBack: () -> Unit,
    onNavigateToPractice: (String) -> Unit
) {
    val context = LocalContext.current
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }
    var isTtsReady by remember { mutableStateOf(false) }
    
    DisposableEffect(context) {
        var textToSpeech: TextToSpeech? = null
        textToSpeech = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val localeBn = Locale("bn", "BD")
                val result = textToSpeech?.setLanguage(localeBn) ?: TextToSpeech.LANG_NOT_SUPPORTED
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    textToSpeech?.language = Locale.ENGLISH
                }
                textToSpeech?.setPitch(1.8f)
                textToSpeech?.setSpeechRate(0.7f)
                isTtsReady = true
            } else {
                Toast.makeText(context, "TTS Initialization failed", Toast.LENGTH_SHORT).show()
            }
        }
        tts = textToSpeech
        onDispose {
            textToSpeech?.stop()
            textToSpeech?.shutdown()
        }
    }
    val (title, itemsList) = when (categoryId) {
        "vowels" -> "বাংলা স্বরবর্ণ" to listOf("অ", "আ", "ই", "ঈ", "উ", "ঊ", "ঋ", "এ", "ঐ", "ও", "ঔ")
        "consonants" -> "বাংলা ব্যঞ্জনবর্ণ" to listOf("ক", "খ", "গ", "ঘ", "ঙ", "চ", "ছ", "জ", "ঝ", "ঞ", "ট", "ঠ", "ড", "ঢ", "ণ", "ত", "থ", "দ", "ধ", "ন", "প", "ফ", "ব", "ভ", "ম", "য", "র", "ল", "শ", "ষ", "স", "হ", "ড়", "ঢ়", "য়", "ৎ", "ং", "ঃ", "ঁ")
        "english_cap" -> "ইংরেজি বড় হাতের অক্ষর" to ('A'..'Z').map { it.toString() }
        "english_small" -> "ইংরেজি ছোট হাতের অক্ষর" to ('a'..'z').map { it.toString() }
        "numbers" -> "সংখ্যা শিখি" to (1..100).map { convertToBengaliNumber(it) }
        "namata" -> "নামতা শিখি" to (1..10).map { convertToBengaliNumber(it) }
        else -> "শেখার বিষয়" to listOf()
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    titleContentColor = MaterialTheme.colorScheme.onBackground
                ),
                title = { Text(title, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = MaterialTheme.colorScheme.primary)
                    }
                }
            )
        }
    ) { paddingValues ->
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(vertical = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(itemsList) { itemStr ->
                if (categoryId == "namata") {
                    NamataFolderTile(
                        numberStr = itemStr,
                        onClick = { onNavigateToPractice("namata_$itemStr") }
                    )
                } else {
                    LetterTile(
                        letter = itemStr,
                        isTtsReady = isTtsReady,
                        onPractice = { onNavigateToPractice(itemStr) },
                        onSpeak = {
                            if (isTtsReady) {
                                val spokenText = getSpokenName(itemStr)
                                val parts = spokenText.split("।").filter { it.isNotBlank() }
                                if (parts.isNotEmpty()) {
                                    tts?.speak(parts[0], TextToSpeech.QUEUE_FLUSH, null, null)
                                    for (i in 1 until parts.size) {
                                        tts?.speak(parts[i], TextToSpeech.QUEUE_ADD, null, null)
                                    }
                                }
                            } else {
                                Toast.makeText(context, "ভয়েস সেটআপ হচ্ছে...", Toast.LENGTH_SHORT).show()
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun LetterTile(
    letter: String,
    isTtsReady: Boolean,
    onPractice: () -> Unit,
    onSpeak: () -> Unit
) {
    val details = getLetterDetails(letter)
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(0.7f),
            
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(2.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = letter,
                    fontSize = 80.sp,
                    fontWeight = FontWeight.Black,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(text = details.emoji, fontSize = 50.sp)
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = details.bnName,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = androidx.compose.ui.graphics.Color(0xFF4CAF50)
                )
                if (details.enName != null) {
                    Text(
                        text = details.enName,
                        fontSize = 16.sp,
                        color = androidx.compose.ui.graphics.Color.Gray
                    )
                }
            }
            
            // Actions Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.primaryContainer)
                    .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                IconButton(onClick = onSpeak) {
                    Icon(
                        imageVector = if (isTtsReady) Icons.AutoMirrored.Filled.VolumeUp else Icons.AutoMirrored.Filled.VolumeOff,
                        contentDescription = "শুনুন",
                        tint = if (isTtsReady) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                        modifier = Modifier.size(32.dp)
                    )
                }
                IconButton(onClick = onPractice) {
                    Icon(
                        imageVector = Icons.Default.Create,
                        contentDescription = "লিখুন",
                        tint = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.size(32.dp)
                    )
                }
            }
        }
    }
}

data class LetterDetails(val emoji: String, val bnName: String, val enName: String? = null)

fun getLetterDetails(letter: String): LetterDetails {
    return when (letter.uppercase()) {
        "A" -> LetterDetails("🍎", "আপেল", "Apple")
        "B" -> LetterDetails("⚽", "বল", "Ball")
        "C" -> LetterDetails("🐱", "বিড়াল", "Cat")
        "D" -> LetterDetails("🐶", "কুকুর", "Dog")
        "E" -> LetterDetails("🐘", "হাতি", "Elephant")
        "F" -> LetterDetails("🐟", "মাছ", "Fish")
        "G" -> LetterDetails("🍇", "আঙুর", "Grapes")
        "H" -> LetterDetails("🏠", "বাড়ি", "House")
        "I" -> LetterDetails("🍦", "আইসক্রিম", "Ice cream")
        "J" -> LetterDetails("🍓", "জাম", "Jam")
        "K" -> LetterDetails("🪁", "ঘুড়ি", "Kite")
        "L" -> LetterDetails("🦁", "সিংহ", "Lion")
        "M" -> LetterDetails("🌙", "চাঁদ", "Moon")
        "N" -> LetterDetails("📓", "খাতা", "Notebook")
        "O" -> LetterDetails("🍊", "কমলা", "Orange")
        "P" -> LetterDetails("🐧", "পেঙ্গুইন", "Penguin")
        "Q" -> LetterDetails("👸", "রানি", "Queen")
        "R" -> LetterDetails("🌹", "গোলাপ", "Rose")
        "S" -> LetterDetails("☀️", "সূর্য", "Sun")
        "T" -> LetterDetails("🐯", "বাঘ", "Tiger")
        "U" -> LetterDetails("☂️", "ছাতা", "Umbrella")
        "V" -> LetterDetails("🎻", "বেহালা", "Violin")
        "W" -> LetterDetails("🐋", "তিমি", "Whale")
        "X" -> LetterDetails("🎸", "জাইলোফোন", "Xylophone")
        "Y" -> LetterDetails("🪀", "ইয়ো-ইয়ো", "Yo-yo")
        "Z" -> LetterDetails("🦓", "জেব্রা", "Zebra")
        else -> when (letter) {
            "অ" -> LetterDetails("🦆", "অজগর", null)
            "আ" -> LetterDetails("🥭", "আম", null)
            "ই" -> LetterDetails("🐭", "ইঁদুর", null)
            "ঈ" -> LetterDetails("🦅", "ঈগল", null)
            "উ" -> LetterDetails("🐪", "উট", null)
            "ঊ" -> LetterDetails("🌊", "ঊর্মি", null)
            "ঋ" -> LetterDetails("🐻", "ঋক্ষ", null)
            "এ" -> LetterDetails("✏️", "এক", null)
            "ঐ" -> LetterDetails("🪞", "ঐনা", null)
            "ও" -> LetterDetails("💊", "ওষুধ", null)
            "ঔ" -> LetterDetails("🌿", "ঔষধ", null)
            "ক" -> LetterDetails("🍌", "কলা", null)
            "খ" -> LetterDetails("🐇", "খরগোশ", null)
            "গ" -> LetterDetails("🐄", "গরু", null)
            "ঘ" -> LetterDetails("🏠", "ঘর", null)
            "ঙ" -> LetterDetails("🎨", "রঙ", null)
            "চ" -> LetterDetails("🌙", "চাঁদ", null)
            "ছ" -> LetterDetails("🐐", "ছাগল", null)
            "জ" -> LetterDetails("🍓", "জাম", null)
            "ঝ" -> LetterDetails("🌪️", "ঝড়", null)
            "ট" -> LetterDetails("🍅", "টমেটো", null)
            "ঠ" -> LetterDetails("👄", "ঠোঁট", null)
            "ড" -> LetterDetails("🥥", "ডাব", null)
            "ঢ" -> LetterDetails("🥁", "ঢাক", null)
            "ত" -> LetterDetails("🍉", "তরমুজ", null)
            "থ" -> LetterDetails("🍽️", "থালা", null)
            "দ" -> LetterDetails("🥛", "দই", null)
            "ধ" -> LetterDetails("🌾", "ধান", null)
            "ন" -> LetterDetails("🌊", "নদী", null)
            "প" -> LetterDetails("🐦", "পাখি", null)
            "ফ" -> LetterDetails("🌸", "ফুল", null)
            "ব" -> LetterDetails("📚", "বই", null)
            "ভ" -> LetterDetails("🐻", "ভালুক", null)
            "ম" -> LetterDetails("🐟", "মাছ", null)
            "য" -> LetterDetails("🎵", "যন্ত্র", null)
            "র" -> LetterDetails("🚀", "রকেট", null)
            "ল" -> LetterDetails("🍋", "লেবু", null)
            "শ" -> LetterDetails("🐦", "শালিক", null)
            "স" -> LetterDetails("🐍", "সাপ", null)
            "হ" -> LetterDetails("🐘", "হাতি", null)
            "ঞ" -> LetterDetails("🍊", "রঞ্জন", null)
            "ণ" -> LetterDetails("🥁", "মণ", null)
            "ষ" -> LetterDetails("🐂", "ষাঁড়", null)
            "ড়" -> LetterDetails("🥚", "ড়িম (ডিম)", null)
            "ঢ়" -> LetterDetails("🌿", "ঢ়েঁকি", null)
            "য়" -> LetterDetails("🌺", "য়ুব (যুব)", null)
            "ৎ" -> LetterDetails("🏃", "তৎপর", null)
            "ং" -> LetterDetails("🎵", "রং", null)
            "ঃ" -> LetterDetails("✨", "বিসর্গ", null)
            "ঁ" -> LetterDetails("🌙", "চাঁদ (অনুস্বার)", null)
            "১" -> LetterDetails("☝️", "এক", null)
            "২" -> LetterDetails("✌️", "দুই", null)
            "৩" -> LetterDetails("🤟", "তিন", null)
            "৪" -> LetterDetails("🍀", "চার", null)
            "৫" -> LetterDetails("🖐️", "পাঁচ", null)
            "৬" -> LetterDetails("🎲", "ছয়", null)
            "৭" -> LetterDetails("🌈", "সাত", null)
            "৮" -> LetterDetails("🐙", "আট", null)
            "৯" -> LetterDetails("🎯", "নয়", null)
            "১০" -> LetterDetails("🔟", "দশ", null)
            "১১" -> LetterDetails("🦋", "এগারো", null)
            "১২" -> LetterDetails("🕛", "বারো", null)
            "১৩" -> LetterDetails("🌠", "তেরো", null)
            "১৪" -> LetterDetails("💝", "চৌদ্দ", null)
            "১৫" -> LetterDetails("🌸", "পনেরো", null)
            "১৬" -> LetterDetails("🎪", "ষোলো", null)
            "১৭" -> LetterDetails("🦁", "সতেরো", null)
            "১৮" -> LetterDetails("🌺", "আঠারো", null)
            "১৯" -> LetterDetails("🦊", "উনিশ", null)
            "২০" -> LetterDetails("🎉", "বিশ", null)
            "২১" -> LetterDetails("🐬", "একুশ", null)
            "২২" -> LetterDetails("🦜", "বাইশ", null)
            "২৩" -> LetterDetails("🌙", "তেইশ", null)
            "২৪" -> LetterDetails("🪴", "চব্বিশ", null)
            "২৫" -> LetterDetails("🎂", "পঁচিশ", null)
            "২৬" -> LetterDetails("🦚", "ছাব্বিশ", null)
            "২৭" -> LetterDetails("🌍", "সাতাশ", null)
            "২৮" -> LetterDetails("🐼", "আঠাশ", null)
            "২৯" -> LetterDetails("🦄", "উনত্রিশ", null)
            "৩০" -> LetterDetails("🎠", "ত্রিশ", null)
            "৩১" -> LetterDetails("🌻", "একত্রিশ", null)
            "৩২" -> LetterDetails("🐯", "বত্রিশ", null)
            "৩৩" -> LetterDetails("🎨", "তেত্রিশ", null)
            "৩৪" -> LetterDetails("🦋", "চৌত্রিশ", null)
            "৩৫" -> LetterDetails("🌴", "পঁয়ত্রিশ", null)
            "৩৬" -> LetterDetails("🐳", "ছত্রিশ", null)
            "৩৭" -> LetterDetails("🎭", "সাঁইত্রিশ", null)
            "৩৮" -> LetterDetails("🦩", "আটত্রিশ", null)
            "৩৯" -> LetterDetails("🌮", "উনচল্লিশ", null)
            "৪০" -> LetterDetails("🎪", "চল্লিশ", null)
            "৪১" -> LetterDetails("🦅", "একচল্লিশ", null)
            "৪২" -> LetterDetails("🌊", "বিয়াল্লিশ", null)
            "৪৩" -> LetterDetails("🐋", "তেতাল্লিশ", null)
            "৪৪" -> LetterDetails("🦁", "চৌচল্লিশ", null)
            "৪৫" -> LetterDetails("🌺", "পঁয়তাল্লিশ", null)
            "৪৬" -> LetterDetails("🎯", "ছেচল্লিশ", null)
            "৪৭" -> LetterDetails("🐘", "সাতচল্লিশ", null)
            "৪৮" -> LetterDetails("🌸", "আটচল্লিশ", null)
            "৪৯" -> LetterDetails("🦊", "উনপঞ্চাশ", null)
            "৫০" -> LetterDetails("🎊", "পঞ্চাশ", null)
            "৫১" -> LetterDetails("🍁", "একান্ন", null)
            "৫২" -> LetterDetails("🐬", "বায়ান্ন", null)
            "৫৩" -> LetterDetails("🦜", "তিপান্ন", null)
            "৫৪" -> LetterDetails("🌙", "চুয়ান্ন", null)
            "৫৫" -> LetterDetails("🍄", "পঞ্চান্ন", null)
            "৫৬" -> LetterDetails("🎂", "ছাপান্ন", null)
            "৫৭" -> LetterDetails("🦚", "সাতান্ন", null)
            "৫৮" -> LetterDetails("🌍", "আটান্ন", null)
            "৫৯" -> LetterDetails("🐼", "উনষাট", null)
            "৬০" -> LetterDetails("🎠", "ষাট", null)
            "৬১" -> LetterDetails("🌻", "একষট্টি", null)
            "৬২" -> LetterDetails("🐯", "বাষট্টি", null)
            "৬৩" -> LetterDetails("🎨", "তেষট্টি", null)
            "৬৪" -> LetterDetails("🦋", "চৌষট্টি", null)
            "৬৫" -> LetterDetails("🌴", "পঁয়ষট্টি", null)
            "৬৬" -> LetterDetails("🐳", "ছেষট্টি", null)
            "৬৭" -> LetterDetails("🎭", "সাতষট্টি", null)
            "৬৮" -> LetterDetails("🦩", "আটষট্টি", null)
            "৬৯" -> LetterDetails("🌮", "উনসত্তর", null)
            "৭০" -> LetterDetails("🎪", "সত্তর", null)
            "৭১" -> LetterDetails("🦅", "একাত্তর", null)
            "৭২" -> LetterDetails("🌊", "বাহাত্তর", null)
            "৭৩" -> LetterDetails("🐋", "তিয়াত্তর", null)
            "৭৪" -> LetterDetails("🦁", "চুয়াত্তর", null)
            "৭৫" -> LetterDetails("🌺", "পঁচাত্তর", null)
            "৭৬" -> LetterDetails("🎯", "ছিয়াত্তর", null)
            "৭৭" -> LetterDetails("🐘", "সাতাত্তর", null)
            "৭৮" -> LetterDetails("🌸", "আটাত্তর", null)
            "৭৯" -> LetterDetails("🦊", "উনআশি", null)
            "৮০" -> LetterDetails("🎊", "আশি", null)
            "৮১" -> LetterDetails("🍒", "একাশি", null)
            "৮২" -> LetterDetails("🐬", "বিরাশি", null)
            "৮৩" -> LetterDetails("🦜", "তিরাশি", null)
            "৮৪" -> LetterDetails("🌙", "চুরাশি", null)
            "৮৫" -> LetterDetails("🍕", "পঁচাশি", null)
            "৮৬" -> LetterDetails("🎂", "ছিয়াশি", null)
            "৮৭" -> LetterDetails("🦚", "সাতাশি", null)
            "৮৮" -> LetterDetails("🌍", "আটাশি", null)
            "৮৯" -> LetterDetails("🐼", "উননব্বই", null)
            "৯০" -> LetterDetails("🎠", "নব্বই", null)
            "৯১" -> LetterDetails("🌻", "একানব্বই", null)
            "৯২" -> LetterDetails("🐯", "বিরানব্বই", null)
            "৯৩" -> LetterDetails("🎨", "তিরানব্বই", null)
            "৯৪" -> LetterDetails("🦋", "চুরানব্বই", null)
            "৯৫" -> LetterDetails("🌴", "পঁচানব্বই", null)
            "৯৬" -> LetterDetails("🐳", "ছিয়ানব্বই", null)
            "৯৭" -> LetterDetails("🎭", "সাতানব্বই", null)
            "৯৮" -> LetterDetails("🦩", "আটানব্বই", null)
            "৯৯" -> LetterDetails("🌮", "নিরানব্বই", null)
            "১০০" -> LetterDetails("🏆", "একশো", null)
            else -> LetterDetails("🧩", "শেখা", null)
        }
    }
}

fun convertToBengaliNumber(number: Int): String {
    val englishToBengaliMap = mapOf(
        '0' to '০', '1' to '১', '2' to '২', '3' to '৩', '4' to '৪',
        '5' to '৫', '6' to '৬', '7' to '৭', '8' to '৮', '9' to '৯'
    )
    return number.toString().map { englishToBengaliMap[it] ?: it }.joinToString("")
}


@Composable
fun NamataFolderTile(
    numberStr: String,
    onClick: () -> Unit
) {
    val numberInt = numberStr.map { it - '০' }.joinToString("").toIntOrNull() ?: 1
    
    val folderColors = listOf(
        androidx.compose.ui.graphics.Color(0xFFFFA726), // 1 -> Orange
        androidx.compose.ui.graphics.Color(0xFF66BB6A), // 2 -> Green
        androidx.compose.ui.graphics.Color(0xFF42A5F5), // 3 -> Blue
        androidx.compose.ui.graphics.Color(0xFFAB47BC), // 4 -> Purple
        androidx.compose.ui.graphics.Color(0xFFEF5350), // 5 -> Red
        androidx.compose.ui.graphics.Color(0xFFFFCA28), // 6 -> Yellow
        androidx.compose.ui.graphics.Color(0xFF26C6DA), // 7 -> Cyan
        androidx.compose.ui.graphics.Color(0xFFF48FB1), // 8 -> Pink
        androidx.compose.ui.graphics.Color(0xFF8D6E63), // 9 -> Brown
        androidx.compose.ui.graphics.Color(0xFF2E7D32)  // 10 -> Dark Green
    )
    val colorIndex = (numberInt - 1).coerceIn(0, 9)
    val folderColor = folderColors[colorIndex]
    
    Card(
        modifier = Modifier.fillMaxWidth().aspectRatio(0.85f).clickable { onClick() },
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(2.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    androidx.compose.material.icons.Icons.Default.Folder,
                    contentDescription = "Folder",
                    tint = folderColor,
                    modifier = Modifier.size(80.dp)
                )
                Text(
                    text = numberStr,
                    fontSize = 50.sp,
                    fontWeight = FontWeight.Black,
                    color = androidx.compose.ui.graphics.Color.White
                    
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text("$numberStr এর নামতা", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = MaterialTheme.colorScheme.onSurface)
        }
    }
}
