package com.example.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun LearningTabScreen(
    viewModel: MainViewModel,
    onNavigateToCategory: (String) -> Unit
) {
    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 24.dp),
            contentPadding = PaddingValues(vertical = 24.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            item {
                Text(
                    text = "লেখাপড়া",
                    fontWeight = FontWeight.Bold,
                    fontSize = 28.sp,
                    color = MaterialTheme.colorScheme.onBackground,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
            }
            
            item {
                CategoryCard(
                    title = "বাংলা স্বরবর্ণ",
                    icon = "🅰️",
                    subtitle = "অ আ ই ঈ উ ঊ ঋ এ ঐ ও ঔ",
                    onClick = { onNavigateToCategory("vowels") }
                )
            }
            item {
                CategoryCard(
                    title = "বাংলা ব্যঞ্জনবর্ণ",
                    icon = "🔤",
                    subtitle = "ক খ গ ঘ ঙ চ ছ জ ঝ ঞ...",
                    onClick = { onNavigateToCategory("consonants") }
                )
            }
            item {
                CategoryCard(
                    title = "ইংরেজি বড় হাতের অক্ষর",
                    icon = "🔠",
                    subtitle = "A B C D E F G H I J...",
                    onClick = { onNavigateToCategory("english_cap") }
                )
            }
            item {
                CategoryCard(
                    title = "ইংরেজি ছোট হাতের অক্ষর",
                    icon = "🔡",
                    subtitle = "a b c d e f g h i j...",
                    onClick = { onNavigateToCategory("english_small") }
                )
            }
            item {
                CategoryCard(
                    title = "সংখ্যা শিখি",
                    icon = "🔢",
                    subtitle = "১ থেকে ১০০ পর্যন্ত",
                    onClick = { onNavigateToCategory("numbers") }
                )
            }
            item {
                CategoryCard(
                    title = "নামতা শিখি",
                    icon = "🔢",
                    subtitle = "১ থেকে ১০০ পর্যন্ত",
                    onClick = { onNavigateToCategory("namata") }
                )
            }
        }
    }
}