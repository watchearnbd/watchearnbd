package com.example.ui

data class QuizQuestion(
    val question: String,
    val options: List<String>,
    val correctAnswerIndex: Int
)

val allQuizQuestions = listOf(
    QuizQuestion("নিচের কোনটি স্বরবর্ণ?", listOf("ক", "অ", "গ", "ঘ"), 1),
    QuizQuestion("১ এরপর কোন সংখ্যা আসে?", listOf("২", "৩", "৪", "৫"), 0),
    QuizQuestion("Apple মানে কী?", listOf("কমলা", "আপেল", "কলা", "আঙ্গুর"), 1),
    QuizQuestion("কোন প্রাণী বনে থাকে?", listOf("বাঘ", "গরু", "ছাগল", "কুকুর"), 0),
    QuizQuestion("আকাশের রঙ কী?", listOf("লাল", "সবুজ", "নীল", "হলুদ"), 2),
    QuizQuestion("১০ এর আগের সংখ্যা কত?", listOf("৮", "৯", "১১", "১২"), 1),
    QuizQuestion("কোনটি ব্যঞ্জনবর্ণ?", listOf("অ", "আ", "ক", "ঈ"), 2),
    QuizQuestion("কুকুর কীভাবে ডাকে?", listOf("ম্যাও", "ঘেউ ঘেউ", "হাম্বা", "কাকা"), 1),
    QuizQuestion("Cat মানে কী?", listOf("বিড়াল", "কুকুর", "গরু", "ছাগল"), 0),
    QuizQuestion("ঘাসের রঙ কী?", listOf("নীল", "সবুজ", "সাদা", "কালো"), 1)
)
