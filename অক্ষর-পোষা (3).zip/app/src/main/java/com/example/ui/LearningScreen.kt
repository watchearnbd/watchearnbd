package com.example.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.ui.platform.LocalContext
import android.speech.tts.TextToSpeech
import java.util.Locale
import kotlin.math.sqrt
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Edit
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.layout.onSizeChanged
import android.graphics.PathMeasure as AndroidPathMeasure
import android.graphics.Path as AndroidPath
import android.graphics.RectF
import android.graphics.Paint
import androidx.compose.ui.graphics.asComposePath
import androidx.compose.animation.core.*
import androidx.compose.ui.graphics.drawscope.translate

enum class WritingResult {
    GOOD, TRY_BIGGER, EMPTY, TRY_AGAIN
}

fun checkWriting(
    strokeCount: Int,
    coverage: Float,
    timeSpent: Long
): WritingResult {
    if (strokeCount == 0) {
        return WritingResult.EMPTY
    }
    if (strokeCount >= 1 && coverage >= 0.15f && timeSpent >= 3000) {
        return WritingResult.GOOD
    }
    if (strokeCount >= 1 && timeSpent >= 2000) {
        return WritingResult.TRY_BIGGER
    }
    return WritingResult.TRY_AGAIN
}

private data class Contour(
    val length: Float,
    val composePath: androidx.compose.ui.graphics.Path,
    val androidPathMeasure: AndroidPathMeasure
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LearningScreen(
    letter: String,
    viewModel: MainViewModel,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }
    var isTtsReady by remember { mutableStateOf(false) }
    
    DisposableEffect(context) {
        var textToSpeech: TextToSpeech? = null
        textToSpeech = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val localeBn = Locale("bn", "BD")
                val result = textToSpeech?.setLanguage(localeBn) ?: TextToSpeech.LANG_NOT_SUPPORTED
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    textToSpeech?.language = Locale.ENGLISH
                }
                textToSpeech?.setPitch(1.8f)
                textToSpeech?.setSpeechRate(0.7f)
                isTtsReady = true
            } else {
                android.widget.Toast.makeText(context, "TTS Initialization failed", android.widget.Toast.LENGTH_SHORT).show()
            }
        }
        tts = textToSpeech
        onDispose {
            textToSpeech?.stop()
            textToSpeech?.shutdown()
        }
    }

    LaunchedEffect(isTtsReady) {
        if (isTtsReady) {
            
            tts?.speak(letter, TextToSpeech.QUEUE_FLUSH, null, null)
        }
    }

    var paths by remember { mutableStateOf(listOf<Path>()) }
    var currentPath by remember { mutableStateOf<Path?>(null) }
    var showSuccess by remember { mutableStateOf(false) }
    var showError by remember { mutableStateOf(false) }
    var showTryBigger by remember { mutableStateOf(false) }
    var showEmpty by remember { mutableStateOf(false) }
    
    var strokeLength by remember { mutableStateOf(0f) }
    var wrongAttempts by remember { mutableStateOf(0) }
    var lastPosition by remember { mutableStateOf<Offset?>(null) }
    
    var minX by remember { mutableStateOf(Float.MAX_VALUE) }
    var maxX by remember { mutableStateOf(Float.MIN_VALUE) }
    var minY by remember { mutableStateOf(Float.MAX_VALUE) }
    var maxY by remember { mutableStateOf(Float.MIN_VALUE) }
    var startTime by remember { mutableStateOf(0L) }
    var canvasSize by remember { mutableStateOf(androidx.compose.ui.unit.IntSize.Zero) }

    val contoursAndBounds = remember(letter) {
        val p = Paint().apply {
            textSize = 600f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            textAlign = Paint.Align.CENTER
        }
        val androidPath = AndroidPath()
        p.getTextPath(letter, 0, letter.length, 0f, 0f, androidPath)
        
        val bounds = RectF()
        androidPath.computeBounds(bounds, true)
        
        val pm = AndroidPathMeasure(androidPath, false)
        val list = mutableListOf<Contour>()
        do {
            val len = pm.length
            if (len > 0) {
                val segment = AndroidPath()
                pm.getSegment(0f, len, segment, true)
                val segmentPm = AndroidPathMeasure(segment, false)
                list.add(Contour(len, segment.asComposePath(), segmentPm))
            }
        } while (pm.nextContour())
        
        Pair(list, bounds)
    }
    val (contours, pathBounds) = contoursAndBounds

    val infiniteTransition = rememberInfiniteTransition()
    val totalLength = remember(contours) { contours.sumOf { it.length.toDouble() }.toFloat() }
    val animationProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = maxOf(2000, (contours.size * 3000)), easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "StrokeAnimation"
    )

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    titleContentColor = MaterialTheme.colorScheme.onBackground
                ),
                title = { Text("অক্ষর লেখা শিখি", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = MaterialTheme.colorScheme.primary)
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // TOP BOX: Animation Guide
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(Color.White, RoundedCornerShape(24.dp)),
                contentAlignment = Alignment.Center
            ) {
                // Watermark letter
                Text(
                    text = letter,
                    fontSize = 120.sp,
                    fontWeight = FontWeight.Black,
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)
                )

                // Animation Canvas
                Canvas(modifier = Modifier.fillMaxSize().padding(16.dp)) {
                    if (contours.isNotEmpty() && totalLength > 0f) {
                        val currentLen = animationProgress * totalLength
                        var remainingLen = currentLen
                        var activeContour: Contour? = null
                        var distanceInActive = 0f
                        
                        for (contour in contours) {
                            if (remainingLen <= contour.length) {
                                activeContour = contour
                                distanceInActive = remainingLen
                                break
                            }
                            remainingLen -= contour.length
                        }
                        if (activeContour == null) {
                            activeContour = contours.last()
                            distanceInActive = activeContour.length
                        }
                        
                        val dx = size.width / 2 - pathBounds.centerX()
                        val dy = size.height / 2 - pathBounds.centerY()
                        
                        translate(dx, dy) {
                            val colors = listOf(Color.Red, Color.Blue, Color.Green, Color(0xFFFFA500), Color(0xFF9C27B0))
                            contours.forEachIndexed { index, contour ->
                                drawPath(
                                    path = contour.composePath,
                                    color = colors[index % colors.size].copy(alpha = 0.5f),
                                    style = Stroke(
                                        width = 12f,
                                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(30f, 30f), 0f)
                                    )
                                )
                            }
                            
                            val pos = FloatArray(2)
                            activeContour.androidPathMeasure.getPosTan(distanceInActive, pos, null)
                            
                            drawCircle(
                                color = Color.Blue,
                                radius = 24f,
                                center = Offset(pos[0], pos[1])
                            )
                            drawCircle(
                                color = Color.Blue.copy(alpha = 0.3f),
                                radius = 40f,
                                center = Offset(pos[0], pos[1])
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            
            val hasStartedDrawing = paths.isNotEmpty() || currentPath != null
            Text(
                text = if (hasStartedDrawing) "খুব সুন্দর! লেখা চালিয়ে যাও..." else "নিচে নিজে লেখো 👇",
                fontSize = 18.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onBackground
            )
            
            Spacer(modifier = Modifier.height(16.dp))

            // BOTTOM BOX: Drawing Canvas
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(Color.White, RoundedCornerShape(24.dp))
                    .onSizeChanged { canvasSize = it }
                    .pointerInput(Unit) {
                        detectDragGestures(
                            onDragStart = { offset ->
                                if (startTime == 0L) startTime = System.currentTimeMillis()
                                currentPath = Path().apply {
                                    moveTo(offset.x, offset.y)
                                }
                                lastPosition = offset
                            },
                            onDrag = { change, _ ->
                                val pos = change.position
                                currentPath?.lineTo(pos.x, pos.y)
                                
                                minX = kotlin.math.min(minX, pos.x)
                                maxX = kotlin.math.max(maxX, pos.x)
                                minY = kotlin.math.min(minY, pos.y)
                                maxY = kotlin.math.max(maxY, pos.y)
                                
                                lastPosition?.let { last ->
                                    val dx = pos.x - last.x
                                    val dy = pos.y - last.y
                                    strokeLength += sqrt(dx * dx + dy * dy)
                                }
                                lastPosition = pos
                                
                                // Force recomposition
                                currentPath = Path().apply {
                                    addPath(currentPath!!)
                                }
                            },
                            onDragEnd = {
                                currentPath?.let {
                                    paths = paths + it
                                }
                                currentPath = null
                                lastPosition = null
                            }
                        )
                    },
                contentAlignment = Alignment.Center
            ) {
                if (wrongAttempts >= 3) {
                    // Show a hint dotted letter
                    Text(
                        text = letter,
                        fontSize = 120.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.LightGray.copy(alpha = 0.5f)
                    )
                }

                Canvas(modifier = Modifier.fillMaxSize().padding(16.dp)) {
                    paths.forEach { path ->
                        drawPath(
                            path = path,
                            color = Color(0xFFFF9800),
                            style = Stroke(
                                width = 32f,
                                cap = StrokeCap.Round,
                                join = StrokeJoin.Round
                            )
                        )
                    }
                    currentPath?.let { path ->
                        drawPath(
                            path = path,
                            color = Color(0xFFFF9800),
                            style = Stroke(
                                width = 32f,
                                cap = StrokeCap.Round,
                                join = StrokeJoin.Round
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                OutlinedButton(
                    onClick = { 
                        paths = emptyList()
                        strokeLength = 0f
                        minX = Float.MAX_VALUE
                        maxX = Float.MIN_VALUE
                        minY = Float.MAX_VALUE
                        maxY = Float.MIN_VALUE
                        startTime = 0L
                    },
                    modifier = Modifier.weight(1f).padding(end = 8.dp).height(56.dp)
                ) {
                    Text("মুছে ফেলুন")
                }
                
                Button(
                    onClick = {
                        val timeTaken = if (startTime == 0L) 0 else System.currentTimeMillis() - startTime
                        val width = if (maxX > minX) maxX - minX else 0f
                        val height = if (maxY > minY) maxY - minY else 0f
                        val coverage = if (canvasSize.width > 0 && canvasSize.height > 0) {
                            (width * height) / (canvasSize.width * canvasSize.height).toFloat()
                        } else 0f
                        
                        var result = checkWriting(paths.size, coverage, timeTaken)
                        
                        if (wrongAttempts >= 2 && result != WritingResult.EMPTY) {
                            // After 3 attempts (0, 1, 2) it becomes 3rd attempt check, give pass
                            result = WritingResult.GOOD
                        }
                        
                        when (result) {
                            WritingResult.EMPTY -> {
                                showEmpty = true
                                
                            }
                            WritingResult.GOOD -> {
                                showSuccess = true
                                viewModel.completeLesson()
                                
                            }
                            WritingResult.TRY_BIGGER -> {
                                showTryBigger = true
                                wrongAttempts++
                                
                            }
                            WritingResult.TRY_AGAIN -> {
                                showError = true
                                wrongAttempts++
                                
                            }
                        }
                    },
                    modifier = Modifier.weight(1f).padding(start = 8.dp).height(56.dp).testTag("finish_lesson_button")
                ) {
                    Text("সম্পন্ন", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    if (showSuccess) {
        AlertDialog(
            onDismissRequest = { 
                showSuccess = false 
                onNavigateBack()
            },
            icon = { Icon(Icons.Default.CheckCircle, contentDescription = "Success", tint = Color(0xFF4CAF50), modifier = Modifier.size(48.dp)) },
            title = { Text("দারুণ হয়েছে! 🎉") },
            text = { Text("+10 XP") },
            confirmButton = {
                Button(
                    onClick = { 
                        showSuccess = false
                        onNavigateBack()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4CAF50))
                ) {
                    Text("পরের অক্ষর →")
                }
            }
        )
    }

    if (showTryBigger) {
        AlertDialog(
            onDismissRequest = { showTryBigger = false },
            icon = { Icon(Icons.Default.Star, contentDescription = "Try Bigger", tint = Color(0xFFFFC107), modifier = Modifier.size(48.dp)) },
            title = { Text("বাহ! আরেকটু বড় করে লেখো! 🌟") },
            text = { Text("চেষ্টা করেছ সোনামণি! আরেকটু বড় করে লেখো!") },
            confirmButton = {
                Button(
                    onClick = { 
                        showTryBigger = false
                        paths = emptyList()
                        strokeLength = 0f
                        minX = Float.MAX_VALUE
                        maxX = Float.MIN_VALUE
                        minY = Float.MAX_VALUE
                        maxY = Float.MIN_VALUE
                        startTime = 0L
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFC107), contentColor = Color.Black)
                ) {
                    Text("আবার চেষ্টা করি")
                }
            }
        )
    }

    if (showEmpty) {
        AlertDialog(
            onDismissRequest = { showEmpty = false },
            icon = { Icon(Icons.Default.Edit, contentDescription = "Empty", tint = Color(0xFFFF5722), modifier = Modifier.size(48.dp)) },
            title = { Text("সোনামণি কিছু লেখোনি! ✏️") },
            text = { Text("নিচে সাদা জায়গায় অক্ষরটি লেখো।") },
            confirmButton = {
                Button(
                    onClick = { 
                        showEmpty = false
                        paths = emptyList()
                        strokeLength = 0f
                        minX = Float.MAX_VALUE
                        maxX = Float.MIN_VALUE
                        minY = Float.MAX_VALUE
                        maxY = Float.MIN_VALUE
                        startTime = 0L
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF5722))
                ) {
                    Text("চলো লিখি")
                }
            }
        )
    }

    if (showError) {
        AlertDialog(
            onDismissRequest = { showError = false },
            icon = { Icon(Icons.Default.Edit, contentDescription = "Error", tint = Color(0xFFFF5722), modifier = Modifier.size(48.dp)) },
            title = { Text("আরো চেষ্টা করো সোনামণি! 💕") },
            text = { Text("উপরের অক্ষরটা ভালো করে দেখো, তারপর আস্তে আস্তে আঁকো।") },
            confirmButton = {
                Button(
                    onClick = { 
                        showError = false
                        paths = emptyList()
                        strokeLength = 0f
                        minX = Float.MAX_VALUE
                        maxX = Float.MIN_VALUE
                        minY = Float.MAX_VALUE
                        maxY = Float.MIN_VALUE
                        startTime = 0L
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF5722))
                ) {
                    Text("আবার চেষ্টা করি 🖊️")
                }
            }
        )
    }
}
