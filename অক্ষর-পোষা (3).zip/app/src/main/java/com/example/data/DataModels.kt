package com.example.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "user_progress")
data class UserProgress(
    @PrimaryKey val id: Int = 1,
    val xp: Int = 0,
    val level: Int = 1,
    val isPremium: Boolean = false,
    val currentPet: String = "🐯",
    val currentOutfit: String = "সাধারণ",
    val currentRoom: String = "সাধারণ",
    val foodCount: Int = 0,
    val happiness: Int = 80,
    val unlockedPets: String = "🐯",
    val unlockedOutfits: String = "সাধারণ",
    val unlockedRooms: String = "সাধারণ",
    val name: String = "সোনামণি",
    val age: String = "৫",
    val avatar: String = "👦",
    val streak: Int = 0,
    val lastPlayedDate: Long = 0,
    val learnedLetters: Int = 0,
    val lastQuizTime: Long = 0L,
    val quizScore: Int = 0,
    val todayQuizIndex: Int = 0
)

@Entity(tableName = "game_history")
data class GameHistory(
    @PrimaryKey val dateString: String, // "yyyy-MM-dd"
    val score: Int = 0,
    val totalGames: Int = 5,
    val timestamp: Long = System.currentTimeMillis()
)

@Dao
interface UserProgressDao {
    @Query("SELECT * FROM user_progress WHERE id = 1")
    fun getProgress(): Flow<UserProgress?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProgress(progress: UserProgress)

    @Query("UPDATE user_progress SET xp = xp + :gainedXp, level = :newLevel WHERE id = 1")
    suspend fun updateXpAndLevel(gainedXp: Int, newLevel: Int)
}

@Dao
interface GameHistoryDao {
    @Query("SELECT * FROM game_history ORDER BY timestamp DESC LIMIT 7")
    fun getRecentHistory(): Flow<List<GameHistory>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHistory(history: GameHistory)
    
    @Query("SELECT SUM(totalGames) FROM game_history")
    fun getTotalGamesPlayed(): Flow<Int?>
    
    @Query("SELECT SUM(score) FROM game_history")
    fun getTotalCorrectAnswers(): Flow<Int?>
    
    @Query("SELECT * FROM game_history WHERE dateString = :dateStr LIMIT 1")
    suspend fun getHistoryByDate(dateStr: String): GameHistory?
}

@Database(entities = [UserProgress::class, GameHistory::class], version = 5, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userProgressDao(): UserProgressDao
    abstract fun gameHistoryDao(): GameHistoryDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "akshor_posha_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}

class ProgressRepository(
    private val progressDao: UserProgressDao,
    private val gameHistoryDao: GameHistoryDao
) {
    val progressFlow: Flow<UserProgress?> = progressDao.getProgress()
    val recentHistoryFlow: Flow<List<GameHistory>> = gameHistoryDao.getRecentHistory()
    val totalGamesFlow: Flow<Int?> = gameHistoryDao.getTotalGamesPlayed()
    val totalScoreFlow: Flow<Int?> = gameHistoryDao.getTotalCorrectAnswers()

    suspend fun initializeProgress() {
        progressDao.insertProgress(UserProgress())
    }

    suspend fun updateProgress(progress: UserProgress) {
        progressDao.insertProgress(progress)
    }

    suspend fun addXp(amount: Int, currentXp: Int) {
        val newXp = currentXp + amount
        val newLevel = calculateLevel(newXp)
        progressDao.updateXpAndLevel(amount, newLevel)
    }

    private fun calculateLevel(xp: Int): Int {
        return (xp / 10) + 1
    }
    
    suspend fun saveGameResult(dateStr: String, score: Int, total: Int) {
        val existing = gameHistoryDao.getHistoryByDate(dateStr)
        if (existing != null) {
            gameHistoryDao.insertHistory(existing.copy(
                score = existing.score + score,
                totalGames = existing.totalGames + total,
                timestamp = System.currentTimeMillis()
            ))
        } else {
            gameHistoryDao.insertHistory(GameHistory(dateString = dateStr, score = score, totalGames = total))
        }
    }
}
