import re

with open('./app/src/main/java/com/example/ui/CategoryDetailScreen.kt', 'r') as f:
    content = f.read()

# Replace getEmojiForLetter with getLetterDetails
new_helpers = """data class LetterDetails(val emoji: String, val bnName: String, val enName: String? = null)

fun getLetterDetails(letter: String): LetterDetails {
    return when (letter) {
        // English Capitals
        "A" -> LetterDetails("🍎", "আপেল", "Apple")
        "B" -> LetterDetails("⚽", "বল", "Ball")
        "C" -> LetterDetails("🐱", "বিড়াল", "Cat")
        "D" -> LetterDetails("🐶", "কুকুর", "Dog")
        "E" -> LetterDetails("🐘", "হাতি", "Elephant")
        "F" -> LetterDetails("🐟", "মাছ", "Fish")
        "G" -> LetterDetails("🍇", "আঙুর", "Grapes")
        "H" -> LetterDetails("🏠", "বাড়ি", "House")
        "I" -> LetterDetails("🍦", "আইসক্রিম", "Ice cream")
        "J" -> LetterDetails("🤹", "জাদু", "Juggle")
        "K" -> LetterDetails("🪁", "ঘুড়ি", "Kite")
        "L" -> LetterDetails("🦁", "সিংহ", "Lion")
        "M" -> LetterDetails("🌙", "চাঁদ", "Moon")
        "N" -> LetterDetails("📓", "খাতা", "Notebook")
        "O" -> LetterDetails("🍊", "কমলা", "Orange")
        "P" -> LetterDetails("🐧", "পেঙ্গুইন", "Penguin")
        "Q" -> LetterDetails("👸", "রানি", "Queen")
        "R" -> LetterDetails("🌹", "গোলাপ", "Rose")
        "S" -> LetterDetails("☀️", "সূর্য", "Sun")
        "T" -> LetterDetails("🐯", "বাঘ", "Tiger")
        "U" -> LetterDetails("☂️", "ছাতা", "Umbrella")
        "V" -> LetterDetails("🎻", "বেহালা", "Violin")
        "W" -> LetterDetails("🐋", "তিমি", "Whale")
        "X" -> LetterDetails("🎸", "জাইলোফোন", "Xylophone")
        "Y" -> LetterDetails("🪀", "ইয়ো-ইয়ো", "Yo-yo")
        "Z" -> LetterDetails("🦓", "জেব্রা", "Zebra")

        // Bengali Vowels
        "অ" -> LetterDetails("🦆", "অজগর", null)
        "আ" -> LetterDetails("🥭", "আম", null)
        "ই" -> LetterDetails("🐭", "ইঁদুর", null)
        "ঈ" -> LetterDetails("🦅", "ঈগল", null)
        "উ" -> LetterDetails("🐪", "উট", null)
        "ঊ" -> LetterDetails("🌊", "ঊর্মি", null)
        "ঋ" -> LetterDetails("🐻", "ঋক্ষ", null)
        "এ" -> LetterDetails("✏️", "এক", null)
        "ঐ" -> LetterDetails("🪞", "ঐনা", null)
        "ও" -> LetterDetails("💊", "ওষুধ", null)
        "ঔ" -> LetterDetails("🌿", "ঔষধ", null)

        // Numbers
        "১" -> LetterDetails("☝️", "এক", null)
        "২" -> LetterDetails("✌️", "দুই", null)
        "৩" -> LetterDetails("🤟", "তিন", null)
        "৪" -> LetterDetails("🖖", "চার", null)
        "৫" -> LetterDetails("🖐️", "পাঁচ", null)
        "৬" -> LetterDetails("🕕", "ছয়", null)
        "৭" -> LetterDetails("🕖", "সাত", null)
        "৮" -> LetterDetails("🕗", "আট", null)
        "৯" -> LetterDetails("🕘", "নয়", null)
        "১০" -> LetterDetails("🔟", "দশ", null)
        
        else -> LetterDetails("🌟", "শেখা", null)
    }
}

fun convertToBengaliNumber"""

content = re.sub(r'fun getEmojiForLetter.*?fun convertToBengaliNumber', new_helpers, content, flags=re.DOTALL)

# Replace LetterTile
new_letter_tile = """@Composable
fun LetterTile(
    letter: String,
    isTtsReady: Boolean,
    onPractice: () -> Unit,
    onSpeak: () -> Unit
) {
    val details = getLetterDetails(letter)
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(0.7f)
            .clickable { onSpeak() },
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(2.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = letter,
                    fontSize = 80.sp,
                    fontWeight = FontWeight.Black,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(text = details.emoji, fontSize = 48.sp)
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = details.bnName,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = androidx.compose.ui.graphics.Color(0xFF4CAF50) // Green
                )
                if (details.enName != null) {
                    Text(
                        text = details.enName,
                        fontSize = 16.sp,
                        color = androidx.compose.ui.graphics.Color.Gray
                    )
                }
            }
            
            // Actions Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.primaryContainer)
                    .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                IconButton(onClick = onSpeak) {
                    Icon(
                        imageVector = if (isTtsReady) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                        contentDescription = "শুনুন",
                        tint = if (isTtsReady) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                        modifier = Modifier.size(32.dp)
                    )
                }
                IconButton(onClick = onPractice) {
                    Icon(
                        imageVector = Icons.Default.Create,
                        contentDescription = "লিখুন",
                        tint = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.size(32.dp)
                    )
                }
            }
        }
    }
}"""

content = re.sub(r'@Composable\nfun LetterTile\(.*?\}\n\}', new_letter_tile, content, flags=re.DOTALL)

with open('./app/src/main/java/com/example/ui/CategoryDetailScreen.kt', 'w') as f:
    f.write(content)
