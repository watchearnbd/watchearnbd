import re

with open('./app/src/main/java/com/example/ui/CategoryDetailScreen.kt', 'r') as f:
    content = f.read()

new_letter_tile = """@Composable
fun LetterTile(
    letter: String,
    isTtsReady: Boolean,
    onPractice: () -> Unit,
    onSpeak: () -> Unit
) {
    val details = getLetterDetails(letter)
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(0.7f)
            .clickable { onSpeak() },
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(2.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = letter,
                    fontSize = 80.sp,
                    fontWeight = FontWeight.Black,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(text = details.emoji, fontSize = 48.sp)
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = details.bnName,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = androidx.compose.ui.graphics.Color(0xFF4CAF50)
                )
                if (details.enName != null) {
                    Text(
                        text = details.enName,
                        fontSize = 16.sp,
                        color = androidx.compose.ui.graphics.Color.Gray
                    )
                }
            }
            
            // Actions Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.primaryContainer)
                    .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                IconButton(onClick = onSpeak) {
                    Icon(
                        imageVector = if (isTtsReady) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                        contentDescription = "শুনুন",
                        tint = if (isTtsReady) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                        modifier = Modifier.size(32.dp)
                    )
                }
                IconButton(onClick = onPractice) {
                    Icon(
                        imageVector = Icons.Default.Create,
                        contentDescription = "লিখুন",
                        tint = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.size(32.dp)
                    )
                }
            }
        }
    }
}"""

content = re.sub(r'@Composable\s*fun LetterTile.*?\}\s*\}\s*\}', new_letter_tile, content, flags=re.DOTALL)

with open('./app/src/main/java/com/example/ui/CategoryDetailScreen.kt', 'w') as f:
    f.write(content)
