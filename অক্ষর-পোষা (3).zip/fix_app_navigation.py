with open('/app/applet/app/src/main/java/com/example/ui/AppNavigation.kt', 'r') as f:
    content = f.read()

new_composable = """            composable("learning/{letter}") { backStackEntry ->
                val letter = backStackEntry.arguments?.getString("letter") ?: "অ"
                if (letter.startsWith("namata_")) {
                    val numberStr = letter.removePrefix("namata_")
                    NamataDetailScreen(
                        numberStr = numberStr,
                        onNavigateBack = { navController.popBackStack() }
                    )
                } else {
                    LearningScreen(
                        letter = letter,
                        viewModel = viewModel,
                        onNavigateBack = { navController.popBackStack() }
                    )
                }
            }"""

content = content.replace("""            composable("learning/{letter}") { backStackEntry ->
                val letter = backStackEntry.arguments?.getString("letter") ?: "অ"
                LearningScreen(
                    letter = letter,
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }""", new_composable)

with open('/app/applet/app/src/main/java/com/example/ui/AppNavigation.kt', 'w') as f:
    f.write(content)
