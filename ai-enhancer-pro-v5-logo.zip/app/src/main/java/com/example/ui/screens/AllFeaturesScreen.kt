package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AllFeaturesScreen(onBack: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("All Features") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("Here are all the amazing features you can use:")
            AIFeatureItem(icon = "✨", label = "Enhance Resolution")
            AIFeatureItem(icon = "🚀", label = "AI Upscale (2x/4x)")
            AIFeatureItem(icon = "🛠️", label = "Restore Old Photos")
            AIFeatureItem(icon = "🎨", label = "Colorize Black & White")
            AIFeatureItem(icon = "👤", label = "Portrait Beautify")
            AIFeatureItem(icon = "🌌", label = "Night Mode Enhancement")
        }
    }
}
