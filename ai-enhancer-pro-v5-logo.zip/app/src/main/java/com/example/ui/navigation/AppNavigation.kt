package com.example.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ui.components.BottomNavBar
import com.example.ui.screens.*

@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination?.route
    
    val showBottomBar = currentDestination == HomeRoute ||
            currentDestination == HistoryRoute ||
            currentDestination == PremiumRoute ||
            currentDestination == ProfileRoute

    Scaffold(
        bottomBar = {
            if (showBottomBar) {
                BottomNavBar(navController)
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = SplashRoute,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(SplashRoute) {
                SplashScreen(onNavigateToLogin = {
                    navController.navigate(LoginRoute) {
                        popUpTo(SplashRoute) { inclusive = true }
                    }
                })
            }
            composable(LoginRoute) {
                LoginScreen(onLoginSuccess = {
                    navController.navigate(HomeRoute) {
                        popUpTo(LoginRoute) { inclusive = true }
                    }
                })
            }
            composable(HomeRoute) {
                HomeScreen(
                    onPhotoSelected = { uri, feature -> 
                        navController.navigate("processing/${android.net.Uri.encode(uri)}/$feature")
                    },
                    onNavigateToPremium = { navController.navigate(PremiumRoute) },
                    onNavigateToAllFeatures = { navController.navigate(AllFeaturesRoute) },
                    onNavigateToHistoryItem = { resultUri -> 
                        navController.navigate("result/${android.net.Uri.encode(resultUri)}")
                    }
                )
            }
            composable(AllFeaturesRoute) {
                AllFeaturesScreen(onBack = { navController.popBackStack() })
            }
            // UploadRoute is bypassed from Home, but keeping it in case
            composable(UploadRoute) {
                UploadScreen(
                    onBack = { navController.popBackStack() },
                    onPhotoSelected = { uri -> 
                        navController.navigate("preview/${android.net.Uri.encode(uri)}") 
                    }
                )
            }
            composable(
                route = PreviewRoute,
                arguments = listOf(androidx.navigation.navArgument("imageUri") { type = androidx.navigation.NavType.StringType })
            ) { backStackEntry ->
                val imageUri = backStackEntry.arguments?.getString("imageUri") ?: ""
                PreviewScreen(
                    imageUri = imageUri,
                    onBack = { navController.popBackStack() },
                    onStartEnhance = { feature -> navController.navigate("processing/${android.net.Uri.encode(imageUri)}/$feature") }
                )
            }
            composable(
                route = ProcessingRoute,
                arguments = listOf(
                    androidx.navigation.navArgument("imageUri") { type = androidx.navigation.NavType.StringType },
                    androidx.navigation.navArgument("feature") { type = androidx.navigation.NavType.StringType }
                )
            ) { backStackEntry ->
                val imageUri = backStackEntry.arguments?.getString("imageUri") ?: ""
                val feature = backStackEntry.arguments?.getString("feature") ?: "enhance"
                ProcessingScreen(
                    imageUri = imageUri,
                    feature = feature,
                    onProcessComplete = { resultUri ->
                        navController.navigate("result/${android.net.Uri.encode(resultUri)}") {
                            popUpTo(ProcessingRoute) { inclusive = true }
                        }
                    }
                )
            }
            composable(
                route = ResultRoute,
                arguments = listOf(androidx.navigation.navArgument("imageUri") { type = androidx.navigation.NavType.StringType })
            ) { backStackEntry ->
                val resultUri = backStackEntry.arguments?.getString("imageUri") ?: ""
                ResultScreen(
                    resultUri = resultUri,
                    onBack = { navController.popBackStack() },
                    onHome = {
                        navController.navigate(HomeRoute) {
                            popUpTo(HomeRoute) { inclusive = true }
                        }
                    }
                )
            }
            composable(HistoryRoute) {
                HistoryScreen()
            }
            composable(PremiumRoute) {
                PremiumScreen()
            }
            composable(ProfileRoute) {
                ProfileScreen(onNavigateToSettings = { navController.navigate(SettingsRoute) }, onNavigateToPremium = { navController.navigate(PremiumRoute) })
            }
            composable(SettingsRoute) {
                SettingsScreen(onBack = { navController.popBackStack() })
            }
        }
    }
}
