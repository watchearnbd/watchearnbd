package com.example.ui.navigation

const val SplashRoute = "splash"
const val LoginRoute = "login"
const val HomeRoute = "home"
const val UploadRoute = "upload"
const val PreviewRoute = "preview/{imageUri}"
const val ProcessingRoute = "processing/{imageUri}/{feature}"
const val ResultRoute = "result/{imageUri}"
const val HistoryRoute = "history"
const val PremiumRoute = "premium"
const val ProfileRoute = "profile"

const val AllFeaturesRoute = "all_features"
const val SettingsRoute = "settings"
