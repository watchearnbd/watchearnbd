package com.example.ui.screens

import androidx.compose.foundation.clickable
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.EnhancerApp
import com.example.ui.components.MockAdBanner
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PremiumScreen() {
    val context = LocalContext.current
    val app = context.applicationContext as EnhancerApp
    val isPremium by app.userManager.isPremium.collectAsState()
    val coroutineScope = rememberCoroutineScope()
    var isPurchasing by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Premium", fontWeight = FontWeight.Bold) })
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                Icons.Default.Star,
                contentDescription = null,
                modifier = Modifier.size(80.dp),
                tint = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = if (isPremium) "You are a Premium Member!" else "Upgrade to Premium",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = if (isPremium) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onBackground
            )
            Spacer(modifier = Modifier.height(32.dp))
            PremiumFeatureItem("No Ads Experience")
            PremiumFeatureItem("Faster Processing Times")
            PremiumFeatureItem("HD & 4K Export Quality")
            PremiumFeatureItem("Unlimited Enhancements")
            
            Spacer(modifier = Modifier.height(32.dp))
            
            if (!isPremium) {
                Button(
                    onClick = {
                        coroutineScope.launch {
                            isPurchasing = true
                            delay(1500) // Simulate network call for Google Play Billing
                            app.userManager.setPremium(true)
                            isPurchasing = false
                            Toast.makeText(context, "Subscription successful! Welcome to Premium.", Toast.LENGTH_SHORT).show()
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    enabled = !isPurchasing
                ) {
                    if (isPurchasing) {
                        CircularProgressIndicator(modifier = Modifier.size(24.dp), color = MaterialTheme.colorScheme.onPrimary)
                    } else {
                        Text("Get Premium - $4.99/mo", style = MaterialTheme.typography.titleMedium)
                    }
                }
            } else {
                OutlinedButton(
                    onClick = {
                        app.userManager.setPremium(false)
                        Toast.makeText(context, "Subscription cancelled.", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.fillMaxWidth().height(56.dp)
                ) {
                    Text("Manage Subscription (Cancel)", style = MaterialTheme.typography.titleMedium)
                }
            }
        }
    }
}

@Composable
fun PremiumFeatureItem(text: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Default.Check, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        Spacer(modifier = Modifier.width(16.dp))
        Text(text, style = MaterialTheme.typography.bodyLarge)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(onNavigateToSettings: () -> Unit, onNavigateToPremium: () -> Unit) {
    val context = LocalContext.current
    val app = context.applicationContext as EnhancerApp
    val credits by app.userManager.credits.collectAsState()
    val isPremium by app.userManager.isPremium.collectAsState()
    val coroutineScope = rememberCoroutineScope()
    var isWatchingAd by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Profile", fontWeight = FontWeight.Bold) })
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(100.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Text("JD", style = MaterialTheme.typography.headlineLarge, color = MaterialTheme.colorScheme.onPrimaryContainer)
                }
                Spacer(modifier = Modifier.height(16.dp))
                // Simulated Firebase Auth Data
                Text("John Doe", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("john.doe@example.com", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (isPremium) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        color = MaterialTheme.colorScheme.tertiaryContainer,
                        shape = CircleShape
                    ) {
                        Text("PREMIUM MEMBER", modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onTertiaryContainer)
                    }
                }
            }
            
            Card(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Available Credits", style = MaterialTheme.typography.labelLarge)
                        Text(if(isPremium) "Unlimited" else "$credits Credits", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    }
                    if (!isPremium) {
                        Button(
                            onClick = { 
                                coroutineScope.launch {
                                    isWatchingAd = true
                                    Toast.makeText(context, "Playing Video Ad...", Toast.LENGTH_SHORT).show()
                                    delay(2000) // Simulate ad watching time
                                    app.userManager.addCredit(1)
                                    isWatchingAd = false
                                    Toast.makeText(context, "Reward Granted: +1 Credit!", Toast.LENGTH_SHORT).show()
                                }
                            }, 
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                            enabled = !isWatchingAd
                        ) {
                            if (isWatchingAd) {
                                CircularProgressIndicator(modifier = Modifier.size(16.dp), color = MaterialTheme.colorScheme.onSecondary, strokeWidth = 2.dp)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Watching...")
                            } else {
                                Icon(Icons.Default.PlayArrow, contentDescription = null)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Watch Ad for +1")
                            }
                        }
                    }
                }
            }
            if (!isPremium) {
                MockAdBanner(type = "Native Ad", modifier = Modifier.padding(16.dp))
            }
            ProfileMenuItem(Icons.Default.CreditCard, "Subscription", onClick = onNavigateToPremium)
            ProfileMenuItem(Icons.Default.Settings, "Settings", onClick = onNavigateToSettings)
        }
    }
}

@Composable
fun ProfileMenuItem(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String, onClick: () -> Unit = {}) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(modifier = Modifier.width(16.dp))
        Text(text, style = MaterialTheme.typography.bodyLarge)
    }
}
