package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(onBack: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("App Settings", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            
            ListItem(headlineContent = { Text("Notifications") }, supportingContent = { Text("Manage alerts and sounds") })
            ListItem(headlineContent = { Text("Theme") }, supportingContent = { Text("System Default (Dark Mode)") })
            ListItem(headlineContent = { Text("Language") }, supportingContent = { Text("English (US)") })
            
            Divider()
            
            Text("Account", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            ListItem(headlineContent = { Text("Log Out") }, colors = ListItemDefaults.colors(headlineColor = MaterialTheme.colorScheme.primary))
            ListItem(headlineContent = { Text("Delete Account") }, colors = ListItemDefaults.colors(headlineColor = MaterialTheme.colorScheme.error))
        }
    }
}
