package com.example.ui.screens

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import android.graphics.Shader
import android.net.Uri
import android.widget.Toast
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.tensorflow.lite.DataType
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.support.common.ops.CastOp
import org.tensorflow.lite.support.image.ImageProcessor
import org.tensorflow.lite.support.image.TensorImage
import org.tensorflow.lite.support.tensorbuffer.TensorBuffer
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.channels.FileChannel
import kotlin.math.ceil
import kotlin.math.min

class ProcessingViewModel : ViewModel() {

    private val _uiState = MutableStateFlow<ProcessingState>(ProcessingState.Loading(0f))
    val uiState: StateFlow<ProcessingState> = _uiState

    // 1. Tiling configuration
    private val TILE_SIZE = 256
    private val OVERLAP = 32
    private val SCALE = 4
    
    private var interpreter: Interpreter? = null
    private var lastInputWidth = -1
    private var lastInputHeight = -1

    private fun getInterpreter(context: Context): Interpreter {
        if (interpreter == null) {
            val assetFileDescriptor = context.assets.openFd("ml/esrgan.tflite")
            val fileInputStream = FileInputStream(assetFileDescriptor.fileDescriptor)
            val fileChannel = fileInputStream.channel
            val startOffset = assetFileDescriptor.startOffset
            val declaredLength = assetFileDescriptor.declaredLength
            val mappedByteBuffer = fileChannel.map(FileChannel.MapMode.READ_ONLY, startOffset, declaredLength)
            
            val options = Interpreter.Options()
            options.setNumThreads(4)
            interpreter = Interpreter(mappedByteBuffer, options)
        }
        return interpreter!!
    }

    override fun onCleared() {
        super.onCleared()
        interpreter?.close()
        interpreter = null
        lastInputWidth = -1
        lastInputHeight = -1
    }

    // 3. Background-safe processing using viewModelScope and Dispatchers.IO
    fun startProcessing(context: Context, imageUri: String, feature: String) {
        viewModelScope.launch(Dispatchers.IO) {
            _uiState.value = ProcessingState.Loading(0.01f)
            
            try {
                // Ensure model is available
                try {
                    getInterpreter(context)
                } catch (e: Exception) {
                    _uiState.value = ProcessingState.Error("Failed to load on-device AI model.")
                    return@launch
                }

                val uri = Uri.parse(imageUri)
                val inputStream = context.contentResolver.openInputStream(uri)
                val originalBitmap = BitmapFactory.decodeStream(inputStream)
                inputStream?.close()

                if (originalBitmap == null) {
                    _uiState.value = ProcessingState.Error("Failed to decode image.")
                    return@launch
                }

                val width = originalBitmap.width
                val height = originalBitmap.height

                // 5. Alert if image is too small
                if (width < 200 || height < 200) {
                    withContext(Dispatchers.Main) {
                        Toast.makeText(context, "Image is very small. Enhancement results may be limited.", Toast.LENGTH_LONG).show()
                    }
                }

                // 2. Memory management for large images
                if (width * SCALE > 8000 || height * SCALE > 8000) {
                     withContext(Dispatchers.Main) {
                        Toast.makeText(context, "Large image detected. Processing may take longer.", Toast.LENGTH_SHORT).show()
                    }
                }

                val outWidth = width * SCALE
                val outHeight = height * SCALE
                
                // Safe allocation for large output bitmap
                val resultBitmap = try {
                    Bitmap.createBitmap(outWidth, outHeight, Bitmap.Config.ARGB_8888)
                } catch(e: OutOfMemoryError) {
                    _uiState.value = ProcessingState.Error("Image is too large to process (Out of Memory).")
                    return@launch
                }
                
                val canvas = Canvas(resultBitmap)
                
                val step = TILE_SIZE - OVERLAP
                val xTiles = ceil(width.toDouble() / step).toInt()
                val yTiles = ceil(height.toDouble() / step).toInt()
                val totalTiles = xTiles * yTiles
                var processedTiles = 0

                val paint = Paint(Paint.ANTI_ALIAS_FLAG)

                val startTimeOverall = System.currentTimeMillis()
                val timeoutMs = 90_000L

                for (y in 0 until height step step) {
                    for (x in 0 until width step step) {
                        if (System.currentTimeMillis() - startTimeOverall > timeoutMs) {
                            resultBitmap.recycle()
                            originalBitmap.recycle()
                            _uiState.value = ProcessingState.Error("Processing timed out (took longer than 90 seconds). Try a smaller image.")
                            return@launch
                        }

                        // Extract tile with boundaries
                        val tileW = min(TILE_SIZE, width - x)
                        val tileH = min(TILE_SIZE, height - y)
                        
                        val tile = Bitmap.createBitmap(originalBitmap, x, y, tileW, tileH)
                        
                        val startTimeTile = System.currentTimeMillis()
                        // 1. Run on-device inference
                        val enhancedTile = runTFLiteInference(context, tile)
                        val endTimeTile = System.currentTimeMillis()
                        android.util.Log.d("ProcessingViewModel", "Tile ($x, $y) processed in ${endTimeTile - startTimeTile} ms")
                        
                        // Calculate output position
                        val outX = x * SCALE
                        val outY = y * SCALE
                        
                        val srcRect = Rect(0, 0, enhancedTile.width, enhancedTile.height)
                        val dstRect = Rect(outX, outY, outX + enhancedTile.width, outY + enhancedTile.height)
                        
                        // 1. Feather blending for seamless overlap
                        if (x > 0 || y > 0) {
                            applyFeatherMask(enhancedTile, OVERLAP * SCALE)
                        }
                        
                        // Draw onto the main canvas
                        canvas.drawBitmap(enhancedTile, srcRect, dstRect, paint)
                        
                        tile.recycle()
                        enhancedTile.recycle()
                        
                        processedTiles++
                        
                        // 2. Realistic progress update
                        val progress = (processedTiles.toFloat() / totalTiles.toFloat()) * 0.95f
                        _uiState.value = ProcessingState.Loading(progress)
                    }
                }

                // Save result
                val file = File(context.cacheDir, "enhanced_${System.currentTimeMillis()}.jpg")
                val out = FileOutputStream(file)
                resultBitmap.compress(Bitmap.CompressFormat.JPEG, 95, out)
                out.close()
                val app = context.applicationContext as com.example.EnhancerApp
                app.userManager.deductCredit()
                val historyItem = com.example.data.local.HistoryEntity(originalImageUri = imageUri, enhancedImageUri = android.net.Uri.fromFile(file).toString(), timestamp = System.currentTimeMillis(), feature = feature)
                app.database.historyDao().insertHistory(historyItem)
                resultBitmap.recycle()
                originalBitmap.recycle()

                _uiState.value = ProcessingState.Success(Uri.fromFile(file).toString())
                
            } catch (e: Exception) {
                e.printStackTrace()
                _uiState.value = ProcessingState.Error(e.message ?: "Error processing image")
            }
        }
    }

    // Applies a feather mask to blend overlapping edges
    private fun applyFeatherMask(bitmap: Bitmap, overlapPixels: Int) {
        val canvas = Canvas(bitmap)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
        }
        
        // Simple linear gradient mask for the overlap region
        val gradient = LinearGradient(
            0f, 0f, overlapPixels.toFloat(), overlapPixels.toFloat(),
            Color.TRANSPARENT, Color.BLACK,
            Shader.TileMode.CLAMP
        )
        paint.shader = gradient
        canvas.drawRect(0f, 0f, bitmap.width.toFloat(), bitmap.height.toFloat(), paint)
    }

    private fun runTFLiteInference(context: Context, input: Bitmap): Bitmap {
        val tflite = getInterpreter(context)
        
        // Resize interpreter input tensor dynamically for this tile
        if (lastInputWidth != input.width || lastInputHeight != input.height) {
            tflite.resizeInput(0, intArrayOf(1, input.height, input.width, 3))
            tflite.allocateTensors()
            lastInputWidth = input.width
            lastInputHeight = input.height
        }
        
        val inputDataType = tflite.getInputTensor(0).dataType()
        val inputImage = TensorImage(inputDataType)
        inputImage.load(input)
        
        // Models usually expect FLOAT32 for ESRGAN
        val imageProcessor = ImageProcessor.Builder()
            .add(CastOp(DataType.FLOAT32))
            .build()
        val processedInput = imageProcessor.process(inputImage)

        val outputDataType = tflite.getOutputTensor(0).dataType()
        val outputBuffer = TensorBuffer.createFixedSize(
            intArrayOf(1, input.height * SCALE, input.width * SCALE, 3), 
            outputDataType
        )
        
        tflite.run(processedInput.buffer, outputBuffer.buffer.rewind())
        
        val outputImage = TensorImage(outputDataType)
        outputImage.load(outputBuffer)
        
        val outputProcessor = ImageProcessor.Builder()
            .add(CastOp(DataType.UINT8))
            .build()
        
        return outputProcessor.process(outputImage).bitmap
    }
}

sealed class ProcessingState {
    data class Loading(val progress: Float) : ProcessingState()
    data class Success(val resultUrl: String) : ProcessingState()
    data class Error(val message: String) : ProcessingState()
}
