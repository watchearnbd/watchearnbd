package com.example

import android.app.Application
import com.example.data.local.AppDatabase
import com.example.data.local.UserManager

class EnhancerApp : Application() {
    val database: AppDatabase by lazy { AppDatabase.getDatabase(this) }
    val userManager: UserManager by lazy { UserManager(this) }
}
