package com.example.data.local

import android.content.Context
import androidx.core.content.edit
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class UserManager(private val context: Context) {
    private val prefs = context.getSharedPreferences("user_prefs", Context.MODE_PRIVATE)

    private val _credits = MutableStateFlow(prefs.getInt("credits", 12))
    val credits: StateFlow<Int> = _credits.asStateFlow()

    private val _isPremium = MutableStateFlow(prefs.getBoolean("is_premium", false))
    val isPremium: StateFlow<Boolean> = _isPremium.asStateFlow()

    fun deductCredit() {
        if (_isPremium.value) return
        if (_credits.value > 0) {
            val newCredits = _credits.value - 1
            prefs.edit { putInt("credits", newCredits) }
            _credits.value = newCredits
        }
    }

    fun addCredit(amount: Int) {
        val newCredits = _credits.value + amount
        prefs.edit { putInt("credits", newCredits) }
        _credits.value = newCredits
    }

    fun setPremium(premium: Boolean) {
        prefs.edit { putBoolean("is_premium", premium) }
        _isPremium.value = premium
    }
}
