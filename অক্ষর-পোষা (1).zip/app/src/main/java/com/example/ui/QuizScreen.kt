package com.example.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun QuizScreen(viewModel: MainViewModel) {
    Scaffold(
        containerColor = DarkBg,
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Default.SportsEsports,
                contentDescription = "Games",
                tint = TextYellow,
                modifier = Modifier.size(100.dp)
            )
            Spacer(modifier = Modifier.height(24.dp))
            Text(
                text = "অন্য গেম",
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                color = TextYellow
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "নতুন গেম খুব শীঘ্রই আসছে!",
                fontSize = 18.sp,
                color = Color.LightGray
            )
        }
    }
}