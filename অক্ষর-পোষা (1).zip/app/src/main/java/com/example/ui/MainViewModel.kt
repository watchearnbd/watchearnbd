package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.ProgressRepository
import com.example.data.UserProgress
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Calendar

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getDatabase(application)
    private val repository = ProgressRepository(database.userProgressDao())

    val uiState: StateFlow<UserProgress?> = repository.progressFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = null
        )

    init {
        viewModelScope.launch {
            // Wait for uiState to be collected briefly, if null then initialize
            repository.initializeProgress()
            updateStreak()
        }
    }
    
    private suspend fun updateStreak() {
        val state = repository.progressFlow.stateIn(viewModelScope).value ?: return
        val currentDay = getTodayStartOfDay()
        
        val newStreak = if (state.lastPlayedDate == 0L) {
            1
        } else if (state.lastPlayedDate == currentDay) {
            state.streak // already played today
        } else if (state.lastPlayedDate == currentDay - 86400000L) {
            state.streak + 1 // played yesterday
        } else {
            1 // streak broken
        }
        
        repository.updateProgress(state.copy(streak = newStreak, lastPlayedDate = currentDay))
    }
    
    private fun getTodayStartOfDay(): Long {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }

    fun completeLesson() {
        viewModelScope.launch {
            val currentState = uiState.value ?: return@launch
            repository.addXp(25, currentState.xp)
            // 1 letter learned = +1 food, +1 learned letters
            val updated = currentState.copy(
                xp = currentState.xp + 25,
                level = ((currentState.xp + 25) / 10) + 1,
                foodCount = currentState.foodCount + 1,
                happiness = (currentState.happiness + 5).coerceAtMost(100),
                learnedLetters = currentState.learnedLetters + 1
            )
            repository.updateProgress(updated)
            updateStreak()
        }
    }

    fun feedPet() {
        viewModelScope.launch {
            val state = uiState.value ?: return@launch
            if (state.foodCount > 0) {
                val updated = state.copy(
                    foodCount = state.foodCount - 1,
                    happiness = (state.happiness + 10).coerceAtMost(100)
                )
                repository.updateProgress(updated)
            }
        }
    }

    fun setPet(pet: String) {
        viewModelScope.launch {
            val state = uiState.value ?: return@launch
            if (state.unlockedPets.contains(pet)) {
                repository.updateProgress(state.copy(currentPet = pet))
            }
        }
    }

    fun setOutfit(outfit: String) {
        viewModelScope.launch {
            val state = uiState.value ?: return@launch
            if (state.unlockedOutfits.contains(outfit)) {
                repository.updateProgress(state.copy(currentOutfit = outfit))
            }
        }
    }

    fun setRoom(roomName: String) {
        viewModelScope.launch {
            val state = uiState.value ?: return@launch
            if (state.unlockedRooms.contains(roomName)) {
                repository.updateProgress(state.copy(currentRoom = roomName))
            }
        }
    }
    
    fun updateProfile(name: String, age: String, avatar: String) {
        viewModelScope.launch {
            val state = uiState.value ?: return@launch
            repository.updateProgress(state.copy(name = name, age = age, avatar = avatar))
        }
    }

    fun submitQuizAnswer(isCorrect: Boolean) {
        viewModelScope.launch {
            val state = uiState.value ?: return@launch
            val newScore = if (isCorrect) state.quizScore + 10 else state.quizScore
            val newIndex = state.todayQuizIndex + 1
            
            val updated = state.copy(
                quizScore = newScore,
                todayQuizIndex = newIndex,
                lastQuizTime = if (newIndex >= 5) System.currentTimeMillis() else state.lastQuizTime,
                xp = if (isCorrect) state.xp + 10 else state.xp,
                level = if (isCorrect) ((state.xp + 10) / 10) + 1 else state.level
            )
            repository.updateProgress(updated)
            updateStreak()
        }
    }
    
    fun checkAndResetQuiz() {
        viewModelScope.launch {
            val state = uiState.value ?: return@launch
            if (state.todayQuizIndex >= 5) {
                val currentTime = System.currentTimeMillis()
                val diffHours = (currentTime - state.lastQuizTime) / (1000 * 60 * 60)
                if (diffHours >= 12) {
                    val updated = state.copy(todayQuizIndex = 0, quizScore = 0)
                    repository.updateProgress(updated)
                }
            }
        }
    }

    fun testModeUnlockAll() {
        viewModelScope.launch {
            val state = uiState.value ?: return@launch
            val updated = state.copy(
                unlockedPets = "🐯,🐶,🐱,🐼,🦊",
                unlockedOutfits = "সাধারণ,রাজকীয় পোশাক,মহাকাশ পোশাক,জাদুকরী পোশাক",
                unlockedRooms = "সাধারণ,বাগান ঘর,মহলের ঘর",
                foodCount = state.foodCount + 50,
                level = 10,
                isPremium = true
            )
            repository.updateProgress(updated)
        }
    }
}
