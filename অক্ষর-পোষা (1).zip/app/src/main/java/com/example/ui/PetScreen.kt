package com.example.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.delay

val DarkBg = Color(0xFF1A1A2E)
val CardBg = Color(0xFF16213E)
val BorderLight = Color(0xFF0F3460)
val BorderGreen = Color(0xFF4CAF50)
val BorderRed = Color(0xFFE53935)
val TextWhite = Color.White
val TextYellow = Color(0xFFFFC107)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PetScreen(viewModel: MainViewModel) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val state = uiState ?: return
    
    LaunchedEffect(Unit) {
        viewModel.checkAndResetQuiz()
    }

    Scaffold(
        containerColor = DarkBg,
        topBar = {
            TopAppBar(
                title = { Text("পোষা প্রাণী ও কুইজ", fontWeight = FontWeight.Bold, color = TextWhite) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DarkBg
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Pet Display (Optional but keeps it PetScreen)
            val infiniteTransition = rememberInfiniteTransition()
            val bounce by infiniteTransition.animateFloat(
                initialValue = 0f,
                targetValue = -10f,
                animationSpec = infiniteRepeatable(
                    animation = tween(1000, easing = FastOutSlowInEasing),
                    repeatMode = RepeatMode.Reverse
                ), label = "bounce"
            )
            Box(
                modifier = Modifier
                    .size(100.dp)
                    .offset(y = bounce.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.1f))
                    .border(2.dp, BorderLight, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(state.currentPet, fontSize = 60.sp)
            }
            
            // Daily Quiz UI
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = CardBg),
                border = BorderStroke(2.dp, BorderLight)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp).fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("🏆 আজকের কুইজ", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = TextYellow)
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    if (state.todayQuizIndex >= 5) {
                        // Quiz Finished, Show Timer
                        var timeLeft by remember { mutableStateOf("") }
                        
                        LaunchedEffect(state.lastQuizTime) {
                            while (true) {
                                val diff = System.currentTimeMillis() - state.lastQuizTime
                                val remaining = (12 * 60 * 60 * 1000L) - diff
                                if (remaining <= 0) {
                                    viewModel.checkAndResetQuiz()
                                    break
                                } else {
                                    val hours = remaining / (60 * 60 * 1000)
                                    val minutes = (remaining % (60 * 60 * 1000)) / (60 * 1000)
                                    val seconds = (remaining % (60 * 1000)) / 1000
                                    timeLeft = String.format("%02d:%02d:%02d", hours, minutes, seconds)
                                }
                                delay(1000)
                            }
                        }
                        
                        Text("কুইজ শেষ!", fontSize = 20.sp, color = TextWhite)
                        Text("মোট স্কোর: ${state.quizScore}", fontSize = 18.sp, color = BorderGreen, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(16.dp))
                        Text("⏰ পরের কুইজ আসবে:", fontSize = 16.sp, color = Color.LightGray)
                        Text(timeLeft, fontSize = 24.sp, color = TextYellow, fontWeight = FontWeight.Bold)
                    } else {
                        val questionNumber = state.todayQuizIndex + 1
                        val question = allQuizQuestions[state.todayQuizIndex % allQuizQuestions.size]
                        
                        var selectedOption by remember { mutableStateOf<Int?>(null) }
                        var isAnswerChecked by remember { mutableStateOf(false) }
                        
                        Text("প্রশ্ন $questionNumber/৫", fontSize = 16.sp, color = Color.LightGray)
                        Text("স্কোর: ${state.quizScore}", fontSize = 16.sp, color = BorderGreen)
                        
                        HorizontalDivider(modifier = Modifier.padding(vertical = 16.dp), color = BorderLight)
                        
                        Text(
                            text = question.question,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextWhite,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(bottom = 24.dp)
                        )
                        
                        val labels = listOf("ক", "খ", "গ", "ঘ")
                        
                        question.options.forEachIndexed { index, option ->
                            val isCorrect = index == question.correctAnswerIndex
                            val isSelected = selectedOption == index
                            
                            val bgColor = if (isAnswerChecked) {
                                if (isCorrect) BorderGreen.copy(alpha = 0.2f)
                                else if (isSelected) BorderRed.copy(alpha = 0.2f)
                                else Color.Transparent
                            } else {
                                if (isSelected) BorderLight else Color.Transparent
                            }
                            
                            val borderColor = if (isAnswerChecked) {
                                if (isCorrect) BorderGreen
                                else if (isSelected) BorderRed
                                else BorderLight
                            } else {
                                if (isSelected) TextYellow else BorderLight
                            }
                            
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(bgColor)
                                    .border(2.dp, borderColor, RoundedCornerShape(12.dp))
                                    .clickable(enabled = !isAnswerChecked) {
                                        selectedOption = index
                                    }
                                    .padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("[${labels[index]}]", color = TextYellow, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(option, color = TextWhite, fontSize = 18.sp)
                            }
                        }
                        
                        Spacer(modifier = Modifier.height(24.dp))
                        
                        Button(
                            onClick = {
                                if (isAnswerChecked) {
                                    val wasCorrect = selectedOption == question.correctAnswerIndex
                                    viewModel.submitQuizAnswer(wasCorrect)
                                    selectedOption = null
                                    isAnswerChecked = false
                                } else {
                                    isAnswerChecked = true
                                }
                            },
                            enabled = selectedOption != null,
                            modifier = Modifier.fillMaxWidth().height(56.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = TextYellow, disabledContainerColor = BorderLight),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Text(
                                text = if (isAnswerChecked) "পরের প্রশ্ন →" else "উত্তর যাচাই করুন",
                                color = DarkBg,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}