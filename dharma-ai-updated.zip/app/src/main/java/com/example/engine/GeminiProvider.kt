package com.example.engine

import com.example.BuildConfig
import com.example.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class GeminiProvider : AiEngine {
    private val apiKey = BuildConfig.GEMINI_API_KEY
    private val service = RetrofitClient.service

    override suspend fun generateResponse(
        prompt: String,
        history: List<ChatMessage>,
        responseStyle: String,
        isKidsMode: Boolean
    ): AiResponse = withContext(Dispatchers.IO) {
        val contents = mutableListOf<Content>()
        
        for (msg in history) {
            contents.add(
                Content(
                    role = msg.role,
                    parts = listOf(Part(text = msg.text))
                )
            )
        }
        
        contents.add(
            Content(
                role = "user",
                parts = listOf(Part(text = prompt))
            )
        )

        var systemPrompt = """
            You are Dharma AI (Hindu Dharma AI). 
            Your purpose is to answer questions about Hindu Dharma, philosophy, spirituality, scriptures, culture, festivals, and traditions in a simple, professional, and accessible language. 
            Always use a respectful and neutral tone. 
            You have access to a Google Search tool — use it whenever the question involves a specific mantra, shloka (verse), puja vidhi, festival date, or any fact you are not 100% certain about, so the answer is verified rather than guessed.
            Never invent or approximate a mantra or scripture verse from memory alone — search first, then quote the verified verse exactly as found, along with its source (scripture name, chapter/verse number, or website).
            If, even after searching, you cannot find a reliable source, state clearly: 'এই বিষয়ে নিশ্চিত তথ্য আমার Knowledge Base-এ পাওয়া যায়নি।'
            Provide answers in Bengali if asked in Bengali, or English if asked in English. The default language is Bengali.
            Structure your answers nicely using Markdown. Use emojis appropriately.
        """.trimIndent()

        if (isKidsMode) {
            systemPrompt += "\nKIDS MODE ENABLED: Explain things very simply, like talking to a 7-year-old child. Keep it short, safe, and educational."
        }

        systemPrompt += "\nRESPONSE STYLE: $responseStyle"

        val systemInstruction = Content(
            parts = listOf(Part(text = systemPrompt))
        )

        val request = GenerateContentRequest(
            contents = contents,
            systemInstruction = systemInstruction,
            generationConfig = GenerationConfig(
                temperature = 0.3f // Lower temperature for more factual responses
            ),
            tools = listOf(Tool()) // Enables Google Search grounding for verified mantra/shloka answers
        )

        try {
            val response = service.generateContent(apiKey, request)
            val candidate = response.candidates?.firstOrNull()
            var responseText = candidate?.content?.parts?.firstOrNull()?.text
                ?: "কোনো উত্তর পাওয়া যায়নি।"

            // Extract grounding sources (from Google Search) so the answer can be verified
            val chunks = candidate?.groundingMetadata?.groundingChunks.orEmpty()
            val sources = chunks.mapNotNull { it.web }.filter { !it.uri.isNullOrBlank() }
            val wasSearched = sources.isNotEmpty()

            if (wasSearched) {
                val sourceLines = sources.distinctBy { it.uri }.take(5).joinToString("\n") { src ->
                    "- [${src.title ?: src.uri}](${src.uri})"
                }
                responseText += "\n\n---\n📚 **সোর্স (যাচাইকৃত):**\n$sourceLines"
            }

            AiResponse(
                text = responseText,
                sourceName = sources.distinctBy { it.uri }.take(5).joinToString(", ") { it.title ?: it.uri ?: "" },
                isVerified = wasSearched
            )
        } catch (e: Exception) {
            android.util.Log.e("GeminiProvider", "Error generating response", e)
            AiResponse(
                text = "দুঃখিত, এই মুহূর্তে AI উত্তর তৈরি করতে পারছে না। Error: ${e.message}",
                isFallback = true
            )
        }
    }

    override suspend fun analyzeImage(imageUri: String, prompt: String): AiResponse {
        return AiResponse(
            text = "বর্তমানে ছবি বিশ্লেষণ করার ফিচারটি ডেভেলপমেন্ট পর্যায়ে আছে। দয়া করে আপনার প্রশ্নটি টেক্সট হিসেবে লিখে জানান।",
            isFallback = true
        )
    }
}
