package com.example

import android.app.Application

class EnhancerApp : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}
