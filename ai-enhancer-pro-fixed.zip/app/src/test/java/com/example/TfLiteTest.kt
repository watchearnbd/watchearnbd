package com.example

import org.junit.Test
import org.tensorflow.lite.support.image.TensorImage
import org.tensorflow.lite.DataType
import org.tensorflow.lite.support.tensorbuffer.TensorBuffer
import org.tensorflow.lite.support.common.ops.CastOp
import org.tensorflow.lite.support.image.ImageProcessor

class TfLiteTest {
    @Test
    fun testTensorImage() {
        println("Compiles fine!")
    }
}
