package com.example.research

import com.example.ai.AiProvider
import com.example.ai.Content
import com.example.ai.Part
import com.example.data.KnowledgeEntity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class ResearchResult(
    val answer: String,
    val webSources: List<WebResult> = emptyList(),
    val youtubeSources: List<YouTubeResult> = emptyList(),
    val localSources: List<KnowledgeEntity> = emptyList(),
    val verificationStatus: VerificationStatus = VerificationStatus.NONE,
    val sourceMetadata: List<SourceMetadata> = emptyList(),
    val suggestedQuestions: List<String> = emptyList()
)

class ResearchEngine(
    private val localKnowledgeProvider: ILocalKnowledgeProvider,
    private val webSearchProvider: IWebSearchProvider,
    private val youtubeSearchProvider: IYouTubeSearchProvider,
    private val scriptureVerificationProvider: IScriptureVerificationProvider,
    private val aiProvider: AiProvider
) {
    suspend fun conductResearch(
        question: String,
        chatHistory: List<Content>,
        isDeepResearch: Boolean,
        onProgress: (String) -> Unit
    ): ResearchResult {
        onProgress("🔎 প্রশ্ন বিশ্লেষণ করছি...")
        val analysis = aiProvider.analyzeQuery(question)
        onProgress("Category: ${analysis.category ?: "UNKNOWN"}")
        
        onProgress("📚 Local Knowledge পরীক্ষা করছি...")
        val localResults = localKnowledgeProvider.search(question)
        
        var webResults: List<WebResult> = emptyList()
        var youtubeResults: List<YouTubeResult> = emptyList()
        
        // If Local Knowledge is insufficient or Deep Research is explicitly enabled, we require deep research.
        val needsExternalResearch = isDeepResearch || analysis.needsWebSearch || localResults.isEmpty()
        
        if (needsExternalResearch) {
            onProgress("🌐 Web sources খুঁজছি...")
            webResults = webSearchProvider.search(analysis.webSearchQuery ?: question)
            if (analysis.needsYouTube) {
                youtubeResults = youtubeSearchProvider.search(analysis.youtubeSearchQuery ?: question)
            }
        }
        
        onProgress("📖 Reference যাচাই করছি...")
        // Simulate comparison
        onProgress("⚖️ Sources তুলনা করছি...")
        
        val sourceMetadataList = mutableListOf<SourceMetadata>()
        var hasVerified = false
        var hasPartiallyVerified = false
        var hasNotVerified = false
        
        // Verification phase for local sources
        localResults.forEach {
            val isVerified = scriptureVerificationProvider.verify(it.content)
            val status = when (it.verifiedStatus.lowercase()) {
                "verified" -> VerificationStatus.VERIFIED
                "partially verified" -> VerificationStatus.PARTIALLY_VERIFIED
                else -> VerificationStatus.NOT_VERIFIED
            }
            
            if (status == VerificationStatus.VERIFIED) hasVerified = true
            else if (status == VerificationStatus.PARTIALLY_VERIFIED) hasPartiallyVerified = true
            else hasNotVerified = true
            
            sourceMetadataList.add(
                SourceMetadata(
                    title = it.title,
                    domain = "Local Knowledge Base",
                    sourceType = it.category,
                    reference = "${it.scripture} (${it.reference})",
                    summary = it.content.take(100) + "...",
                    relevanceScore = 100, // Highest for local
                    verificationStatus = status
                )
            )
        }
        
        // Source ranking and verification for web
        webResults.forEach {
            var relevance = 50
            var sType = "General web source"
            var vStatus = VerificationStatus.NOT_VERIFIED
            
            val domainLower = it.domain.lowercase()
            val titleLower = it.title.lowercase()
            
            // Basic source ranking logic
            if (domainLower.contains("vedabase") || domainLower.contains("sacred-texts") || domainLower.contains("gita-society")) {
                relevance = 90
                sType = "Primary Scripture / authoritative text"
                vStatus = VerificationStatus.PARTIALLY_VERIFIED
            } else if (domainLower.contains("ramakrishna") || domainLower.contains("iskcon") || domainLower.contains("chinmaya") || domainLower.contains("chabad")) {
                relevance = 80
                sType = "Trusted religious source"
                vStatus = VerificationStatus.PARTIALLY_VERIFIED
            } else if (domainLower.contains(".edu") || domainLower.contains("university") || domainLower.contains("scholar") || domainLower.contains("oxford") || domainLower.contains("cambridge")) {
                relevance = 75
                sType = "Academic / educational source"
                vStatus = VerificationStatus.PARTIALLY_VERIFIED
            } else if (domainLower.contains("wikipedia.org") || domainLower.contains("britannica")) {
                relevance = 60
                sType = "Established reference"
                vStatus = VerificationStatus.NOT_VERIFIED
            }
            
            sourceMetadataList.add(
                SourceMetadata(
                    title = it.title,
                    domain = it.domain,
                    sourceType = sType,
                    reference = it.link,
                    summary = it.snippet.take(100) + "...",
                    relevanceScore = relevance,
                    verificationStatus = vStatus
                )
            )
            
            if (vStatus == VerificationStatus.PARTIALLY_VERIFIED) hasPartiallyVerified = true
            else if (vStatus == VerificationStatus.NOT_VERIFIED) hasNotVerified = true
        }
        
        // Sort by relevance score
        sourceMetadataList.sortByDescending { it.relevanceScore }
        
        val overallStatus = when {
            hasVerified && !hasNotVerified -> VerificationStatus.VERIFIED
            hasVerified && hasNotVerified -> VerificationStatus.PARTIALLY_VERIFIED
            hasPartiallyVerified -> VerificationStatus.PARTIALLY_VERIFIED
            sourceMetadataList.isEmpty() -> VerificationStatus.NOT_VERIFIED
            else -> VerificationStatus.NOT_VERIFIED
        }
        
        onProgress("🧠 উত্তর তৈরি করছি...")
        
        
        var finalAnswerText = ""
        try {
            finalAnswerText = generateFinalAnswer(question, chatHistory, localResults, webResults, youtubeResults, isDeepResearch, needsExternalResearch, analysis.needsYouTube, analysis.category)
                } catch (e: Exception) {
            if (localResults.isNotEmpty()) {
                finalAnswerText = "⚠️ Network Error / Offline Mode: ইন্টারনেট সংযোগ না থাকায় AI বিশ্লেষণ সম্ভব হচ্ছে না। নিচে Local Knowledge Base থেকে প্রাপ্ত সরাসরি তথ্য দেওয়া হলো:\n\n" + localResults.joinToString("\n\n") { "📌 " + it.title + "\n" + it.content }
            } else {
                throw e
            }
        }
        var finalAnswer = finalAnswerText
        val suggestedQuestions = mutableListOf<String>()
        val delimiter = "---SUGGESTED_QUESTIONS---"
        if (finalAnswer.contains(delimiter)) {
            val parts = finalAnswer.split(delimiter)
            finalAnswer = parts[0].trim()
            if (parts.size > 1) {
                val qs = parts[1].trim().split("\n")
                for (q in qs) {
                    val cleanQ = q.trim().replace(Regex("^\\d+\\.\\s*"), "").replace(Regex("^-?\\s*"), "")
                    if (cleanQ.isNotBlank() && cleanQ.length > 5) {
                        suggestedQuestions.add(cleanQ)
                    }
                }
            }
        }

        return ResearchResult(
            answer = finalAnswer, 
            webSources = webResults, 
            youtubeSources = youtubeResults, 
            localSources = localResults.take(3),
            verificationStatus = overallStatus,
            sourceMetadata = sourceMetadataList,
            suggestedQuestions = suggestedQuestions
        )
    }
    
    private suspend fun generateFinalAnswer(
        question: String,
        chatHistory: List<Content>,
        localResults: List<KnowledgeEntity>,
        webResults: List<WebResult>,
        youtubeResults: List<YouTubeResult>,
        isDeepResearch: Boolean,
        needsExternalResearch: Boolean,
        attemptedYouTubeSearch: Boolean,
        queryCategory: String?
    ): String {
        val todayDate = SimpleDateFormat("dd MMMM yyyy", Locale("bn", "BD")).format(Date())
        
        val systemInstruction = buildString {
            append("Query Classification: ${queryCategory ?: "UNKNOWN"}\n")
            append("You are Dharma AI, an intelligent, helpful, and context-aware AI Assistant. While your primary expertise is Hindu Dharma, Philosophy, and Scriptures, you MUST also answer general knowledge, science, history, daily life, and other non-religious questions concisely and accurately if you know the answer. Adapt to the user's language, but default to Bengali. Current Date: $todayDate.\n")
                        append("CRITICAL RULES:\n")
            append("1. Never invent scripture references, chapter, verse, shlokas, mantras, sanskrit text, or source. If not in DB or external search, explicitly state it.\n")
            append("2. Maintain tradition awareness (Vaishnava, Shaiva, Shakta, Smarta, Vedanta, Yoga). Do not present one interpretation as the universal Hindu belief. If sources disagree, state: 'এই বিষয়ে বিভিন্ন tradition-এ ভিন্ন ব্যাখ্যা রয়েছে।'\n")
            append("3. Do NOT claim you searched Google or YouTube if webResults or youtubeResults are empty.\n")
            append("4. Use the provided Local Knowledge Database context if available. If it is a general question, use your general verified AI knowledge.\n")
            
            append("5. If a Mantra is asked, format exactly as:\n🕉️ মন্ত্র\n📖 শাস্ত্রীয় উৎস\n📍 Reference\n🔤 উচ্চারণ / Transliteration\n📝 সহজ বাংলা অর্থ\n💡 Traditional Context\n🔎 Verification\n📚 Source\nIf unverified, clearly state 'Not Verified'.\n")
            append("6. If a Shloka is asked, format exactly as:\n📖 শাস্ত্র\n📍 Chapter / Verse\n🕉️ শ্লোক\n🔤 Transliteration\n📝 বাংলা অর্থ\n💡 ব্যাখ্যা\n🔎 Verification\n📚 Source\nIf unverified, DO NOT guess the chapter/verse. State 'এই reference নির্ভরযোগ্যভাবে যাচাই করা যায়নি।'\n")
                        append("6a. For Bhagavad Gita related questions, use this specific format when appropriate:\n📖 Bhagavad Gita\n📍 Chapter / Verse\n🕉️ শ্লোক\n🔤 Transliteration\n📝 বাংলা অর্থ\n💡 সহজ ব্যাখ্যা\n🔎 Verification\n📚 Source\nDo NOT invent unverified fields.\n")
            append("7. Transliteration এবং pronunciation একই জিনিস ধরে নেবে না। যদি নির্ভরযোগ্য pronunciation data না থাকে: 'উচ্চারণের তথ্য যাচাই করা হয়নি।' দেখাতে পারবে। নিজে থেকে Sanskrit pronunciation তৈরি করবে না।\n")
            append("8. YouTube videos are educational resources; their scriptural authenticity must be verified separately. If referencing a video, mention: 'এই ভিডিওটি একটি reference resource; এর বক্তব্যের শাস্ত্রীয় সত্যতা আলাদাভাবে যাচাই করা হয়েছে/হয়নি।'\n")
            append("9. If a Puja or Festival is asked about, format the answer with:\n🪔 উৎসব / পূজা\n📖 ধর্মীয় ও ঐতিহ্যগত তাৎপর্য\n🕉️ প্রচলিত রীতি\n🌏 Regional / Tradition Variation\n📍 Reference\n🔎 Verification\n📚 Sources\n")
            append("10. Regional/Tradition Awareness for Festivals/Pujas: NEVER claim a ritual is universal if not proven. Use 'অঞ্চল ও tradition অনুযায়ী রীতিতে পার্থক্য থাকতে পারে।' where applicable. Do not invent rituals, materials, or fake history.\n")
            append("11. GREETING UNDERSTANDING: If the user just says Hi, Hello, নমস্কার, জয় শ্রী রাম, etc., reply politely (e.g. 'নমস্কার 🙏 Dharma AI-তে আপনাকে স্বাগতম। আমি হিন্দু ধর্ম, দর্শন, শাস্ত্র... নিয়ে সাহায্য করতে পারি। আপনি কী জানতে চান?') and suggest initial topics. Do NOT give a long lecture.\n")
            append("12. CONTEXT & FOLLOW-UP: Understand follow-up questions (e.g. 'এর মানে কী?', 'আরও বলো') using the conversation context.\n")
            append("13. SUGGESTED QUESTIONS (CRITICAL): At the VERY END of your response, you MUST provide 3 to 5 highly relevant, context-aware follow-up questions for the user. Do NOT invent fake scripture references in these suggestions. For ambiguous or unknown/gibberish questions, you MAY skip suggesting follow-ups. Append them exactly in this format:\n\n---SUGGESTED_QUESTIONS---\n1. [Question 1]\n2. [Question 2]\n3. [Question 3]\n")
            append("14. UNIVERSAL KNOWLEDGE: Answer general knowledge questions (e.g., 'পৃথিবীর সবচেয়ে বড় মহাসাগর কোনটি?') concisely and accurately without claiming you only know Dharma.\n")
            append("15. UNCERTAINTY & HALLUCINATION PREVENTION: If unsure or lacking sources, DO NOT GUESS. State 'এই তথ্যটি সম্পর্কে আমি পুরোপুরি নিশ্চিত নই।' or 'এই বিষয়টি সম্পর্কে আমার কাছে এই মুহূর্তে নির্ভরযোগ্য তথ্য নেই।'\n")
            append("16. AMBIGUITY, GIBBERISH & TYPOS: Clarify ambiguous questions (e.g. 'শক্তি' could mean Physics Energy or Hindu Shakti). Tolerate typos (e.g., 'গিতা ২ অধ্যায়' -> 'ভগবদ্গীতার দ্বিতীয় অধ্যায়'). If gibberish (e.g., 'asdfgh'), respond: 'আমি আপনার কথাটা পুরোপুরি বুঝতে পারিনি। একটু অন্যভাবে লিখবেন?'\n")
            append("17. WRONG PREMISE: Do NOT accept false premises. E.g., if asked 'What is in the 25th chapter of Gita?', explicitly correct that Gita has only 18 chapters.\n")
            append("18. CONVERSATIONAL TONE & LANGUAGE: Be natural, clear, and human-like. Don't be robotic. Do not force rigid formats on simple questions.\n")


            if (needsExternalResearch && webResults.isEmpty() && youtubeResults.isEmpty()) {
                append("\nIMPORTANT FALLBACK INSTRUCTION: External search is currently unavailable. You MUST include this EXACT sentence in your response (either at the start or end): 'বর্তমানে external web research unavailable; verified Dharma Knowledge Base থেকে উত্তর দেওয়া হচ্ছে।'\n")
            }
            
            if (localResults.isEmpty()) {
                append("\nNo exact matching records found in the Local Knowledge Base. If it is a Dharma-related question, answer from your general verified knowledge but mention: 'এই তথ্যের নির্দিষ্ট শাস্ত্রীয় reference Knowledge Base-এ পাওয়া যায়নি।'. If it is a general knowledge question (science, history, etc.), just answer it normally without mentioning the Knowledge Base.\n")
            } else {
                append("\n--- Local Dharma Knowledge Base Context ---\n")
                                localResults.take(5).forEach { k -> 
                    append("Title: ${k.title}\n" +
                           "Category: ${k.category}\n" +
                           "Scripture: ${k.scripture}\n" +
                           "Reference: ${k.reference}\n" +
                           "Sanskrit Text: ${k.sanskritText}\n" +
                           "Transliteration: ${k.transliteration}\n" +
                           "Bangla Meaning: ${k.banglaMeaning}\n" +
                           "Content: ${k.content}\n" +
                           "Explanation: ${k.explanation}\n" +
                           "Deity: ${k.deity}\n" +
                           "Traditional Practice: ${k.traditionalPractice}\n" +
                           "Regional Variation: ${k.regionalVariation}\n" +
                           "Significance: ${k.significance}\n" +
                           "Materials: ${k.materials}\n" +
                           "Mantra References: ${k.mantraReferences}\n" +
                           "Historical Context: ${k.historicalContext}\n" +
                           "Source: ${k.source}\n" +
                           "Verified Status: ${k.verifiedStatus}\n---\n")
                }
            }
            
            if (webResults.isNotEmpty()) {
                append("\n--- Web Search Results ---\n")
                webResults.forEach { w -> append("- ${w.domain}: ${w.title} (${w.snippet})\n") }
            }

            if (attemptedYouTubeSearch && youtubeResults.isEmpty()) {
                append("\nIf the user specifically asked for a video and YouTube results are empty, you MUST state: 'বর্তমানে YouTube research unavailable।' and answer using other available knowledge.\n")
            }
            if (youtubeResults.isNotEmpty()) {
                append("\n--- YouTube Search Results ---\n")
                youtubeResults.forEach { y -> append("- Channel: ${y.channelTitle}, Title: ${y.title} (${y.description})\n") }
            }

        }
        
        val historyWithQuestion = chatHistory.toMutableList()
        historyWithQuestion.add(Content(role = "user", parts = listOf(Part(text = question))))
        return aiProvider.generateResponse(historyWithQuestion, systemInstruction)
    }
}
