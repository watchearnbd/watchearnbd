import os

path = 'app/src/main/java/com/example/ai/SmartKnowledgeMatcher.kt'
if not os.path.exists(path):
    print("File not found")
    exit(1)

with open(path, 'r') as f:
    text = f.read()

replacement = """    private fun semanticNormalize(text: String): String {
        var norm = text.lowercase()
            .replace(Regex("[\\\\p{Punct}।—-]+"), " ")
            .replace(Regex("[\\\\s]+"), " ")
            .trim()
            
        // Pre-replace multi-word synonyms and common variations
        for ((synList, canon) in synonyms) {
            for (syn in synList) {
                if (syn.contains(" ")) {
                    norm = norm.replace(syn, canon)
                }
            }
        }
                    
        val tokens = norm.split(" ").filter { !stopWords.contains(it) }
        val canonicalTokens = tokens.map { token ->
            var canonical = token
            for ((synList, canon) in synonyms) {
                if (synList.any { it == token || (token.contains(it) && it.length > 3) }) {
                    canonical = canon
                    break
                }
            }
            canonical
        }
        return canonicalTokens.joinToString(" ")
    }"""

import re
pattern = r'    private fun semanticNormalize\(text: String\): String \{.*?    \}'
text = re.sub(pattern, replacement, text, flags=re.MULTILINE|re.DOTALL)

with open(path, 'w') as f:
    f.write(text)
print("Patched semanticNormalize for multi-word")
