import os

path = 'app/src/main/java/com/example/ai/SmartKnowledgeMatcher.kt'
with open(path, 'r') as f:
    text = f.read()

# Make sure chapter match gives an even higher score or relaxes threshold
text = text.replace('maxScore = maxOf(maxScore, 0.95)', 'maxScore = maxOf(maxScore, 0.95)\n                    return 0.95')

# Make sure typo match handles partial tokens better
text = text.replace('val tokenScore = (matchedTokens / queryTokens.size) * 0.8 // Max 0.8',
                    'val tokenScore = (matchedTokens / queryTokens.size) * 0.9 // Max 0.9')

with open(path, 'w') as f:
    f.write(text)
print("SmartKnowledgeMatcher token and chapter logic updated.")
