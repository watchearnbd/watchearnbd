fun main() {
    println("মন্ত্র".length)
}
