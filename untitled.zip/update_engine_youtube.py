import re

with open("app/src/main/java/com/example/research/ResearchEngine.kt", "r") as f:
    content = f.read()

# Add rule 7
content = content.replace(
    "append(\"6. If a Shloka is asked, format exactly as:\\nChapter\\nVerse\\nReference\\nMeaning\\nExplanation\\nIf unverified, DO NOT guess the chapter/verse. State 'এই reference নির্ভরযোগ্যভাবে যাচাই করা যায়নি।'\\n\")",
    "append(\"6. If a Shloka is asked, format exactly as:\\nChapter\\nVerse\\nReference\\nMeaning\\nExplanation\\nIf unverified, DO NOT guess the chapter/verse. State 'এই reference নির্ভরযোগ্যভাবে যাচাই করা যায়নি।'\\n\")\n            append(\"7. YouTube videos are educational resources; their scriptural authenticity must be verified separately. If referencing a video, mention: 'এই ভিডিওটি একটি reference resource; এর বক্তব্যের শাস্ত্রীয় সত্যতা আলাদাভাবে যাচাই করা হয়েছে/হয়নি।'\\n\")"
)

# Append youtube results
youtube_append = """
            if (youtubeResults.isNotEmpty()) {
                append("\\n--- YouTube Search Results ---\\n")
                youtubeResults.forEach { y -> append("- Channel: ${y.channelTitle}, Title: ${y.title} (${y.description})\\n") }
            }
"""

content = content.replace(
    "if (webResults.isNotEmpty()) {\n                append(\"\\n--- Web Search Results ---\\n\")\n                webResults.forEach { w -> append(\"- ${w.domain}: ${w.title} (${w.snippet})\\n\") }\n            }",
    "if (webResults.isNotEmpty()) {\n                append(\"\\n--- Web Search Results ---\\n\")\n                webResults.forEach { w -> append(\"- ${w.domain}: ${w.title} (${w.snippet})\\n\") }\n            }" + youtube_append
)

# Update fallback string to just say "বর্তমানে YouTube research unavailable।" if deep search but youtube unavailable.
# Actually, the user says:
# "YouTube unavailable হলে:
# “বর্তমানে YouTube research unavailable।”
# দেখিয়ে Local Knowledge/Web Research ব্যবহার করবে।"
# So if youtubeResults is empty but we searched for it, we should maybe add that fallback. 
# Or we can just let the AI say it if it thinks it searched YouTube.
# Wait, "YouTube search result না থাকলে: Fake video তৈরি করবে না... YouTube unavailable হলে: “বর্তমানে YouTube research unavailable।” দেখিয়ে Local Knowledge/Web Research ব্যবহার করবে।"

with open("app/src/main/java/com/example/research/ResearchEngine.kt", "w") as f:
    f.write(content)

