import os, re

path = 'app/src/main/java/com/example/ai/AdvancedDecisionEngine.kt'
with open(path, 'r') as f:
    text = f.read()

target = """        // --- 9. RESPONSE GENERATION (RULE-BASED NLG) ---
        onProgress("Internal Brain: Formatting Final Answer...")
        val primaryResult = results.first()
        val sb = java.lang.StringBuilder()
        
        val isDetailed = listOf("বিস্তারিত", "আরও", "সব", "ব্যাখ্যা", "বুঝিয়ে").any { lowerMessage.contains(it) }
        val isMeaning = listOf("মানে", "অর্থ", "বলতে কী", "কি বোঝায়").any { lowerMessage.contains(it) }
        val isExample = listOf("উদাহরণ", "যেমন").any { lowerMessage.contains(it) }
        val isReasoning = listOf("কেন", "কারণ").any { lowerMessage.contains(it) }

        if (isDetailed) {"""

replacement = """        // --- 9. RESPONSE GENERATION (RULE-BASED NLG) ---
        onProgress("Internal Brain: Formatting Final Answer...")
        val primaryResult = results.first()
        val sb = java.lang.StringBuilder()
        
        // Handle AI RESPONSE RULE injected in explanation
        if (primaryResult.explanation.contains("AI RESPONSE RULE")) {
            val isCountQuery = listOf("কয়টি নাম", "কতটি নাম", "কতগুলো নাম", "how many names", "how many").any { lowerMessage.contains(it) }
            val isListQuery = listOf("নামগুলো", "108 naam", "108 নাম", "সবগুলো", "তালিকা", "108 name").any { lowerMessage.contains(it) }
            val isMainMantraQuery = listOf("প্রধান মন্ত্র", "main mantra", "কোন মন্ত্র").any { lowerMessage.contains(it) }
            
            if (primaryResult.title.contains("108 Names")) {
                if (isCountQuery && !isListQuery) {
                    sb.append("শ্রীকৃষ্ণের ১০৮ নামের একটি প্রচলিত অষ্টোত্তর শতনামাবলী রয়েছে। বিভিন্ন শাস্ত্রীয় ও ভক্তি-পরম্পরায় নামের তালিকায় কিছু পার্থক্য দেখা যেতে পারে। Dharma AI-তে একটি নির্দিষ্ট উৎসভিত্তিক ১০৮ নামের তালিকা সংরক্ষিত রয়েছে।")
                } else {
                    sb.append(primaryResult.content)
                }
            } else if (primaryResult.title.contains("Hare Krishna")) {
                 if (isMainMantraQuery) {
                     sb.append("শ্রীকৃষ্ণের উপাসনায় বিভিন্ন বৈষ্ণব পরম্পরায় বিভিন্ন মন্ত্র ব্যবহৃত হয়। এর মধ্যে হরে কৃষ্ণ মহামন্ত্র এবং 'ওঁ নমো ভগবতে বাসুদেবায়' বিশেষভাবে পরিচিত।")
                 } else {
                     sb.append(primaryResult.content)
                 }
            } else {
                 sb.append(primaryResult.content)
            }
        } else {
            val isDetailed = listOf("বিস্তারিত", "আরও", "সব", "ব্যাখ্যা", "বুঝিয়ে").any { lowerMessage.contains(it) }
            val isMeaning = listOf("মানে", "অর্থ", "বলতে কী", "কি বোঝায়").any { lowerMessage.contains(it) }
            val isExample = listOf("উদাহরণ", "যেমন").any { lowerMessage.contains(it) }
            val isReasoning = listOf("কেন", "কারণ").any { lowerMessage.contains(it) }
    
            if (isDetailed) {"""

if target in text:
    text = text.replace(target, replacement)
    
    # regex for closing brace
    text = re.sub(r'(\s+sb\.append\("\\n\\n\(শ্লোক: \$\{primaryResult\.sanskritText\}\)"\)\n\s+}[ \t]*\n\s+)(var finalResponse = sb\.toString\(\)\.trim\(\))', r'\1} // Close AI RULE else block\n\n        \2', text)

    with open(path, 'w') as f:
        f.write(text)
    print("Patched AdvancedDecisionEngine for AI RULES")
else:
    print("Could not find target in ADE")
