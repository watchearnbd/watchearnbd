import re

with open("app/src/main/java/com/example/research/Providers.kt", "r") as f:
    content = f.read()

new_web_provider = """class WebSearchProviderImpl : IWebSearchProvider {
    override suspend fun search(query: String): List<WebResult> {
        val apiKey = com.example.BuildConfig.GOOGLE_SEARCH_API_KEY
        val cx = com.example.BuildConfig.GOOGLE_SEARCH_CX
        
        if (apiKey.isEmpty() || apiKey == "MY_GOOGLE_SEARCH_API_KEY" || cx.isEmpty() || cx == "MY_GOOGLE_SEARCH_CX") {
            println("Web Research: NOT CONFIGURED")
            return emptyList()
        }
        
        return try {
            val response = GoogleSearchRetrofit.service.search(query = query, apiKey = apiKey, cx = cx)
            response.items?.map { item ->
                WebResult(
                    title = item.title ?: "",
                    link = item.link ?: "",
                    domain = item.displayLink ?: "",
                    snippet = item.snippet ?: ""
                )
            } ?: emptyList()
        } catch (e: Exception) {
            println("Web Research Error: ${e.message}")
            emptyList()
        }
    }
}"""

content = re.sub(r'class WebSearchProviderImpl : IWebSearchProvider \{.*?\}', new_web_provider, content, flags=re.DOTALL)

with open("app/src/main/java/com/example/research/Providers.kt", "w") as f:
    f.write(content)

