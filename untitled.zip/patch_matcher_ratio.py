import os

path = 'app/src/main/java/com/example/ai/SmartKnowledgeMatcher.kt'
with open(path, 'r') as f:
    text = f.read()

text = text.replace('if (ratio > 0.5) maxScore = maxOf(maxScore, 0.75 + (ratio * 0.2))',
                    'if (ratio > 0.3) maxScore = maxOf(maxScore, 0.75 + (ratio * 0.2))\n            if (titleNorm.length > 4 && normalizedQuery.contains(titleNorm)) maxScore = maxOf(maxScore, 0.86)')

text = text.replace('if (ratio > 0.5) maxScore = maxOf(maxScore, 0.70 + (ratio * 0.2))',
                    'if (ratio > 0.3) maxScore = maxOf(maxScore, 0.70 + (ratio * 0.2))\n                if (alias.length > 4 && normalizedQuery.contains(alias)) maxScore = maxOf(maxScore, 0.86)')

with open(path, 'w') as f:
    f.write(text)
print("SmartKnowledgeMatcher containment rule patched.")
