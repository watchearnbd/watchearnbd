import os

with open('app/src/main/java/com/example/ai/AdvancedDecisionEngine.kt', 'r') as f:
    text = f.read()

target = """        // 7. Self-Correction
        var finalAnswer = result.answer
        if (!selfCheckResult.isValid && !selfCheckResult.correctionsNeeded.isNullOrBlank()) {
            onProgress("🔧 Self-Correcting...")
            finalAnswer = generateCorrection(finalQuery, result.answer, selfCheckResult.correctionsNeeded, history)
        }"""

replacement = """        // 7. Self-Correction
        var finalAnswer = result.answer
        if (!selfCheckResult.isValid && !selfCheckResult.correctionsNeeded.isNullOrBlank()) {
            onProgress("🔧 Self-Correcting...")
            try {
                finalAnswer = generateCorrection(finalQuery, result.answer, selfCheckResult.correctionsNeeded, history)
            } catch (e: Exception) {
                // Ignore correction if it fails due to auth or network
            }
        }"""

text = text.replace(target, replacement)

with open('app/src/main/java/com/example/ai/AdvancedDecisionEngine.kt', 'w') as f:
    f.write(text)

