import re
with open('app/src/main/java/com/example/research/ResearchEngine.kt', 'r') as f:
    content = f.read()

# Try-catch around generateFinalAnswer
replacement = """
        var finalAnswerText = ""
        try {
            finalAnswerText = generateFinalAnswer(question, chatHistory, localResults, webResults, youtubeResults, isDeepResearch, needsExternalResearch, analysis.needsYouTube)
        } catch (e: Exception) {
            if (localResults.isNotEmpty()) {
                finalAnswerText = "Network Error (Offline Mode). We cannot generate a conversational response right now. However, here is the information from the Local Knowledge Base:\n\n" + localResults.joinToString("\n\n") { "📌 " + it.title + "\\n" + it.content }
            } else {
                throw e
            }
        }
        val finalAnswer = finalAnswerText
"""

content = content.replace("val finalAnswer = generateFinalAnswer(question, chatHistory, localResults, webResults, youtubeResults, isDeepResearch, needsExternalResearch, analysis.needsYouTube)", replacement)

with open('app/src/main/java/com/example/research/ResearchEngine.kt', 'w') as f:
    f.write(content)
