import os

path = 'app/src/main/java/com/example/ai/AdvancedDecisionEngine.kt'
if not os.path.exists(path):
    print("File not found")
    exit(1)

with open(path, 'r') as f:
    text = f.read()

# Let's ensure it has proper MANTRA checking and Clarification
# We saw earlier that it had some logic for "UNKNOWN / OUT OF DOMAIN RESPONSE (MANTRA/SCRIPTURE SAFETY)"
