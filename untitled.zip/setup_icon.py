import os

os.makedirs('app/src/main/res/drawable', exist_ok=True)
os.makedirs('app/src/main/res/mipmap-anydpi-v26', exist_ok=True)
os.makedirs('app/src/main/res/values', exist_ok=True)

# 1. Background
with open('app/src/main/res/drawable/ic_launcher_background.xml', 'w') as f:
    f.write('''<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="108dp"
    android:height="108dp"
    android:viewportWidth="108"
    android:viewportHeight="108">
    <path
        android:fillColor="#0B0F19"
        android:pathData="M0,0h108v108h-108z" />
    <path
        android:fillColor="#1A2235"
        android:pathData="M0,0L108,108v-108z" />
</vector>
''')

# 2. Foreground (Dharma AI Book + Sparkle)
with open('app/src/main/res/drawable/ic_launcher_foreground.xml', 'w') as f:
    f.write('''<?xml version="1.0" encoding="utf-8"?>
<layer-list xmlns:android="http://schemas.android.com/apk/res/android">
    <item
        android:width="66dp"
        android:height="66dp"
        android:gravity="center">
        <vector
            android:width="66dp"
            android:height="66dp"
            android:viewportWidth="24"
            android:viewportHeight="24">
            <!-- Book Icon -->
            <path
                android:fillColor="#FFD700"
                android:pathData="M21,5c-1.11,-0.35 -2.33,-0.5 -3.5,-0.5 -1.95,0 -4.05,0.4 -5.5,1.5 -1.45,-1.1 -3.55,-1.5 -5.5,-1.5S2.45,4.9 1,6v14.65c0,0.25 0.25,0.5 0.5,0.5 0.1,0 0.15,-0.05 0.25,-0.09C3.1,20.45 5.05,20 6.5,20c1.95,0 4.05,0.4 5.5,1.5 1.35,-0.85 3.8,-1.5 5.5,-1.5 1.65,0 3.35,0.3 4.75,1.06 0.1,0.05 0.15,0.09 0.25,0.09 0.25,0 0.5,-0.25 0.5,-0.5V6c-0.6,-0.45 -1.25,-0.75 -2,-1zm0,13.5c-1.1,-0.35 -2.3,-0.5 -3.5,-0.5 -1.7,0 -4.15,0.65 -5.5,1.5V8c1.35,-0.85 3.8,-1.5 5.5,-1.5 1.2,0 2.4,0.15 3.5,0.5v11.5z" />
            <!-- Star in the middle -->
            <path
                android:fillColor="#FFA500"
                android:pathData="M12,2l2,5h5l-4,3l1,5l-4,-3l-4,3l1,-5l-4,-3h5z" />
        </vector>
    </item>
</layer-list>
''')

# 3. Adaptive Icon
ic_launcher = '''<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@drawable/ic_launcher_background" />
    <foreground android:drawable="@drawable/ic_launcher_foreground" />
</adaptive-icon>
'''
with open('app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml', 'w') as f:
    f.write(ic_launcher)

with open('app/src/main/res/mipmap-anydpi-v26/ic_launcher_round.xml', 'w') as f:
    f.write(ic_launcher)

print("Icon setup complete.")
