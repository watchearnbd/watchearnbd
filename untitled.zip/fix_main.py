import re
with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

# Add a Knowledge tab
content = content.replace('Icon(Icons.Filled.Search, contentDescription = "Research")', 'Icon(Icons.Filled.MenuBook, contentDescription = "Knowledge")')
content = content.replace('label = { Text("Research") }', 'label = { Text("Knowledge") }')
content = content.replace('onClick = { navController.navigate("research") { launchSingleTop = true } }', 'onClick = { navController.navigate("knowledge") { launchSingleTop = true } }')

content = content.replace('composable("research") { DummyScreen("Deep Research Mode") }', 'composable("knowledge") { com.example.ui.knowledge.KnowledgeScreen() }')

# Add imports
imports = """
import androidx.compose.material.icons.filled.MenuBook
import com.example.ui.knowledge.KnowledgeScreen
"""
content = content.replace("import com.example.ui.chat.ChatViewModelFactory", "import com.example.ui.chat.ChatViewModelFactory\n" + imports)

with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(content)
