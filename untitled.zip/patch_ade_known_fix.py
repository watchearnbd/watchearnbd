import os

path = 'app/src/main/java/com/example/ai/AdvancedDecisionEngine.kt'
if os.path.exists(path):
    with open(path, 'r') as f:
        text = f.read()
    
    # Replace the strict 'I am not sure' with the new TRUTH-FIRST unknown message
    text = text.replace('এই তথ্যটি সম্পর্কে আমি নিশ্চিত নই। ভুল তথ্য দেওয়ার চেয়ে আমি সেটা পরিষ্কারভাবে জানাচ্ছি।', 
                        'এই তথ্যটি আমার Verified Knowledge Base-এ নেই।')
    
    with open(path, 'w') as f:
        f.write(text)
    print("Patched AdvancedDecisionEngine.kt")
else:
    print("File not found")
