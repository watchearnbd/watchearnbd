import os

with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    text = f.read()

text = text.replace(
    'composable("knowledge") { KnowledgeScreen(savedItemViewModel) }',
    'composable("knowledge") { KnowledgeScreen(savedItemViewModel, onNavigateToDetail = {}) }'
)

with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(text)
