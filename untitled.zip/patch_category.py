import os

with open('app/src/main/java/com/example/research/ResearchEngine.kt', 'r') as f:
    text = f.read()

text = text.replace(
    'append("You are Dharma AI',
    'append("Query Classification: ${analysis.category ?: "UNKNOWN"}\\n")\n            append("You are Dharma AI'
)

with open('app/src/main/java/com/example/research/ResearchEngine.kt', 'w') as f:
    f.write(text)

