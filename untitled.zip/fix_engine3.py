import re
with open('app/src/main/java/com/example/research/ResearchEngine.kt', 'r') as f:
    content = f.read()

# Pass attemptedYouTubeSearch to generateFinalAnswer
content = content.replace(
    "val finalAnswer = generateFinalAnswer(question, chatHistory, localResults, webResults, youtubeResults, isDeepResearch, needsExternalResearch)",
    "val finalAnswer = generateFinalAnswer(question, chatHistory, localResults, webResults, youtubeResults, isDeepResearch, needsExternalResearch, analysis.needsYouTube)"
)

content = content.replace(
    "needsExternalResearch: Boolean\n    ): String {",
    "needsExternalResearch: Boolean,\n        attemptedYouTubeSearch: Boolean\n    ): String {"
)

# Update the condition inside generateFinalAnswer
content = content.replace(
    "if (youtubeResults.isEmpty()) {",
    "if (attemptedYouTubeSearch && youtubeResults.isEmpty()) {"
)

with open('app/src/main/java/com/example/research/ResearchEngine.kt', 'w') as f:
    f.write(content)
