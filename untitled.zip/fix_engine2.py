import re
with open('app/src/main/java/com/example/research/ResearchEngine.kt', 'r') as f:
    content = f.read()

# Pass needsExternalResearch to generateFinalAnswer
content = content.replace(
    "val finalAnswer = generateFinalAnswer(question, chatHistory, localResults, webResults, youtubeResults, isDeepResearch)",
    "val finalAnswer = generateFinalAnswer(question, chatHistory, localResults, webResults, youtubeResults, isDeepResearch, needsExternalResearch)"
)

content = content.replace(
    "isDeepResearch: Boolean\n    ): String {",
    "isDeepResearch: Boolean,\n        needsExternalResearch: Boolean\n    ): String {"
)

# Update the condition inside generateFinalAnswer
content = content.replace(
    "if (webResults.isEmpty() && youtubeResults.isEmpty()) {",
    "if (needsExternalResearch && webResults.isEmpty() && youtubeResults.isEmpty()) {"
)

with open('app/src/main/java/com/example/research/ResearchEngine.kt', 'w') as f:
    f.write(content)
