import os

def write_file(path, content):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w') as f:
        f.write(content.strip() + '\n')

# 1. Update KnowledgeEntity
write_file('app/src/main/java/com/example/data/KnowledgeEntity.kt', """
package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "knowledge")
data class KnowledgeEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val category: String,
    val scripture: String,
    val reference: String,
    val content: String,
    val explanation: String,
    val source: String,
    val verifiedStatus: String,
    val tags: String
)
""")

# 2. Update KnowledgeDao
write_file('app/src/main/java/com/example/data/KnowledgeDao.kt', """
package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface KnowledgeDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(knowledgeList: List<KnowledgeEntity>)

    @Query(\"\"\"
        SELECT * FROM knowledge 
        WHERE title LIKE '%' || :query || '%' 
        OR content LIKE '%' || :query || '%'
        OR explanation LIKE '%' || :query || '%'
        OR tags LIKE '%' || :query || '%'
        OR scripture LIKE '%' || :query || '%'
    \"\"\")
    suspend fun searchKnowledge(query: String): List<KnowledgeEntity>
    
    @Query("SELECT COUNT(*) FROM knowledge")
    suspend fun getKnowledgeCount(): Int

    @Query("DELETE FROM knowledge")
    suspend fun clearAll()
}
""")

# 3. Update AppDatabase
write_file('app/src/main/java/com/example/data/AppDatabase.kt', """
package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [KnowledgeEntity::class], version = 2, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun knowledgeDao(): KnowledgeDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "dharma_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
""")

# 4. Elaborate KnowledgeSeeder
write_file('app/src/main/java/com/example/data/KnowledgeSeeder.kt', """
package com.example.data

object KnowledgeSeeder {
    val initialData = listOf(
        KnowledgeEntity(
            title = "গায়ত্রী মন্ত্র",
            category = "Mantra",
            scripture = "ঋগ্বেদ",
            reference = "৩.৬২.১০",
            content = "ওঁ ভূর্ভুবঃ স্বঃ তৎ সবিতুর্বরেণ্যং ভর্গো দেবস্য ধীমহি ধিয়ো য়ো নঃ প্রচোদয়াৎ।",
            explanation = "আমরা সেই পরমেশ্বরের (সূর্যদেব বা সবিতা) তেজ ধ্যান করি, যিনি আমাদের বুদ্ধিকে সঠিক পথে চালিত করেন। এটি অন্যতম পবিত্র বৈদিক মন্ত্র।",
            source = "Local Dharma Knowledge Base",
            verifiedStatus = "Verified",
            tags = "গায়ত্রী, মন্ত্র, সূর্য, বৈদিক, প্রার্থনা, Gayatri"
        ),
        KnowledgeEntity(
            title = "মহামৃত্যুঞ্জয় মন্ত্র",
            category = "Mantra",
            scripture = "ঋগ্বেদ",
            reference = "৭.৫৯.১২",
            content = "ওঁ ত্র্যম্বকং যজামহে সুগন্ধিং পুষ্টিবর্ধনম্। উর্বারুকমিব বন্ধনান্ মৃত্যোর্মুক্ষীয় মামৃতাৎ।।",
            explanation = "আমরা ত্রিনেত্র শিবের আরাধনা করি, যিনি সুগন্ধি ও পুষ্টিদাতা। শশা যেমন বোঁটা থেকে মুক্ত হয়, তেমনি তিনি যেন আমাদের মৃত্যু থেকে মুক্ত করেন এবং অমরত্ব প্রদান করেন।",
            source = "Local Dharma Knowledge Base",
            verifiedStatus = "Verified",
            tags = "মৃত্যুঞ্জয়, শিব, মন্ত্র, মহাদেব, ত্র্যম্বক, Mahamrityunjaya"
        ),
        KnowledgeEntity(
            title = "কর্মযোগ (নিষ্কাম কর্ম)",
            category = "Hindu Philosophy",
            scripture = "ভগবদ্গীতা",
            reference = "অধ্যায় ২, শ্লোক ৪৭",
            content = "কর্মণ্যেवाधिकारस्ते मा फलेषु कदाचन। मा कर्मफलहेतुर्भूर्मा ते सङ्गोऽस्त्वकर्मणि।।",
            explanation = "কর্মে তোমার অধিকার আছে, কিন্তু কর্মফলে কখনোই তোমার অধিকার নেই। তুমি নিজেকে কর্মফলের কারণ ভেবো না, আবার কর্মত্যাগেও যেন তোমার আসক্তি না হয়। এটি নিষ্কাম কর্মের মূল ভিত্তি।",
            source = "Local Dharma Knowledge Base",
            verifiedStatus = "Verified",
            tags = "কর্মযোগ, কর্ম, গীতা, নিষ্কাম কর্ম, দায়িত্ব, Karma, Bhagavad Gita"
        ),
        KnowledgeEntity(
            title = "অবতার তত্ত্ব (যদা যদা হি ধর্মস্য)",
            category = "Hindu Philosophy",
            scripture = "ভগবদ্গীতা",
            reference = "অধ্যায় ৪, শ্লোক ৭-৮",
            content = "যদা যদা হি ধর্মস্য গ্লানির্ভবতি ভারত। ... পরিত্রাণায় সাধূনাং বিনাশায় চ দুষ্কৃতাম্। ধর্মসংস্থাপনার্থায় সম্ভবামি যুগে যুগে।।",
            explanation = "যখনই ধর্মের পতন হয় এবং অধর্মের উত্থান হয়, তখন আমি নিজেকে প্রকাশ করি। সাধুদের রক্ষা, দুর্বৃত্তদের বিনাশ এবং ধর্ম সংস্থাপনের জন্য আমি যুগে যুগে অবতীর্ণ হই।",
            source = "Local Dharma Knowledge Base",
            verifiedStatus = "Verified",
            tags = "অবতার, ধর্ম, গ্লানি, শ্রীকৃষ্ণ, Avatar, Krishna"
        ),
        KnowledgeEntity(
            title = "দুর্গাপূজা (শারদীয়া নবরাত্রি)",
            category = "Festivals",
            scripture = "মার্কণ্ডেয় পুরাণ (দেবী মাহাত্ম্যম্)",
            reference = "দেবী মাহাত্ম্যম্ / চণ্ডী",
            content = "দুর্গাপূজা অশুভ শক্তির ওপর শুভ শক্তির বিজয়ের প্রতীক। মহিষাসুরকে বধ করার জন্য দেবী দুর্গার এই আরাধনা করা হয়।",
            explanation = "শরৎকালে এই পূজা হয় বলে একে শারদীয়া দুর্গাপূজাও বলা হয়। দেবী দুর্গা হলেন আদ্যাশক্তি মহামায়ার রূপ।",
            source = "Local Dharma Knowledge Base",
            verifiedStatus = "Verified",
            tags = "দুর্গা, পূজা, উৎসব, মহিষাসুর, নবরাত্রি, Durga Puja"
        ),
        KnowledgeEntity(
            title = "যোগ দর্শন",
            category = "Yoga",
            scripture = "পতঞ্জলি যোগসূত্র",
            reference = "১.২",
            content = "যোগশ্চিত্তবৃত্তিনিরোধঃ",
            explanation = "চিত্তের বা মনের বৃত্তিগুলোকে (চঞ্চলতা বা চিন্তা) নিরোধ বা নিয়ন্ত্রণ করাই হলো যোগ।",
            source = "Local Dharma Knowledge Base",
            verifiedStatus = "Verified",
            tags = "যোগ, পতঞ্জলি, চিত্ত, মন, ધ્યાન, Yoga"
        ),
        KnowledgeEntity(
            title = "তত্ত্বমসি (মহাবাক্য)",
            category = "Upanishads",
            scripture = "ছান্দোগ্য উপনিষদ",
            reference = "৬.৮.৭",
            content = "তৎ ত্বম্ অসি",
            explanation = "এর আক্ষরিক অর্থ 'তুমিই সেই'। এটি বোঝায় যে জীবাত্মা (ব্যক্তির আত্মা) এবং পরমাত্মা (ব্রহ্ম) মূলত এক এবং অভিন্ন। এটি অদ্বৈত বেদান্তের একটি অন্যতম মূলভিত্তি।",
            source = "Local Dharma Knowledge Base",
            verifiedStatus = "Verified",
            tags = "তত্ত্বমসি, উপনিষদ, বেদান্ত, অদ্বৈত, ব্রহ্ম, আত্মা, Tat Tvam Asi"
        ),
        KnowledgeEntity(
            title = "শিব পূজা",
            category = "Puja",
            scripture = "শিব পুরাণ",
            reference = "বিদ্যেশ্বর সংহিতা",
            content = "শিব পূজা হলো দেবাদিদেব মহাদেবের উপাসনা। সাধারণত শিবলিঙ্গে জল, দুধ, মধু ও বিল্বপত্র বা বেলপাতা অর্পণের মাধ্যমে এই পূজা করা হয়।",
            explanation = "শিবকে অত্যন্ত অল্পে সন্তুষ্ট দেবতা বা আশুতোষ বলা হয়। ভক্তিভরে যে কেউ তাঁর পূজা করতে পারে। মহামৃত্যুঞ্জয় মন্ত্র জপ শিব পূজার একটি প্রধান অংশ।",
            source = "Local Dharma Knowledge Base",
            verifiedStatus = "Verified",
            tags = "শিব, মহাদেব, লিঙ্গ, পূজা, বেলপাতা, Shiva"
        )
    )
}
""")

# 5. Update Providers to mock Google/YouTube and act as interfaces
write_file('app/src/main/java/com/example/research/Providers.kt', """
package com.example.research

data class WebResult(val title: String, val link: String, val domain: String, val snippet: String)
data class YouTubeResult(val title: String, val channelTitle: String, val videoId: String, val description: String)

class WebSearchProvider {
    suspend fun search(query: String): List<WebResult> {
        // Disabled for NO-API-KEY architecture phase. Ready for custom backend injection.
        return emptyList()
    }
}

class YouTubeSearchProvider {
    suspend fun search(query: String): List<YouTubeResult> {
        // Disabled for NO-API-KEY architecture phase. Ready for custom backend injection.
        return emptyList()
    }
}
""")

# 6. Update ResearchEngine
write_file('app/src/main/java/com/example/research/ResearchEngine.kt', """
package com.example.research

import com.example.ai.AiProvider
import com.example.ai.Content
import com.example.ai.Part
import com.example.data.KnowledgeDao
import com.example.data.KnowledgeEntity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class ResearchResult(
    val answer: String,
    val webSources: List<WebResult> = emptyList(),
    val youtubeSources: List<YouTubeResult> = emptyList(),
    val localSources: List<KnowledgeEntity> = emptyList()
)

class ResearchEngine(
    private val localKnowledgeProvider: KnowledgeDao,
    private val webSearchProvider: WebSearchProvider,
    private val youtubeSearchProvider: YouTubeSearchProvider,
    private val aiProvider: AiProvider
) {
    suspend fun conductResearch(
        question: String,
        chatHistory: List<Content>,
        isDeepResearch: Boolean,
        onProgress: (String) -> Unit
    ): ResearchResult {
        onProgress("🔎 প্রশ্ন বিশ্লেষণ করছি...")
        
        onProgress("📚 Local Knowledge পরীক্ষা করছি...")
        val localResults = localKnowledgeProvider.searchKnowledge(question)
        
        val webResults = webSearchProvider.search(question)
        val youtubeResults = youtubeSearchProvider.search(question)
        
        onProgress("📖 Scripture reference যাচাই করছি...")
        onProgress("🧠 উত্তর তৈরি করছি...")
        
        val finalAnswer = generateFinalAnswer(question, chatHistory, localResults, webResults, youtubeResults)
        return ResearchResult(finalAnswer, webResults, youtubeResults, localResults.take(3))
    }
    
    private suspend fun generateFinalAnswer(
        question: String,
        chatHistory: List<Content>,
        localResults: List<KnowledgeEntity>,
        webResults: List<WebResult>,
        youtubeResults: List<YouTubeResult>
    ): String {
        val todayDate = SimpleDateFormat("dd MMMM yyyy", Locale("bn", "BD")).format(Date())
        
        val systemInstruction = buildString {
            append("You are Dharma AI, a Research-Based Hindu Dharma AI Assistant. Answer purely in Bengali. Current Date: $todayDate.\n")
            append("CRITICAL RULES:\n")
            append("1. Never invent scripture references, shlokas, or mantras.\n")
            append("2. Highlight different traditions if sources disagree.\n")
            append("3. Do NOT claim you searched Google or YouTube if webResults or youtubeResults are empty.\n")
            append("4. Use ONLY the provided Local Knowledge Database context to answer if no web results are provided.\n")
            
            if (webResults.isEmpty() && youtubeResults.isEmpty()) {
                append("\nIMPORTANT FALLBACK INSTRUCTION: External search is currently unavailable. You MUST include this EXACT sentence in your response (either at the start or end): 'বর্তমানে external web research unavailable; verified Dharma Knowledge Base থেকে উত্তর দেওয়া হচ্ছে।'\n")
            }
            
            if (localResults.isEmpty()) {
                append("\nNo exact matching records found in the Local Knowledge Base. Answer respectfully from your general verified Hindu Dharma knowledge, but explicitly mention: 'এই তথ্যের নির্দিষ্ট শাস্ত্রীয় reference Knowledge Base-এ পাওয়া যায়নি।'\n")
            } else {
                append("\n--- Local Dharma Knowledge Base Context ---\n")
                localResults.take(5).forEach { k -> 
                    append("Title: ${k.title}\nCategory: ${k.category}\nScripture: ${k.scripture} (${k.reference})\nContent: ${k.content}\nExplanation: ${k.explanation}\nVerified Status: ${k.verifiedStatus}\n---\n") 
                }
            }
            
            if (webResults.isNotEmpty()) {
                append("\n--- Web Search Results ---\n")
                webResults.forEach { w -> append("- ${w.domain}: ${w.title} (${w.snippet})\n") }
            }
        }
        
        val historyWithQuestion = chatHistory.toMutableList()
        historyWithQuestion.add(Content(role = "user", parts = listOf(Part(text = question))))
        return aiProvider.generateResponse(historyWithQuestion, systemInstruction)
    }
}
""")

# 7. Update AiRepository
write_file('app/src/main/java/com/example/ai/AiRepository.kt', """
package com.example.ai

import com.example.research.ResearchEngine
import com.example.research.WebResult
import com.example.research.YouTubeResult

data class ChatMessage(
    val isUser: Boolean, 
    val text: String, 
    val localSources: List<String> = emptyList(),
    val webSources: List<WebResult> = emptyList(),
    val youtubeSources: List<YouTubeResult> = emptyList()
)

class AiRepository(private val researchEngine: ResearchEngine) {
    suspend fun getAiResponse(
        question: String,
        history: List<ChatMessage>,
        isDeepResearch: Boolean,
        onProgress: (String) -> Unit
    ): ChatMessage {
        val apiHistory = history.map { Content(role = if (it.isUser) "user" else "model", parts = listOf(Part(text = it.text))) }
        val result = researchEngine.conductResearch(question, apiHistory, isDeepResearch, onProgress)
        return ChatMessage(
            isUser = false, 
            text = result.answer, 
            localSources = result.localSources.map { "${it.scripture} (${it.reference})" }.filter { it.isNotBlank() }.distinct(),
            webSources = result.webSources,
            youtubeSources = result.youtubeSources
        )
    }
}
""")

# 8. Update MainActivity to force data reload on startup
write_file('app/src/main/java/com/example/MainActivity.kt', """
package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.ai.AiRepository
import com.example.ai.GeminiAiProvider
import com.example.data.AppDatabase
import com.example.data.KnowledgeSeeder
import com.example.research.ResearchEngine
import com.example.research.WebSearchProvider
import com.example.research.YouTubeSearchProvider
import com.example.ui.chat.ChatScreen
import com.example.ui.chat.ChatViewModel
import com.example.ui.chat.ChatViewModelFactory
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        
        GlobalScope.launch(Dispatchers.IO) {
            val db = AppDatabase.getDatabase(applicationContext)
            // Force reload for this test phase
            db.knowledgeDao().clearAll()
            db.knowledgeDao().insertAll(KnowledgeSeeder.initialData)
        }
        
        setContent {
            MyApplicationTheme(darkTheme = false) { 
                val navController = rememberNavController()
                
                Scaffold(
                    bottomBar = {
                        NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                            NavigationBarItem(
                                icon = { Icon(Icons.Filled.Chat, contentDescription = "Chat") },
                                label = { Text("Chat") },
                                selected = true,
                                onClick = { navController.navigate("chat") { launchSingleTop = true } }
                            )
                            NavigationBarItem(
                                icon = { Icon(Icons.Filled.Search, contentDescription = "Research") },
                                label = { Text("Research") },
                                selected = false,
                                onClick = { navController.navigate("research") { launchSingleTop = true } }
                            )
                            NavigationBarItem(
                                icon = { Icon(Icons.Filled.History, contentDescription = "History") },
                                label = { Text("History") },
                                selected = false,
                                onClick = { navController.navigate("history") { launchSingleTop = true } }
                            )
                        }
                    }
                ) { paddingValues ->
                    NavHost(
                        navController = navController,
                        startDestination = "chat",
                        modifier = Modifier.padding(paddingValues).fillMaxSize()
                    ) {
                        composable("chat") {
                            val context = LocalContext.current
                            val db = AppDatabase.getDatabase(context)
                            val aiProvider = GeminiAiProvider()
                            val webSearchProvider = WebSearchProvider()
                            val youtubeSearchProvider = YouTubeSearchProvider()
                            val researchEngine = ResearchEngine(db.knowledgeDao(), webSearchProvider, youtubeSearchProvider, aiProvider)
                            val repository = AiRepository(researchEngine)
                            
                            val viewModel: ChatViewModel = viewModel(
                                factory = ChatViewModelFactory(repository)
                            )
                            
                            ChatScreen(viewModel = viewModel)
                        }
                        composable("research") { DummyScreen("Deep Research Mode") }
                        composable("history") { DummyScreen("History & Saved") }
                    }
                }
            }
        }
    }
}

@Composable
fun DummyScreen(title: String) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(text = title, style = MaterialTheme.typography.headlineMedium)
    }
}
""")

