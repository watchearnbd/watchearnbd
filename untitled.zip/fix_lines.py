with open('app/src/main/java/com/example/data/KnowledgeSeeder.kt', 'r') as f:
    lines = f.readlines()

for i, line in enumerate(lines):
    if line.strip().startswith('sanskritText = "कर्मण्ये'):
        lines[i] = '            sanskritText = "कर्मण्येवाधिकारस्ते मा फलेषु कदाचन। मा कर्मफलहेतुर्भूर्मा ते सङ्गोऽस्त्वकर्मणि॥",\n'
    if line.strip().startswith('मा कर्मफल'):
        lines[i] = ''
    if line.strip().startswith('transliteration = "karmaṇyev'):
        lines[i] = '            transliteration = "karmaṇyevādhikāraste mā phaleṣu kadācana mā karmaphalaheturbhūrmā te saṅgo\'stvakarmani",\n'
    if line.strip().startswith('mā karma'):
        lines[i] = ''

with open('app/src/main/java/com/example/data/KnowledgeSeeder.kt', 'w') as f:
    f.writelines(lines)
