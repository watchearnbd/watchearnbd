import os

with open('app/build.gradle.kts', 'r') as f:
    text = f.read()

text = text.replace(
    'testOptions {\n        unitTests.all {\n            testLogging {\n                showStandardStreams = true\n            }\n        } unitTests { isIncludeAndroidResources = true } }',
    'testOptions {\n        unitTests { isIncludeAndroidResources = true }\n    }'
)

with open('app/build.gradle.kts', 'w') as f:
    f.write(text)

