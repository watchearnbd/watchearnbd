import os

path = 'app/src/main/java/com/example/ui/chat/ChatViewModel.kt'
with open(path, 'r') as f:
    text = f.read()

new_func = """
    fun updateMessageState(messageId: String, isLiked: Boolean, isDisliked: Boolean, isReported: Boolean) {
        val currentMsgs = _messages.value.toMutableList()
        val index = currentMsgs.indexOfFirst { it.id == messageId }
        if (index != -1) {
            val updatedMsg = currentMsgs[index].copy(
                isLiked = isLiked,
                isDisliked = isDisliked,
                isReported = isReported
            )
            currentMsgs[index] = updatedMsg
            _messages.value = currentMsgs
            saveCurrentSession()
        }
    }
"""

if "fun retry()" in text:
    text = text.replace("fun retry() {", new_func + "\n    fun retry() {")
    with open(path, 'w') as f:
        f.write(text)
    print("ChatViewModel patched.")
else:
    print("Could not find fun retry().")
