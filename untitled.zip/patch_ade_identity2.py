import os

path = 'app/src/main/java/com/example/ai/AdvancedDecisionEngine.kt'
if not os.path.exists(path):
    print("File not found")
    exit(1)

with open(path, 'r') as f:
    text = f.read()

target = """        if (lowerMessage.contains("তোমার নাম কী") || lowerMessage.contains("তোমার নাম কি") || lowerMessage.contains("what is your name")) {
            return@withContext buildUnverifiedResponse("আমার নাম Dharma AI। 🙏")
        }"""

replacement = """        val identityQueries = listOf("তোমার নাম কী", "তোমার নাম কি", "what is your name", "তুমি কে", "তোমাকে কী নামে ডাকা হয়", "তোমাকে কি নামে ডাকা হয়", "তুমি কী", "তুমি কি")
        if (identityQueries.any { lowerMessage.contains(it) }) {
            return@withContext buildUnverifiedResponse("আমার নাম Dharma AI। 🙏")
        }"""

if target in text:
    text = text.replace(target, replacement)
    with open(path, 'w') as f:
        f.write(text)
    print("Patched ADE identity queries")
else:
    print("Could not find identity target in ADE")
