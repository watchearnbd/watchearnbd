import os

with open('app/src/test/java/com/example/ExampleRobolectricTest.kt', 'r') as f:
    text = f.read()

target = 'assertEquals("My Application", appName)'
replacement = 'assertEquals("Dharma AI", appName)'

text = text.replace(target, replacement)

with open('app/src/test/java/com/example/ExampleRobolectricTest.kt', 'w') as f:
    f.write(text)

