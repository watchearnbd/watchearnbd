import os

with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    text = f.read()

text = text.replace(
    'import com.example.ai.ConversationBrain',
    'import com.example.ai.ConversationBrain\nimport com.example.ai.AdvancedDecisionEngine'
)

text = text.replace(
    'val repository = remember { AiRepository(researchEngine) }\n                    val conversationBrain = remember { ConversationBrain(repository) }',
    'val repository = remember { AiRepository(researchEngine) }\n                    val conversationBrain = remember { ConversationBrain() }\n                    val decisionEngine = remember { AdvancedDecisionEngine(conversationBrain, researchEngine, aiProvider) }'
)

text = text.replace(
    'factory = ChatViewModelFactory(conversationBrain, repository, db.chatSessionDao())',
    'factory = ChatViewModelFactory(decisionEngine, repository, db.chatSessionDao())'
)

with open('app/src/main/java/com/example/MainActivity.kt', 'w') as f:
    f.write(text)

