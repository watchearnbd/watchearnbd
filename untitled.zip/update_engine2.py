import re

with open("app/src/main/java/com/example/research/ResearchEngine.kt", "r") as f:
    content = f.read()

new_web_verification = """        // Source ranking and verification for web
        webResults.forEach {
            var relevance = 50
            var sType = "General web source"
            var vStatus = VerificationStatus.NOT_VERIFIED
            
            val domainLower = it.domain.lowercase()
            val titleLower = it.title.lowercase()
            
            // Basic source ranking logic
            if (domainLower.contains("vedabase") || domainLower.contains("sacred-texts") || domainLower.contains("gita-society")) {
                relevance = 90
                sType = "Primary Scripture / authoritative text"
                vStatus = VerificationStatus.PARTIALLY_VERIFIED
            } else if (domainLower.contains("ramakrishna") || domainLower.contains("iskcon") || domainLower.contains("chinmaya") || domainLower.contains("chabad")) {
                relevance = 80
                sType = "Trusted religious source"
                vStatus = VerificationStatus.PARTIALLY_VERIFIED
            } else if (domainLower.contains(".edu") || domainLower.contains("university") || domainLower.contains("scholar") || domainLower.contains("oxford") || domainLower.contains("cambridge")) {
                relevance = 75
                sType = "Academic / educational source"
                vStatus = VerificationStatus.PARTIALLY_VERIFIED
            } else if (domainLower.contains("wikipedia.org") || domainLower.contains("britannica")) {
                relevance = 60
                sType = "Established reference"
                vStatus = VerificationStatus.NOT_VERIFIED
            }
            
            sourceMetadataList.add(
                SourceMetadata(
                    title = it.title,
                    domain = it.domain,
                    sourceType = sType,
                    reference = it.link,
                    summary = it.snippet.take(100) + "...",
                    relevanceScore = relevance,
                    verificationStatus = vStatus
                )
            )
            
            if (vStatus == VerificationStatus.PARTIALLY_VERIFIED) hasPartiallyVerified = true
            else if (vStatus == VerificationStatus.NOT_VERIFIED) hasNotVerified = true
        }
        
        // Sort by relevance score
        sourceMetadataList.sortByDescending { it.relevanceScore }"""

content = re.sub(r'        // Mock verification for web/youtube.*?hasNotVerified = true\n        }', new_web_verification, content, flags=re.DOTALL)

with open("app/src/main/java/com/example/research/ResearchEngine.kt", "w") as f:
    f.write(content)

