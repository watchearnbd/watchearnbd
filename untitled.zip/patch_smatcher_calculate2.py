import os
import re

path = 'app/src/main/java/com/example/ai/SmartKnowledgeMatcher.kt'
if not os.path.exists(path):
    print("File not found")
    exit(1)

with open(path, 'r') as f:
    text = f.read()

replacement = """    private fun calculateScore(normalizedQuery: String, entity: KnowledgeEntity): Double {
        val titleNorm = normalize(entity.title)
        val aliases = entity.tags.split(",").map { normalize(it) }

        val querySemantic = semanticNormalize(normalizedQuery)
        val titleSemantic = semanticNormalize(entity.title)
        val aliasesSemantic = entity.tags.split(",").map { semanticNormalize(it) }

        // 1. Exact Title Match
        if (normalizedQuery == titleNorm || querySemantic == titleSemantic) return 1.0

        // 2. Exact Alias Match
        if (aliases.any { it == normalizedQuery } || aliasesSemantic.any { it == querySemantic }) return 0.95"""

pattern = r'    private fun calculateScore\(normalizedQuery: String, entity: KnowledgeEntity\): Double \{\s*val titleNorm = normalize\(entity\.title\)\s*val aliases = entity\.tags\.split\("\,"\)\[^\]]*// 1\. Exact Title Match\s*if \(normalizedQuery == titleNorm\) return 1\.0\s*// 2\. Exact Alias Match\s*if \(aliases\.any \{ it == normalizedQuery \}\) return 0\.95'

# Wait, regex is too brittle. Let's just do a string replace on a smaller chunk.
t1 = """    private fun calculateScore(normalizedQuery: String, entity: KnowledgeEntity): Double {
        val titleNorm = normalize(entity.title)
        val aliases = entity.tags.split(",").map { normalize(it) }

        // 1. Exact Title Match
        if (normalizedQuery == titleNorm) return 1.0

        // 2. Exact Alias Match
        if (aliases.any { it == normalizedQuery }) return 0.95"""

if t1 in text:
    text = text.replace(t1, replacement)
    with open(path, 'w') as f:
        f.write(text)
    print("Patched calculateScore (t1)")
else:
    print("t1 not found. trying regex.")

