import re

with open("app/src/main/java/com/example/ui/chat/ChatScreen.kt", "r") as f:
    content = f.read()

# Replace ChatMessageItem entirely
new_item = """@Composable
fun ChatMessageItem(message: ChatMessage) {
    if (message.isUser) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.End
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.85f)
                    .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 0.dp, bottomEnd = 16.dp, bottomStart = 16.dp))
                    .background(EditorialOrange600)
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Text(text = message.text, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium, lineHeight = 20.sp)
            }
            Text("Just now", fontSize = 10.sp, color = EditorialSlate400, modifier = Modifier.padding(top = 4.dp, end = 4.dp))
        }
    } else {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.Start
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .clip(RoundedCornerShape(topStart = 0.dp, topEnd = 16.dp, bottomEnd = 16.dp, bottomStart = 16.dp))
                    .background(Color.White)
                    .border(1.dp, EditorialOrange100, RoundedCornerShape(topStart = 0.dp, topEnd = 16.dp, bottomEnd = 16.dp, bottomStart = 16.dp))
                    .padding(16.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(bottom = 8.dp)
                ) {
                    Text("AI RESPONSE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFFC2410C), modifier = Modifier.background(EditorialOrange100, RoundedCornerShape(4.dp)).padding(horizontal = 6.dp, vertical = 2.dp))
                    HorizontalDivider(color = EditorialOrange50, modifier = Modifier.weight(1f))
                }
                
                Text(
                    text = message.text,
                    color = EditorialSlate800,
                    fontSize = 14.sp,
                    lineHeight = 22.sp,
                    fontFamily = FontFamily.Serif
                )
                
                if (message.verificationStatus != VerificationStatus.NONE) {
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("🔎 Verification: ", fontSize = 11.sp, color = EditorialSlate500, fontWeight = FontWeight.Bold)
                        val (statusText, statusColor) = when (message.verificationStatus) {
                            VerificationStatus.VERIFIED -> "✅ Verified" to EditorialGreen500
                            VerificationStatus.PARTIALLY_VERIFIED -> "⚠️ Partially Verified" to Color(0xFFD97706)
                            VerificationStatus.NOT_VERIFIED -> "❓ Not Verified" to Color(0xFFDC2626)
                            else -> "" to Color.Transparent
                        }
                        Text(statusText, fontSize = 11.sp, color = statusColor, fontWeight = FontWeight.Bold)
                    }
                }
                
                if (message.sourceMetadata.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("📚 Sources:", fontSize = 11.sp, color = EditorialSlate500, fontWeight = FontWeight.Bold)
                    message.sourceMetadata.forEach { src ->
                        val icon = if (src.sourceType.contains("web", ignoreCase = true)) "🌐" else "📜"
                        Text(
                            text = "$icon ${src.title} - ${src.reference}", 
                            fontSize = 11.sp, 
                            color = EditorialSlate700,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                        Text(
                            text = "Status: ${src.verificationStatus.name.replace("_", " ")}",
                            fontSize = 9.sp,
                            color = EditorialSlate400,
                            modifier = Modifier.padding(start = 16.dp)
                        )
                    }
                }
            }
        }
    }
}
"""

content = re.sub(r'@Composable\nfun ChatMessageItem\(message: ChatMessage\) \{.*', new_item, content, flags=re.DOTALL)

with open("app/src/main/java/com/example/ui/chat/ChatScreen.kt", "w") as f:
    f.write(content)

