import re

with open("app/src/main/java/com/example/research/Providers.kt", "r") as f:
    content = f.read()

# Update YouTubeResult definition
content = content.replace(
    "data class YouTubeResult(val title: String, val channelTitle: String, val videoId: String, val description: String)",
    "data class YouTubeResult(val title: String, val channelTitle: String, val videoId: String, val description: String, val thumbnailUrl: String = \"\", val publishedAt: String = \"\")"
)

# Replace YouTubeSearchProviderImpl
new_yt_provider = """class YouTubeSearchProviderImpl : IYouTubeSearchProvider {
    override suspend fun search(query: String): List<YouTubeResult> {
        val apiKey = com.example.BuildConfig.YOUTUBE_API_KEY
        
        if (apiKey.isEmpty() || apiKey == "MY_YOUTUBE_API_KEY") {
            println("YouTube Research: NOT CONFIGURED")
            return emptyList()
        }
        
        return try {
            val response = YouTubeSearchRetrofit.service.search(query = query, apiKey = apiKey)
            response.items?.mapNotNull { item ->
                val videoId = item.id?.videoId ?: return@mapNotNull null
                val snippet = item.snippet ?: return@mapNotNull null
                
                YouTubeResult(
                    title = snippet.title ?: "",
                    channelTitle = snippet.channelTitle ?: "",
                    videoId = videoId,
                    description = snippet.description ?: "",
                    thumbnailUrl = snippet.thumbnails?.high?.url ?: "",
                    publishedAt = snippet.publishedAt ?: ""
                )
            } ?: emptyList()
        } catch (e: Exception) {
            println("YouTube Research Error: ${e.message}")
            emptyList()
        }
    }
}"""

content = re.sub(r'class YouTubeSearchProviderImpl : IYouTubeSearchProvider \{.*?\}', new_yt_provider, content, flags=re.DOTALL)

with open("app/src/main/java/com/example/research/Providers.kt", "w") as f:
    f.write(content)

