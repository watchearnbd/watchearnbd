import urllib.request
import json
import os

api_key = os.environ.get("GEMINI_API_KEY", "AQ.Ab8RN6KedkxQbBNxo0jNuvGUqnAEDobXB3F4dv3byqHmB8vH9Q")
url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key={api_key}"

system_instruction = """
You are the "Conversation Brain" of Dharma AI.
Analyze the user's latest query considering the recent chat history.

1. INTENT DETECTION: Array of strings. Valid intents: GREETING, QUESTION, FOLLOW_UP, CLARIFICATION, REQUEST_FOR_EXAMPLE, REQUEST_FOR_SIMPLIFICATION, REQUEST_FOR_COMPARISON, REQUEST_FOR_STEPS, REQUEST_FOR_SOURCE, REQUEST_FOR_REFERENCE, REQUEST_FOR_MEANING, REQUEST_FOR_DEFINITION, REQUEST_FOR_RESEARCH, CASUAL_CONVERSATION, CORRECTION, DISAGREEMENT, FEEDBACK, UNKNOWN.
2. CONTEXT RESOLUTION: If the query has pronouns ("এটা", "এর", "ওটা"), resolve them from history and provide the 'resolvedQuery'. Example: User says "এর অর্থ কী?" after AI talked about "গায়ত্রী মন্ত্র". resolvedQuery should be "গায়ত্রী মন্ত্রের অর্থ কী?". If no resolution needed, resolvedQuery = original query.
3. AMBIGUITY CHECK: Only ask for clarification if the ambiguity significantly changes the meaning (e.g., "শক্তি" as Physics vs Hindu Goddess). Do NOT clarify if the intent is clear (e.g., "কর্মযোগ কী?"). If clarification needed, set 'clarificationNeeded' with a polite question in Bengali. Otherwise, set it to null.
4. RESPONSE DEPTH: SHORT, MEDIUM, DETAILED, RESEARCH, STEP_BY_STEP.
5. USER KNOWLEDGE LEVEL: BEGINNER, INTERMEDIATE, ADVANCED.
6. TONE: CONFUSED, CURIOUS, FRUSTRATED, EXCITED, NEUTRAL.

Return ONLY a valid JSON object matching this structure:
{
    "currentTopic": "Topic or null",
    "previousTopic": "Topic or null",
    "userIntents": ["INTENT1", "INTENT2"],
    "conversationGoal": "Goal or null",
    "importantEntities": ["entity1"],
    "referencedEntities": ["resolved entity"],
    "responseDepth": "MEDIUM",
    "userKnowledgeLevel": "BEGINNER",
    "detectedTone": "NEUTRAL",
    "resolvedQuery": "The resolved query without ambiguity",
    "clarificationNeeded": "Clarification question or null"
}
"""

queries = [
    "হাই",
    "কর্মযোগ কী?",
    "এটা কী?",
    "এর মানে কী?",
    "আরও সহজ করে বলো",
    "একটা উদাহরণ দাও",
    "শক্তি কী?",
    "আমি এটা বোঝাইনি",
    "আমি বুঝতে পারছি না",
    "গায়ত্রী মন্ত্র শিখতে চাই"
]

history = []

for q in queries:
    history_str = "\n".join([f"{'User' if m['role'] == 'user' else 'AI'}: {m['parts'][0]['text']}" for m in history])
    prompt = f"Recent History:\n{history_str}\n\nLatest User Query: {q}"
    
    payload = {
        "systemInstruction": {
            "parts": [{"text": system_instruction}]
        },
        "contents": [
            {"role": "user", "parts": [{"text": prompt}]}
        ],
        "generationConfig": {
            "responseMimeType": "application/json"
        }
    }
    
    req = urllib.request.Request(url, data=json.dumps(payload).encode('utf-8'), headers={'Content-Type': 'application/json'})
    try:
        with urllib.request.urlopen(req) as response:
            res_data = json.loads(response.read().decode())
            print(f"\n----- QUERY: {q} -----")
            print(f"A: {res_data['candidates'][0]['content']['parts'][0]['text']}\n")
    except Exception as e:
        print(f"Error on {q}: {e}")
        
    history.append({"role": "user", "parts": [{"text": q}]})
    history.append({"role": "model", "parts": [{"text": f"Simulated answer for {q}."}]})

