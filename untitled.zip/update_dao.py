import re

with open('app/src/main/java/com/example/data/KnowledgeDao.kt', 'r') as f:
    content = f.read()

new_query = """    @Query(\"\"\"
        SELECT * FROM knowledge 
        WHERE title LIKE '%' || :query || '%' 
        OR content LIKE '%' || :query || '%'
        OR explanation LIKE '%' || :query || '%'
        OR tags LIKE '%' || :query || '%'
        OR scripture LIKE '%' || :query || '%'
        OR category LIKE '%' || :query || '%'
        OR subcategory LIKE '%' || :query || '%'
        OR sanskritText LIKE '%' || :query || '%'
        OR transliteration LIKE '%' || :query || '%'
        OR banglaMeaning LIKE '%' || :query || '%'
        OR chapter LIKE '%' || :query || '%'
        OR verse LIKE '%' || :query || '%'
    \"\"\")"""

content = re.sub(r'@Query\(\"\"\"\s*SELECT \* FROM knowledge.*?\"\"\"\)', new_query, content, flags=re.DOTALL)

with open('app/src/main/java/com/example/data/KnowledgeDao.kt', 'w') as f:
    f.write(content)

print("Updated KnowledgeDao.kt")
