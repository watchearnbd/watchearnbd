import os
import re

path = 'app/src/main/java/com/example/research/Providers.kt'
with open(path, 'r') as f:
    text = f.read()

if "getAllKnowledge" not in text:
    text = text.replace("suspend fun search(query: String): List<KnowledgeEntity>",
                        "suspend fun search(query: String): List<KnowledgeEntity>\n    suspend fun getAllKnowledge(): List<KnowledgeEntity>")
    text = text.replace("return dao.searchKnowledge(query)\n    }",
                        "return dao.searchKnowledge(query)\n    }\n\n    override suspend fun getAllKnowledge(): List<KnowledgeEntity> {\n        return dao.getAllKnowledge()\n    }")
    with open(path, 'w') as f:
        f.write(text)
    print("Patched Providers.kt")
