import os
import re

ade_path = 'app/src/main/java/com/example/ai/AdvancedDecisionEngine.kt'
with open(ade_path, 'r') as f:
    text = f.read()

new_code = """package com.example.ai

import com.example.research.ILocalKnowledgeProvider
import com.example.data.KnowledgeEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class AdvancedDecisionEngine(
    private val localKnowledgeProvider: ILocalKnowledgeProvider,
    private val aiProvider: AiProvider // Retained for constructor signature, but NOT USED to enforce API ban.
) {
    suspend fun processPipeline(
        userMessage: String,
        history: List<ChatMessage>,
        isDeepResearch: Boolean,
        onProgress: (String) -> Unit
    ): ChatMessage = withContext(Dispatchers.IO) {
        
        onProgress("Internal Brain: Analyzing Intent & Context...")
        
        val rawMessage = userMessage.trim()
        val lowerMessage = rawMessage.lowercase()
        val lastAiMsg = history.lastOrNull { !it.isUser }?.text ?: ""
        val lastUserMsg = history.lastOrNull { it.isUser }?.text ?: ""
        
        // --- 1. ACKNOWLEDGMENTS & SHORT RESPONSES ---
        if (isAcknowledgment(lowerMessage)) {
            val responses = listOf(
                "জি, আর কোনো বিষয়ে জানতে চান?",
                "বুঝতে পেরেছি। আপনার আধ্যাত্মিক জিজ্ঞাসা থাকলে করতে পারেন।",
                "আচ্ছা! শাস্ত্র বা ধর্ম সম্পর্কে অন্য কোনো প্রশ্ন আছে কি?",
                "ঠিক আছে। আমি কি আপনাকে অন্য কোনোভাবে সাহায্য করতে পারি?"
            )
            val validResponses = responses.filter { it != lastAiMsg }
            return@withContext buildUnverifiedResponse(validResponses.randomOrNull() ?: responses.first())
        }

        if (isAgreement(lowerMessage)) {
            val responses = listOf(
                "জি, আপনার আর কোনো প্রশ্ন থাকলে করতে পারেন।",
                "হ্যাঁ, আর কোনো বিষয় জানার থাকলে বলুন।"
            )
            val validResponses = responses.filter { it != lastAiMsg }
            return@withContext buildUnverifiedResponse(validResponses.randomOrNull() ?: responses.first())
        }

        // --- 2. GREETINGS & SMALL TALK ---
        if (isGreeting(lowerMessage)) {
            val responses = listOf(
                "নমস্কার 🙏 হাই! কেমন আছো? আজ কী নিয়ে কথা বলতে চাও?",
                "হ্যালো 🙏 তোমাকে স্বাগতম। কী জানতে বা আলোচনা করতে চাও?",
                "নমস্কার 🙏 শুভেচ্ছা রইল। আজ কী নিয়ে জানতে বা কথা বলতে চাও?"
            )
            val validResponses = responses.filter { it != lastAiMsg }
            return@withContext buildUnverifiedResponse(validResponses.randomOrNull() ?: responses.first())
        }
        if (isHowAreYou(lowerMessage)) {
            val responses = listOf(
                "আমি ভালো আছি 😊 তোমার সঙ্গে কথা বলতে প্রস্তুত। তুমি কেমন আছো?",
                "আমি বেশ ভালো আছি। তুমি কেমন আছো? আজ কী বিষয়ে কথা বলবো?",
                "আমি ভালো আছি 🙏 আপনার দিনটি কেমন যাচ্ছে?"
            )
            val validResponses = responses.filter { it != lastAiMsg }
            return@withContext buildUnverifiedResponse(validResponses.randomOrNull() ?: responses.first())
        }
        if (isWhatDoYouDo(lowerMessage)) {
            val responses = listOf(
                "তোমার প্রশ্নের উত্তর দেওয়া আর Dharma ও সাধারণ জ্ঞান নিয়ে সাহায্য করাই আমার কাজ। 😊",
                "আমি তোমার প্রশ্নের উত্তর দিতে এবং ধর্ম, শাস্ত্র ও নানা বিষয় নিয়ে কথা বলার জন্য প্রস্তুত। 😊"
            )
            val validResponses = responses.filter { it != lastAiMsg }
            return@withContext buildUnverifiedResponse(validResponses.randomOrNull() ?: responses.first())
        }

        // --- 3. CORRECTION BRAIN (Specific rules for common misconceptions) ---
        if (lowerMessage.contains("গীতা") && lowerMessage.contains("অধ্যায়")) {
            val hasWrongChapter = listOf("২৫", "25", "কুড়ি", "তিরিশ", "১০০", "100", "১০", "10", "১৫", "15", "৭", "7").any { lowerMessage.contains(it) }
            val hasCorrectChapter = lowerMessage.contains("১৮") || lowerMessage.contains("18") || lowerMessage.contains("আঠারো")
            if (hasWrongChapter && !hasCorrectChapter) {
                return@withContext buildUnverifiedResponse("এখানে একটি ছোট সংশোধন আছে 🙏 ভগবদ্গীতায় মোট ১৮টি অধ্যায় রয়েছে।")
            }
        }
        
        // --- 4. AMBIGUITY BRAIN ---
        if (lowerMessage == "শক্তি কী?" || lowerMessage == "শক্তি কি?" || lowerMessage == "শক্তি কি" || lowerMessage == "শক্তি কী") {
            return@withContext buildUnverifiedResponse("আপনি ‘শক্তি’ বলতে হিন্দু দর্শনের Shakti তত্ত্ব বোঝাচ্ছেন, নাকি Physics-এর energy বোঝাচ্ছেন?")
        }

        // --- 5. CONTEXT AWARENESS & COREFERENCE RESOLUTION ---
        var effectiveQuery = rawMessage
        var isFollowUp = false
        
        val followUpKeywords = listOf("এটা", "ওটা", "এর", "কেন", "আরও", "বিস্তারিত", "মানে", "বুঝলাম না", "তার", "সেটার", "উদাহরণ", "তারপর", "তারপরে")
        val isShortQuery = rawMessage.length <= 15

        if (followUpKeywords.any { lowerMessage.contains(it) } || isShortQuery) {
            val isPrevGeneric = isGreeting(lastUserMsg.lowercase()) || isHowAreYou(lastUserMsg.lowercase()) || isWhatDoYouDo(lastUserMsg.lowercase()) || isAcknowledgment(lastUserMsg.lowercase()) || isAgreement(lastUserMsg.lowercase())
            
            if (lastUserMsg.isNotBlank() && !lastUserMsg.equals(rawMessage, ignoreCase = true) && !isPrevGeneric) {
                isFollowUp = true
                effectiveQuery = "$lastUserMsg $rawMessage"
            }
        }

        // --- 6. CLARIFICATION RULE ---
        if (effectiveQuery.length < 3 && !isFollowUp) {
            return@withContext buildUnverifiedResponse("আপনার প্রশ্নটি অস্পষ্ট। আপনি কি আরেকটু বিস্তারিতভাবে বলবেন?")
        }

        // --- 7. KNOWLEDGE BASE SEARCH ---
        onProgress("Internal Brain: Searching Local Knowledge Base...")
        var results = localKnowledgeProvider.search(effectiveQuery)
        
        if (results.isEmpty()) {
            val keywords = effectiveQuery.split(Regex("[\\\\s\\\\p{Punct}]+")).filter { it.length > 2 }
            if (keywords.isNotEmpty()) {
                val kwResults = mutableListOf<KnowledgeEntity>()
                for (keyword in keywords) {
                    kwResults.addAll(localKnowledgeProvider.search(keyword))
                }
                // Sort by keyword match frequency to ensure best match
                results = kwResults.groupBy { it.id }
                    .map { it.value.first() }
                    .sortedByDescending { entity -> 
                        keywords.count { kw -> 
                            entity.title.contains(kw, ignoreCase = true) || 
                            entity.content.contains(kw, ignoreCase = true) ||
                            entity.banglaMeaning.contains(kw, ignoreCase = true) ||
                            entity.explanation.contains(kw, ignoreCase = true)
                        }
                    }.take(3)
            }
        }

        // --- 8. UNKNOWN / OUT OF DOMAIN RESPONSE (MANTRA/SCRIPTURE SAFETY) ---
        if (results.isEmpty()) {
            val religiousTerms = listOf("গীতা", "বেদ", "ঈশ্বর", "ধর্ম", "কৃষ্ণ", "রাম", "পূজা", "মন্ত্র", "শ্লোক", "ভগবান", "শিব", "কালী", "হিন্দু")
            val hasReligiousTerm = religiousTerms.any { effectiveQuery.contains(it) }
            
            val isMantraOrSloka = lowerMessage.contains("মন্ত্র") || lowerMessage.contains("শ্লোক")
            
            if (!hasReligiousTerm && !isFollowUp) {
                val outOfDomainResponses = listOf(
                    "আমি একটি ধর্মীয় ও শাস্ত্রীয় সহায়ক। আপনার প্রশ্নটি আমার বিষয়ের বাইরের বলে মনে হচ্ছে। শাস্ত্র বা ধর্ম সম্পর্কিত কিছু জানতে চাইলে আমাকে জিজ্ঞেস করতে পারেন।",
                    "আমার মূল কাজ হলো শাস্ত্র ও ধর্ম নিয়ে আলোচনা করা। এ বিষয়ে কিছু জানতে চাইলে বলতে পারেন।"
                )
                val validOutOfDomain = outOfDomainResponses.filter { it != lastAiMsg }
                return@withContext buildUnverifiedResponse(validOutOfDomain.randomOrNull() ?: outOfDomainResponses.first())
            }
            
            if (isMantraOrSloka) {
                return@withContext buildUnverifiedResponse("এই মন্ত্র বা শ্লোকটির নির্ভরযোগ্য পাঠ বা উৎস আমি নিশ্চিতভাবে যাচাই করতে পারিনি। ভুল তথ্য দেওয়ার চেয়ে আমি সেটা পরিষ্কারভাবে জানাচ্ছি।")
            }
            
            // CRITICAL TRUTH RULE implementation
            return@withContext buildUnverifiedResponse("এই তথ্যটি সম্পর্কে আমি নিশ্চিত নই। ভুল তথ্য দেওয়ার চেয়ে আমি সেটা পরিষ্কারভাবে জানাচ্ছি।")
        }

        // --- 9. RESPONSE GENERATION (RULE-BASED NLG) ---
        onProgress("Internal Brain: Formatting Final Answer...")
        val primaryResult = results.first()
        val sb = java.lang.StringBuilder()
        
        val isDetailed = listOf("বিস্তারিত", "আরও", "সব", "ব্যাখ্যা", "বুঝিয়ে").any { lowerMessage.contains(it) }
        val isMeaning = listOf("মানে", "অর্থ", "বলতে কী", "কি বোঝায়").any { lowerMessage.contains(it) }
        val isExample = listOf("উদাহরণ", "যেমন").any { lowerMessage.contains(it) }
        val isReasoning = listOf("কেন", "কারণ").any { lowerMessage.contains(it) }

        if (isDetailed) {
            if (primaryResult.content.isNotBlank()) sb.append(primaryResult.content).append("\\n\\n")
            if (primaryResult.sanskritText.isNotBlank()) sb.append("মূল শ্লোক/মন্ত্র:\\n${primaryResult.sanskritText}\\n\\n")
            if (primaryResult.banglaMeaning.isNotBlank()) sb.append("অর্থ:\\n${primaryResult.banglaMeaning}\\n\\n")
            if (primaryResult.explanation.isNotBlank()) sb.append("ব্যাখ্যা:\\n${primaryResult.explanation}")
        } else if (isMeaning) {
            if (primaryResult.banglaMeaning.isNotBlank()) {
                sb.append(primaryResult.banglaMeaning)
                if (primaryResult.explanation.isNotBlank()) sb.append("\\n\\nব্যাখ্যা: ").append(primaryResult.explanation)
            } else if (primaryResult.explanation.isNotBlank()) {
                sb.append(primaryResult.explanation)
            } else {
                sb.append(primaryResult.content)
            }
        } else if (isExample || isReasoning) {
             if (primaryResult.explanation.isNotBlank()) {
                 sb.append(primaryResult.explanation)
             } else {
                 sb.append(primaryResult.content)
             }
        } else {
            // Concise response
            if (primaryResult.content.isNotBlank()) {
                sb.append(primaryResult.content)
            } else if (primaryResult.banglaMeaning.isNotBlank()) {
                sb.append(primaryResult.banglaMeaning)
            } else if (primaryResult.explanation.isNotBlank()) {
                sb.append(primaryResult.explanation)
            }
            if (primaryResult.sanskritText.isNotBlank() && !isShortQuery) {
                 sb.append("\\n\\n(শ্লোক: ${primaryResult.sanskritText})")
            }
        }
        
        var finalResponse = sb.toString().trim()
        if (finalResponse.isEmpty()) {
            return@withContext buildUnverifiedResponse("এই তথ্যটি সম্পর্কে আমি নিশ্চিত নই। ভুল তথ্য দেওয়ার চেয়ে আমি সেটা পরিষ্কারভাবে জানাচ্ছি।")
        }

        val sourcesList = results.map { "${it.scripture} (${it.reference})".trim() }.filter { it.length > 3 }.distinct()

        return@withContext ChatMessage(
            isUser = false,
            text = finalResponse,
            localSources = sourcesList,
            verificationStatus = com.example.research.VerificationStatus.VERIFIED
        )
    }

    private fun isGreeting(text: String): Boolean {
        val greetings = listOf("হাই", "হ্যালো", "নমস্কার", "প্রণাম", "hi", "hello", "nomoshkar")
        val cleanText = text.replace(Regex("\\\\p{Punct}"), "")
        return greetings.any { cleanText == it || cleanText.startsWith("$it ") }
    }

    private fun isHowAreYou(text: String): Boolean {
        val patterns = listOf("কেমন আছো", "কেমন আছেন", "how are you", "কেমন আছ", "ক্যামন আছো", "কেমন চলল", "কেমন চলছে")
        return patterns.any { text.contains(it) }
    }

    private fun isWhatDoYouDo(text: String): Boolean {
        val patterns = listOf("কি করো", "কী করো", "কি খবর", "কী খবর", "কি করছো", "কী করছো", "what do you do", "what are you doing", "whats up", "what's up")
        return patterns.any { text.contains(it) }
    }

    private fun isAcknowledgment(text: String): Boolean {
        val cleanText = text.replace(Regex("\\\\p{Punct}"), "").trim()
        val patterns = listOf("ঠিক আছে", "আচ্ছা", "ওকে", "ok", "okay", "হুম", "হু", "বুঝলাম", "শুনছি")
        return patterns.any { cleanText == it }
    }

    private fun isAgreement(text: String): Boolean {
        val cleanText = text.replace(Regex("\\\\p{Punct}"), "").trim()
        val patterns = listOf("হ্যাঁ", "হ্যা", "yes", "না", "no", "জি", "জী")
        return patterns.any { cleanText == it }
    }

    private fun buildUnverifiedResponse(text: String): ChatMessage {
        return ChatMessage(
            isUser = false,
            text = text,
            localSources = emptyList(),
            verificationStatus = com.example.research.VerificationStatus.NONE
        )
    }
}
"""

with open(ade_path, 'w') as f:
    f.write(new_code)

print("Patch applied.")
