package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "saved_items")
data class SavedItemEntity(
    @PrimaryKey val id: String, // UUID or predictable ID
    val type: String, // "CHAT", "FAVORITE", "BOOKMARK"
    
    val title: String,
    val question: String? = null,
    val answer: String,
    
    val category: String = "",
    val scripture: String = "",
    val reference: String = "",
    val source: String = "",
    val verificationStatus: String = "NONE",
    val sourceMetadataJson: String = "[]",
    val tags: String = "",
    
    val createdDate: Long = System.currentTimeMillis(),
    val updatedDate: Long = System.currentTimeMillis()
)
