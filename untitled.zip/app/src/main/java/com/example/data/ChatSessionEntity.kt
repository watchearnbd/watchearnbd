package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "chat_sessions")
data class ChatSessionEntity(
    @PrimaryKey val id: String,
    val title: String,
    val createdDate: Long,
    val updatedDate: Long,
    val messageCount: Int,
    val chatMode: String, // "NORMAL" or "DEEP_RESEARCH"
    val lastMessagePreview: String,
    val messagesJson: String,
    val isPinned: Boolean = false
)
