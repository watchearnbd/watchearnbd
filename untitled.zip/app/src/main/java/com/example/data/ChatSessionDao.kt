package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ChatSessionDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(chatSession: ChatSessionEntity)

    @Query("DELETE FROM chat_sessions WHERE id = :id")
    suspend fun deleteById(id: String)
    
    @Query("SELECT * FROM chat_sessions ORDER BY isPinned DESC, updatedDate DESC")
    fun getAllChatSessions(): Flow<List<ChatSessionEntity>>

    @Query("SELECT * FROM chat_sessions WHERE title LIKE '%' || :query || '%' OR messagesJson LIKE '%' || :query || '%' ORDER BY isPinned DESC, updatedDate DESC")
    fun searchChatSessions(query: String): Flow<List<ChatSessionEntity>>
    
    @Query("SELECT * FROM chat_sessions WHERE id = :id LIMIT 1")
    suspend fun getChatSessionById(id: String): ChatSessionEntity?
    
    @Query("DELETE FROM chat_sessions")
    suspend fun deleteAllChatSessions()
}
