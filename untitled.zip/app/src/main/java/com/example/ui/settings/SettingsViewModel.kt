package com.example.ui.settings

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.SettingsRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = SettingsRepository(application)
    private val db = AppDatabase.getDatabase(application)

    val themePreference: StateFlow<String> = repository.themePreference.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = "System"
    )

    val textSize: StateFlow<String> = repository.textSize.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = "Medium"
    )

    val languagePreference: StateFlow<String> = repository.languagePreference.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = "বাংলা"
    )

    val defaultChatMode: StateFlow<String> = repository.defaultChatMode.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = "Normal Chat"
    )

    val researchBehavior: StateFlow<String> = repository.researchBehavior.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = "Balanced"
    )

    val showSources: StateFlow<Boolean> = repository.showSources.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = true
    )

    val scriptureSourceDisplay: StateFlow<Boolean> = repository.scriptureSourceDisplay.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = true
    )

    val verificationBadgeDisplay: StateFlow<Boolean> = repository.verificationBadgeDisplay.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = true
    )

    val ttsEnabled: StateFlow<Boolean> = repository.ttsEnabled.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = true
    )

    val ttsSpeed: StateFlow<Float> = repository.ttsSpeed.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = 1.0f
    )

    val voiceInput: StateFlow<String> = repository.voiceInput.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = "Default"
    )
    
    val notificationsEnabled: StateFlow<Boolean> = repository.notificationsEnabled.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = true
    )

    val dailyDharmaReminder: StateFlow<Boolean> = repository.dailyDharmaReminder.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = true
    )

    val festivalReminder: StateFlow<Boolean> = repository.festivalReminder.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = true
    )

    val chatHistoryControl: StateFlow<String> = repository.chatHistoryControl.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = "Keep until I delete"
    )

    fun setThemePreference(theme: String) {
        viewModelScope.launch { repository.setThemePreference(theme) }
    }

    fun setTextSize(size: String) {
        viewModelScope.launch { repository.setTextSize(size) }
    }

    fun setLanguagePreference(language: String) {
        viewModelScope.launch { repository.setLanguagePreference(language) }
    }

    fun setDefaultChatMode(mode: String) {
        viewModelScope.launch { repository.setDefaultChatMode(mode) }
    }

    fun setResearchBehavior(behavior: String) {
        viewModelScope.launch { repository.setResearchBehavior(behavior) }
    }

    fun setShowSources(show: Boolean) {
        viewModelScope.launch { repository.setShowSources(show) }
    }

    fun setScriptureSourceDisplay(show: Boolean) {
        viewModelScope.launch { repository.setScriptureSourceDisplay(show) }
    }

    fun setVerificationBadgeDisplay(show: Boolean) {
        viewModelScope.launch { repository.setVerificationBadgeDisplay(show) }
    }

    fun setTtsEnabled(enabled: Boolean) {
        viewModelScope.launch { repository.setTtsEnabled(enabled) }
    }

    fun setTtsSpeed(speed: Float) {
        viewModelScope.launch { repository.setTtsSpeed(speed) }
    }

    fun setVoiceInput(input: String) {
        viewModelScope.launch { repository.setVoiceInput(input) }
    }
    
    fun setNotificationsEnabled(enabled: Boolean) {
        viewModelScope.launch { repository.setNotificationsEnabled(enabled) }
    }

    fun setDailyDharmaReminder(enabled: Boolean) {
        viewModelScope.launch { repository.setDailyDharmaReminder(enabled) }
    }

    fun setFestivalReminder(enabled: Boolean) {
        viewModelScope.launch { repository.setFestivalReminder(enabled) }
    }

    fun setChatHistoryControl(control: String) {
        viewModelScope.launch { repository.setChatHistoryControl(control) }
    }

    fun clearChatHistory() {
        viewModelScope.launch {
            db.chatSessionDao().deleteAllChatSessions()
        }
    }

    fun clearSavedItems() {
        viewModelScope.launch {
            db.savedItemDao().deleteAllSavedItems()
        }
    }
}
