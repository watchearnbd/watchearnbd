package com.example.ui.history

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.ChatSessionEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ChatHistoryViewModel(application: Application) : AndroidViewModel(application) {
    private val db = AppDatabase.getDatabase(application)
    private val chatSessionDao = db.chatSessionDao()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery

    val chatSessions = combine(
        chatSessionDao.getAllChatSessions(),
        _searchQuery
    ) { sessions, query ->
        if (query.isBlank()) {
            sessions
        } else {
            val q = query.lowercase()
            sessions.filter { 
                it.title.lowercase().contains(q) || 
                it.messagesJson.lowercase().contains(q) 
            }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun deleteSession(id: String) {
        viewModelScope.launch {
            chatSessionDao.deleteById(id)
        }
    }
    
    fun togglePin(session: ChatSessionEntity) {
        viewModelScope.launch {
            chatSessionDao.insert(session.copy(isPinned = !session.isPinned, updatedDate = System.currentTimeMillis()))
        }
    }
}
