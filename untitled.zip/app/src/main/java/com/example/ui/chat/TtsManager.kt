package com.example.ui.chat

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import java.util.Locale

class TtsManager(context: Context, private val onInitCompleted: (Boolean) -> Unit) : TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    var isInitialized = false
    private var onCompletionListener: (() -> Unit)? = null
    private var currentText: String? = null

    init {
        tts = TextToSpeech(context, this)
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                onCompletionListener?.invoke()
            }
            override fun onError(utteranceId: String?) {
                onCompletionListener?.invoke()
            }
        })
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isInitialized = true
            onInitCompleted(true)
        } else {
            Log.e("TtsManager", "Initialization Failed!")
            onInitCompleted(false)
        }
    }

    fun speak(text: String, isBengali: Boolean, speed: Float, onCompletion: () -> Unit) {
        if (!isInitialized || tts == null) {
            onCompletion()
            return
        }
        
        stop() // Stop any previous TTS
        
        onCompletionListener = onCompletion
        currentText = text

        val primaryLocale = if (isBengali) Locale.Builder().setLanguage("bn").setRegion("BD").build() else Locale.US
        val secondaryLocale = if (isBengali) Locale.Builder().setLanguage("bn").build() else Locale.UK

        var result = tts?.setLanguage(primaryLocale)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            result = tts?.setLanguage(secondaryLocale)
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                // If Bengali is requested but not supported, fallback to Hindi as a phonetic approximate if possible
                val tertiary = Locale.Builder().setLanguage("hi").build()
                result = tts?.setLanguage(tertiary)
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                     Log.e("TtsManager", "Language not supported")
                     onCompletion() // Cannot speak
                     return
                }
            }
        }

        tts?.setSpeechRate(speed)
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "TTS_ID_${System.currentTimeMillis()}")
    }

    fun stop() {
        tts?.stop()
        onCompletionListener?.invoke()
        onCompletionListener = null
        currentText = null
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
    }
}
