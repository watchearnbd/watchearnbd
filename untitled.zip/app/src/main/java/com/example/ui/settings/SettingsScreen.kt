package com.example.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(viewModel: SettingsViewModel) {
    val themePreference by viewModel.themePreference.collectAsState()
    val textSize by viewModel.textSize.collectAsState()
    val languagePreference by viewModel.languagePreference.collectAsState()
    val defaultChatMode by viewModel.defaultChatMode.collectAsState()
    val researchBehavior by viewModel.researchBehavior.collectAsState()
    val showSources by viewModel.showSources.collectAsState()
    val scriptureSourceDisplay by viewModel.scriptureSourceDisplay.collectAsState()
    val verificationBadgeDisplay by viewModel.verificationBadgeDisplay.collectAsState()
    val ttsEnabled by viewModel.ttsEnabled.collectAsState()
    val ttsSpeed by viewModel.ttsSpeed.collectAsState()
    val voiceInput by viewModel.voiceInput.collectAsState()
    val notificationsEnabled by viewModel.notificationsEnabled.collectAsState()
    val dailyDharmaReminder by viewModel.dailyDharmaReminder.collectAsState()
    val festivalReminder by viewModel.festivalReminder.collectAsState()
    val chatHistoryControl by viewModel.chatHistoryControl.collectAsState()

    var showClearChatDialog by remember { mutableStateOf(false) }
    var showClearSavedDialog by remember { mutableStateOf(false) }
    var showClearSearchDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "Settings",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }

        item {
            SettingsSection(title = "🧠 AI & Research") {
                SettingsDropdown(
                    label = "Default Chat Mode",
                    options = listOf("Normal Chat", "Deep Research"),
                    selected = defaultChatMode,
                    onSelected = { viewModel.setDefaultChatMode(it) }
                )
                SettingsDropdown(
                    label = "Research Behavior",
                    options = listOf("Balanced", "Strict"),
                    selected = researchBehavior,
                    onSelected = { viewModel.setResearchBehavior(it) }
                )
                SettingsSwitch(
                    label = "Show Source Display",
                    description = "Show sources and verification in chat",
                    checked = showSources,
                    onCheckedChange = { viewModel.setShowSources(it) }
                )
            }
        }

        item {
            SettingsSection(title = "🔊 Voice") {
                SettingsSwitch(
                    label = "Text-to-Speech",
                    description = "Enable AI voice response",
                    checked = ttsEnabled,
                    onCheckedChange = { viewModel.setTtsEnabled(it) }
                )
                if (ttsEnabled) {
                    Column(modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
                        Text("Speech Speed: ${"%.1f".format(ttsSpeed)}x", fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
                        Slider(
                            value = ttsSpeed,
                            onValueChange = { viewModel.setTtsSpeed(it) },
                            valueRange = 0.5f..2.0f,
                            steps = 14
                        )
                    }
                }
                SettingsDropdown(
                    label = "Voice Input",
                    options = listOf("Default", "High Quality"),
                    selected = voiceInput,
                    onSelected = { viewModel.setVoiceInput(it) }
                )
            }
        }

        item {
            SettingsSection(title = "🎨 Appearance") {
                SettingsDropdown(
                    label = "Theme",
                    options = listOf("System", "Light", "Dark"),
                    selected = themePreference,
                    onSelected = { viewModel.setThemePreference(it) }
                )
                SettingsDropdown(
                    label = "Text Size",
                    options = listOf("Small", "Medium", "Large"),
                    selected = textSize,
                    onSelected = { viewModel.setTextSize(it) }
                )
            }
        }

        item {
            SettingsSection(title = "📚 Knowledge") {
                SettingsDropdown(
                    label = "Language",
                    options = listOf("বাংলা", "English"),
                    selected = languagePreference,
                    onSelected = { viewModel.setLanguagePreference(it) }
                )
                SettingsSwitch(
                    label = "Scripture Source Display",
                    checked = scriptureSourceDisplay,
                    onCheckedChange = { viewModel.setScriptureSourceDisplay(it) }
                )
                SettingsSwitch(
                    label = "Verification Badge Display",
                    checked = verificationBadgeDisplay,
                    onCheckedChange = { viewModel.setVerificationBadgeDisplay(it) }
                )
            }
        }

        item {
            SettingsSection(title = "🔔 Notifications") {
                SettingsSwitch(
                    label = "Enable Notifications",
                    description = "Daily Dharma & Festival reminders",
                    checked = notificationsEnabled,
                    onCheckedChange = { viewModel.setNotificationsEnabled(it) }
                )
                if (notificationsEnabled) {
                    SettingsSwitch(
                        label = "Daily Dharma Reminder",
                        checked = dailyDharmaReminder,
                        onCheckedChange = { viewModel.setDailyDharmaReminder(it) }
                    )
                    SettingsSwitch(
                        label = "Festival Reminder",
                        checked = festivalReminder,
                        onCheckedChange = { viewModel.setFestivalReminder(it) }
                    )
                }
            }
        }
        
        item {
            SettingsSection(title = "🔐 Data & Privacy") {
                SettingsDropdown(
                    label = "Chat History Control",
                    options = listOf("Keep until I delete", "Clear on exit"),
                    selected = chatHistoryControl,
                    onSelected = { viewModel.setChatHistoryControl(it) }
                )
                SettingsButton(
                    label = "Clear Chat History",
                    icon = Icons.Default.Delete,
                    onClick = { showClearChatDialog = true }
                )
                SettingsButton(
                    label = "Clear Saved Items",
                    icon = Icons.Default.Delete,
                    onClick = { showClearSavedDialog = true }
                )
                SettingsButton(
                    label = "Clear Local Search History",
                    icon = Icons.Default.Delete,
                    onClick = { showClearSearchDialog = true }
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Privacy Information:",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "• Chat history is kept in memory and cleared on restart.\n" +
                           "• Saved knowledge is stored locally on your device.\n" +
                           "• External Research is used only when Deep Research is enabled.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 18.sp,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }
        
        item {
            SettingsSection(title = "ℹ️ About") {
                Text(
                    text = "Dharma AI Version: 1.0\nKnowledge Base: v2\nResearch Engine: Active\nVerification: Active",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 18.sp
                )
            }
        }
    }

    if (showClearChatDialog) {
        AlertDialog(
            onDismissRequest = { showClearChatDialog = false },
            title = { Text("Clear Chat History") },
            text = { Text("আপনি কি সত্যিই সব chat history মুছে ফেলতে চান?") },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.clearChatHistory()
                    showClearChatDialog = false
                }) { Text("Confirm", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { showClearChatDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showClearSavedDialog) {
        AlertDialog(
            onDismissRequest = { showClearSavedDialog = false },
            title = { Text("Clear Saved Items") },
            text = { Text("আপনি কি সত্যিই সব saved items মুছে ফেলতে চান?") },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.clearSavedItems()
                    showClearSavedDialog = false
                }) { Text("Confirm", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { showClearSavedDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showClearSearchDialog) {
        AlertDialog(
            onDismissRequest = { showClearSearchDialog = false },
            title = { Text("Clear Search History") },
            text = { Text("আপনি কি সত্যিই local search history মুছে ফেলতে চান?") },
            confirmButton = {
                TextButton(onClick = {
                    showClearSearchDialog = false
                }) { Text("Confirm", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { showClearSearchDialog = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
fun SettingsSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surface)
            .padding(16.dp)
    ) {
        Text(
            text = title,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(bottom = 12.dp)
        )
        content()
    }
}

@Composable
fun SettingsSwitch(label: String, description: String? = null, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = label, fontSize = 16.sp, color = MaterialTheme.colorScheme.onSurface)
            if (description != null) {
                Text(text = description, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
fun SettingsButton(label: String, icon: ImageVector, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(24.dp))
        Spacer(modifier = Modifier.width(16.dp))
        Text(text = label, fontSize = 16.sp, color = MaterialTheme.colorScheme.error)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsDropdown(label: String, options: List<String>, selected: String, onSelected: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontSize = 16.sp, color = MaterialTheme.colorScheme.onSurface)
        Box {
            OutlinedButton(onClick = { expanded = true }) {
                Text(selected)
                Icon(Icons.Default.ArrowDropDown, contentDescription = null)
            }
            DropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false }
            ) {
                options.forEach { option ->
                    DropdownMenuItem(
                        text = { Text(option) },
                        onClick = {
                            onSelected(option)
                            expanded = false
                        }
                    )
                }
            }
        }
    }
}