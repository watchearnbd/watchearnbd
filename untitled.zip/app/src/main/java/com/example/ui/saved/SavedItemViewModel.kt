package com.example.ui.saved

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.SavedItemEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SavedItemViewModel(application: Application) : AndroidViewModel(application) {
    private val db = AppDatabase.getDatabase(application)
    private val savedItemDao = db.savedItemDao()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery

    private val _selectedFilter = MutableStateFlow("All")
    val selectedFilter: StateFlow<String> = _selectedFilter

    private val _selectedSort = MutableStateFlow("Recently Added")
    val selectedSort: StateFlow<String> = _selectedSort

    val savedItems = combine(
        savedItemDao.getAllSavedItems(),
        _searchQuery,
        _selectedFilter,
        _selectedSort
    ) { items, query, filter, sort ->
        var filtered = items

        // Filter by Query
        if (query.isNotBlank()) {
            val q = query.lowercase()
            filtered = filtered.filter {
                it.title.lowercase().contains(q) || 
                (it.question?.lowercase()?.contains(q) == true) || 
                it.answer.lowercase().contains(q) ||
                it.tags.lowercase().contains(q)
            }
        }

        // Filter by Type/Category
        if (filter != "All") {
            filtered = when (filter) {
                "Favorites" -> filtered.filter { it.type == "FAVORITE" }
                "Saved" -> filtered.filter { it.type == "CHAT" }
                "Bookmarks" -> filtered.filter { it.type == "BOOKMARK" }
                "Gita", "Mantra", "Shloka", "Puja", "Festival", "Scripture" -> filtered.filter { it.category == filter }
                else -> filtered
            }
        }

        // Sort
        when (sort) {
            "Recently Added" -> filtered = filtered.sortedByDescending { it.createdDate }
            "Recently Updated" -> filtered = filtered.sortedByDescending { it.updatedDate }
            "Alphabetical" -> filtered = filtered.sortedBy { it.title }
        }

        filtered
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setFilter(filter: String) {
        _selectedFilter.value = filter
    }

    fun setSort(sort: String) {
        _selectedSort.value = sort
    }

    fun toggleSave(item: SavedItemEntity) {
        viewModelScope.launch {
            val existing = savedItemDao.getSavedItemById(item.id)
            if (existing != null) {
                savedItemDao.deleteById(item.id)
            } else {
                savedItemDao.insert(item.copy(createdDate = System.currentTimeMillis(), updatedDate = System.currentTimeMillis()))
            }
        }
    }

    fun deleteItem(id: String) {
        viewModelScope.launch {
            savedItemDao.deleteById(id)
        }
    }
}
