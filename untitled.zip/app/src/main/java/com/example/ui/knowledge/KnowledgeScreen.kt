package com.example.ui.knowledge

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.AppDatabase
import com.example.data.KnowledgeEntity
import com.example.ui.saved.SavedItemViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KnowledgeScreen(
    savedItemViewModel: SavedItemViewModel,
    initialCategory: String = "All",
    onNavigateToDetail: (Int) -> Unit
) {
    val context = LocalContext.current
    val dao = remember { AppDatabase.getDatabase(context).knowledgeDao() }
    val viewModel: KnowledgeViewModel = viewModel(factory = KnowledgeViewModelFactory(dao))
    
    LaunchedEffect(initialCategory) {
        viewModel.setCategory(initialCategory)
    }

    val query by viewModel.searchQuery.collectAsState()
    val selectedCategory by viewModel.selectedCategory.collectAsState()
    val results by viewModel.knowledgeList.collectAsState()
    
    val savedItems by savedItemViewModel.savedItems.collectAsState()
    val favoriteIds = savedItems.filter { it.type == "FAVORITE" }.map { it.id }.toSet()
    val bookmarkIds = savedItems.filter { it.type == "BOOKMARK" }.map { it.id }.toSet()

    Column(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        TopAppBar(
            title = { Text("Dharma Knowledge Base", fontWeight = FontWeight.Bold) },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = MaterialTheme.colorScheme.surface,
                titleContentColor = MaterialTheme.colorScheme.onSurface
            )
        )
        
        OutlinedTextField(
            value = query,
            onValueChange = { viewModel.updateSearchQuery(it) },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            placeholder = { Text("Search scripture, topics, mantras...") },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = "Search") },
            shape = RoundedCornerShape(12.dp),
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = MaterialTheme.colorScheme.surface,
                unfocusedContainerColor = MaterialTheme.colorScheme.surface
            )
        )

        val categories = listOf("All", "Gita", "Scripture", "Mantra", "Shloka", "Puja", "Festival", "Philosophy", "Yoga")
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(categories) { cat ->
                FilterChip(
                    selected = selectedCategory == cat,
                    onClick = { viewModel.setCategory(cat) },
                    label = { Text(cat) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                        selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                )
            }
        }
        
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(results) { item ->
                KnowledgeCard(
                    entity = item,
                    isFavorite = favoriteIds.contains(item.id.toString()),
                    isBookmarked = bookmarkIds.contains(item.id.toString()),
                    onCardClick = { onNavigateToDetail(item.id) },
                    onFavoriteClick = {
                        val savedItem = com.example.data.SavedItemEntity(
                            id = item.id.toString(),
                            type = "FAVORITE",
                            title = item.title,
                            category = item.category,
                            scripture = item.scripture,
                            reference = item.reference,
                            answer = item.content,
                            tags = item.tags
                        )
                        savedItemViewModel.toggleSave(savedItem)
                    },
                    onBookmarkClick = {
                        val savedItem = com.example.data.SavedItemEntity(
                            id = item.id.toString(),
                            type = "BOOKMARK",
                            title = item.title,
                            category = item.category,
                            scripture = item.scripture,
                            reference = item.reference,
                            answer = item.content,
                            tags = item.tags
                        )
                        savedItemViewModel.toggleSave(savedItem)
                    }
                )
            }
        }
    }
}

@Composable
fun KnowledgeCard(
    entity: KnowledgeEntity,
    isFavorite: Boolean = false,
    isBookmarked: Boolean = false,
    onCardClick: () -> Unit = {},
    onFavoriteClick: () -> Unit = {},
    onBookmarkClick: () -> Unit = {}
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        shape = RoundedCornerShape(12.dp),
        onClick = onCardClick
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = entity.category,
                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .background(MaterialTheme.colorScheme.secondaryContainer, RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                )
                
                val isVerified = entity.verifiedStatus.lowercase() == "verified"
                val isPartial = entity.verifiedStatus.lowercase() == "partially verified"
                
                val statusColor = if (isVerified) MaterialTheme.colorScheme.primary else if (isPartial) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.error
                val statusBg = if (isVerified) MaterialTheme.colorScheme.primaryContainer else if (isPartial) MaterialTheme.colorScheme.tertiaryContainer else MaterialTheme.colorScheme.errorContainer
                val statusIcon = if (isVerified) "✅ " else if (isPartial) "⚠️ " else "❓ "
                
                Text(
                    text = statusIcon + entity.verifiedStatus,
                    color = statusColor,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .background(statusBg, RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 4.dp)
                )
            }
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = entity.title,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            
            Spacer(modifier = Modifier.height(4.dp))
            
            Text(
                text = "${entity.scripture} • ${entity.reference}",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontWeight = FontWeight.Medium
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            if (entity.sanskritText.isNotBlank()) {
                Text(
                    text = entity.sanskritText,
                    fontSize = 15.sp,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
            }
            
            Text(
                text = entity.content.take(150) + if (entity.content.length > 150) "..." else "",
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onSurface,
                lineHeight = 20.sp
            )
            
            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant, thickness = 1.dp)
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(
                    onClick = onFavoriteClick,
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    modifier = Modifier.height(32.dp)
                ) {
                    Text(
                        text = if (isFavorite) "❤️ Favorited" else "🤍 Favorite",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isFavorite) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                TextButton(
                    onClick = onBookmarkClick,
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    modifier = Modifier.height(32.dp)
                ) {
                    Text(
                        text = if (isBookmarked) "📑 Bookmarked" else "🔖 Bookmark",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isBookmarked) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
