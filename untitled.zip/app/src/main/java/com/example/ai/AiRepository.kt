package com.example.ai

import com.example.research.ResearchEngine
import com.example.research.WebResult
import com.example.research.YouTubeResult
import com.example.research.VerificationStatus
import com.example.research.SourceMetadata

import java.util.UUID

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val isUser: Boolean, 
    val text: String, 
    val localSources: List<String> = emptyList(),
    val webSources: List<WebResult> = emptyList(),
    val youtubeSources: List<YouTubeResult> = emptyList(),
    val verificationStatus: VerificationStatus = VerificationStatus.NONE,
    val sourceMetadata: List<SourceMetadata> = emptyList(),
    val suggestedQuestions: List<String> = emptyList(),
    val isLiked: Boolean = false,
    val isDisliked: Boolean = false,
    val isReported: Boolean = false
)

class AiRepository(private val researchEngine: ResearchEngine) {
    suspend fun getAiResponse(
        question: String,
        history: List<ChatMessage>,
        isDeepResearch: Boolean,
        onProgress: (String) -> Unit
    ): ChatMessage {
        val apiHistory = history.map { Content(role = if (it.isUser) "user" else "model", parts = listOf(Part(text = it.text))) }
        val result = researchEngine.conductResearch(question, apiHistory, isDeepResearch, onProgress)
        return ChatMessage(
            isUser = false, 
            text = result.answer, 
            localSources = result.localSources.map { "${it.scripture} (${it.reference})" }.filter { it.isNotBlank() }.distinct(),
            webSources = result.webSources,
            youtubeSources = result.youtubeSources,
            verificationStatus = result.verificationStatus,
            sourceMetadata = result.sourceMetadata,
            suggestedQuestions = result.suggestedQuestions
        )
    }
}
