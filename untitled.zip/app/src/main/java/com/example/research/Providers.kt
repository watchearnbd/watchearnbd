package com.example.research

import com.example.data.KnowledgeDao
import com.example.data.KnowledgeEntity

data class WebResult(val title: String, val link: String, val domain: String, val snippet: String)
data class YouTubeResult(val title: String, val channelTitle: String, val videoId: String, val description: String, val thumbnailUrl: String = "", val publishedAt: String = "")

// 1. Local Knowledge Provider
interface ILocalKnowledgeProvider {
    suspend fun search(query: String): List<KnowledgeEntity>
    suspend fun getAllKnowledge(): List<KnowledgeEntity>
}

class LocalKnowledgeProviderImpl(private val dao: KnowledgeDao) : ILocalKnowledgeProvider {
    override suspend fun search(query: String): List<KnowledgeEntity> {
        return dao.searchKnowledge(query)
    }

    override suspend fun getAllKnowledge(): List<KnowledgeEntity> {
        return dao.getAllKnowledge()
    }
}

// 2. Web Search Provider
interface IWebSearchProvider {
    suspend fun search(query: String): List<WebResult>
}

class WebSearchProviderImpl : IWebSearchProvider {
    override suspend fun search(query: String): List<WebResult> {
        val apiKey = com.example.BuildConfig.GOOGLE_SEARCH_API_KEY
        val cx = com.example.BuildConfig.GOOGLE_SEARCH_CX
        
        if (apiKey.isEmpty() || apiKey == "MY_GOOGLE_SEARCH_API_KEY" || cx.isEmpty() || cx == "MY_GOOGLE_SEARCH_CX") {
            println("Web Research: NOT CONFIGURED")
            return emptyList()
        }
        
        return try {
            // Run a blocking call using our suspend function
            val response = GoogleSearchRetrofit.service.search(query = query, apiKey = apiKey, cx = cx)
            response.items?.map { item ->
                WebResult(
                    title = item.title ?: "",
                    link = item.link ?: "",
                    domain = item.displayLink ?: "",
                    snippet = item.snippet ?: ""
                )
            } ?: emptyList()
        } catch (e: Exception) {
            println("Web Research Error: ${e.message}")
            emptyList()
        }
    }
}

// 3. YouTube Search Provider
interface IYouTubeSearchProvider {
    suspend fun search(query: String): List<YouTubeResult>
}

class YouTubeSearchProviderImpl : IYouTubeSearchProvider {
    override suspend fun search(query: String): List<YouTubeResult> {
        val apiKey = com.example.BuildConfig.YOUTUBE_API_KEY
        
        if (apiKey.isEmpty() || apiKey == "MY_YOUTUBE_API_KEY") {
            println("YouTube Research: NOT CONFIGURED")
            return emptyList()
        }
        
        return try {
            val response = GoogleApiClient.service.searchYouTube(apiKey = apiKey, query = query)
            response.items?.mapNotNull { item ->
                val videoId = item.id?.videoId ?: return@mapNotNull null
                val snippet = item.snippet ?: return@mapNotNull null
                
                YouTubeResult(
                    title = snippet.title ?: "",
                    channelTitle = snippet.channelTitle ?: "",
                    videoId = videoId,
                    description = snippet.description ?: "",
                    thumbnailUrl = snippet.thumbnails?.high?.url ?: "",
                    publishedAt = snippet.publishedAt ?: ""
                )
            } ?: emptyList()
        } catch (e: Exception) {
            println("YouTube Research Error: ${e.message}")
            emptyList()
        }
    }
}
        
// 4. Scripture Verification Provider
interface IScriptureVerificationProvider {
    suspend fun verify(content: String): Boolean
}

class ScriptureVerificationProviderImpl : IScriptureVerificationProvider {
    override suspend fun verify(content: String): Boolean {
        // Basic placeholder for verification logic
        return true
    }
}
