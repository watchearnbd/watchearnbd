package com.example.research

enum class VerificationStatus {
    VERIFIED, PARTIALLY_VERIFIED, NOT_VERIFIED, NONE
}

data class SourceMetadata(
    val title: String,
    val domain: String,
    val sourceType: String,
    val reference: String,
    val summary: String,
    val relevanceScore: Int,
    val verificationStatus: VerificationStatus
)
