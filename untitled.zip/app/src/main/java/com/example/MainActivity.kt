package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ai.AiRepository
import com.example.ai.GeminiAiProvider
import com.example.data.AppDatabase
import com.example.data.KnowledgeSeeder
import com.example.research.ResearchEngine
import com.example.research.LocalKnowledgeProviderImpl
import com.example.research.WebSearchProviderImpl
import com.example.research.YouTubeSearchProviderImpl
import com.example.research.ScriptureVerificationProviderImpl
import com.example.ui.chat.ChatScreen
import com.example.ui.chat.ChatViewModel
import com.example.ui.chat.ChatViewModelFactory
import com.example.ui.knowledge.KnowledgeScreen
import com.example.ui.settings.SettingsScreen
import com.example.ui.settings.SettingsViewModel
import com.example.ui.theme.MyApplicationTheme

import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

import com.example.ui.saved.SavedItemViewModel
import com.example.ui.saved.SavedScreen
import com.example.ui.history.ChatHistoryViewModel
import com.example.ui.history.ChatHistoryScreen
import com.google.gson.Gson

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        
        GlobalScope.launch {
            val db = AppDatabase.getDatabase(applicationContext)
            if(db.knowledgeDao().getKnowledgeCount() == 0) db.knowledgeDao().insertAll(KnowledgeSeeder.initialData)
        }
        
        setContent {
            val settingsViewModel: SettingsViewModel = viewModel()
            val savedItemViewModel: SavedItemViewModel = viewModel()
            val chatHistoryViewModel: ChatHistoryViewModel = viewModel()
            val themePreference by settingsViewModel.themePreference.collectAsState()
            
            val darkTheme = when (themePreference) {
                "Dark" -> true
                "Light" -> false
                else -> androidx.compose.foundation.isSystemInDarkTheme()
            }
            
            MyApplicationTheme(darkTheme = darkTheme) { 
                val navController = rememberNavController()
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentRoute = navBackStackEntry?.destination?.route
                
                // Note: The Navigation route argument handling for restoring session
                // We'll manage session state in the activity or via database observing if needed,
                // but ChatViewModel handles it when called.
                
                Scaffold(
                    bottomBar = {
                        NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                            NavigationBarItem(
                                icon = { Icon(Icons.AutoMirrored.Filled.Chat, contentDescription = "Chat") },
                                label = { Text("Chat") },
                                selected = currentRoute == "chat",
                                onClick = { navController.navigate("chat") { launchSingleTop = true; restoreState = true } }
                            )
                            NavigationBarItem(
                                icon = { Icon(Icons.Filled.History, contentDescription = "History") },
                                label = { Text("History") },
                                selected = currentRoute == "chat_history",
                                onClick = { navController.navigate("chat_history") { launchSingleTop = true; restoreState = true } }
                            )
                            NavigationBarItem(
                                icon = { Icon(Icons.AutoMirrored.Filled.MenuBook, contentDescription = "Knowledge") },
                                label = { Text("Knowledge") },
                                selected = currentRoute == "knowledge",
                                onClick = { navController.navigate("knowledge") { launchSingleTop = true; restoreState = true } }
                            )
                            NavigationBarItem(
                                icon = { Icon(Icons.Filled.Bookmark, contentDescription = "Library") },
                                label = { Text("Library") },
                                selected = currentRoute == "library",
                                onClick = { navController.navigate("library") { launchSingleTop = true; restoreState = true } }
                            )
                            NavigationBarItem(
                                icon = { Icon(Icons.Filled.Settings, contentDescription = "Settings") },
                                label = { Text("Settings") },
                                selected = currentRoute == "settings",
                                onClick = { navController.navigate("settings") { launchSingleTop = true; restoreState = true } }
                            )
                        }
                    }
                ) { paddingValues ->
                    
                    val context = LocalContext.current
                    val db = remember { AppDatabase.getDatabase(context) }
                    val aiProvider = remember { GeminiAiProvider() }
                    
                    val localKnowledgeProvider = remember { LocalKnowledgeProviderImpl(db.knowledgeDao()) }
                    val webSearchProvider = remember { WebSearchProviderImpl() }
                    val youtubeSearchProvider = remember { YouTubeSearchProviderImpl() }
                    val scriptureVerificationProvider = remember { ScriptureVerificationProviderImpl() }
                    
                    val researchEngine = remember { ResearchEngine(
                        localKnowledgeProvider = localKnowledgeProvider,
                        webSearchProvider = webSearchProvider,
                        youtubeSearchProvider = youtubeSearchProvider,
                        scriptureVerificationProvider = scriptureVerificationProvider,
                        aiProvider = aiProvider
                    ) }
                    
                    val repository = remember { AiRepository(researchEngine) }
                    
                    // We define chatViewModel here to share the instance so when we select a session in History, 
                    // we can update it and navigate.
                    val chatViewModel: ChatViewModel = viewModel(
                        factory = ChatViewModelFactory(repository, db.chatSessionDao())
                    )
                    
                    NavHost(
                        navController = navController,
                        startDestination = "chat",
                        modifier = Modifier.padding(paddingValues).fillMaxSize()
                    ) {
                        composable("chat") {
                            val defaultMode by settingsViewModel.defaultChatMode.collectAsState()
                            val showSources by settingsViewModel.showSources.collectAsState()
                            val scriptureSourceDisplay by settingsViewModel.scriptureSourceDisplay.collectAsState()
                            val verificationBadgeDisplay by settingsViewModel.verificationBadgeDisplay.collectAsState()
                            val textSize by settingsViewModel.textSize.collectAsState()
                            
                            val savedItems by savedItemViewModel.savedItems.collectAsState()
                            val savedItemIds = savedItems.map { it.id }.toSet()
                            
                            LaunchedEffect(defaultMode) {
                                if (chatViewModel.messages.value.isEmpty()) {
                                    chatViewModel.toggleDeepResearch(defaultMode == "Deep Research")
                                }
                            }
                            
                            ChatScreen(
                                viewModel = chatViewModel,
                                showSources = showSources,
                                showScriptureSource = scriptureSourceDisplay,
                                showVerificationBadge = verificationBadgeDisplay,
                                textSize = textSize,
                                savedItemIds = savedItemIds,
                                onSaveMessage = { message ->
                                    val gson = Gson()
                                    val previousUserMessage = chatViewModel.messages.value
                                        .takeWhile { it.id != message.id }
                                        .lastOrNull { it.isUser }
                                        
                                    val item = com.example.data.SavedItemEntity(
                                        id = message.id,
                                        type = "CHAT",
                                        title = previousUserMessage?.text?.take(50)?.let { it + "..." } ?: "Saved Chat",
                                        question = previousUserMessage?.text,
                                        answer = message.text,
                                        verificationStatus = message.verificationStatus.name,
                                        sourceMetadataJson = gson.toJson(message.sourceMetadata)
                                    )
                                    savedItemViewModel.toggleSave(item)
                                },
                                onNewChat = { chatViewModel.startNewChat() }
                            )
                        }
                        composable("chat_history") { 
                            ChatHistoryScreen(
                                viewModel = chatHistoryViewModel,
                                onSessionSelected = { session ->
                                    chatViewModel.loadSession(session)
                                    navController.navigate("chat") {
                                        popUpTo("chat") { inclusive = true }
                                        launchSingleTop = true
                                    }
                                }
                            ) 
                        }
                        composable("knowledge") { KnowledgeScreen(savedItemViewModel) }
                        composable("library") { SavedScreen(savedItemViewModel) }
                        composable("settings") { SettingsScreen(viewModel = settingsViewModel) }
                    }
                }
            }
        }
    }
}
