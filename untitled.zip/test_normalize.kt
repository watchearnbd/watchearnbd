fun main() {
    val text = "Bhagavad Gita-এর original name কী?।"
    var norm = text.lowercase()
            .replace(Regex("[\\\\p{Punct}।—-]+"), " ")
            .replace(Regex("[\\\\s]+"), " ")
            .trim()
    println(norm)
}
