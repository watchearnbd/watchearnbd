import os

path = 'app/src/main/java/com/example/data/KnowledgeSeeder.kt'
if os.path.exists(path):
    with open(path, 'r') as f:
        text = f.read()

    new_entity = """
        KnowledgeEntity(
            title = "ভগবদ্গীতার নাম ও পরিচয়",
            category = "General Knowledge",
            subcategory = "Bhagavad Gita",
            scripture = "মহাভারত",
            reference = "ভীষ্মপর্ব",
            sanskritText = "श्रीमद्भगवद्गीता",
            transliteration = "Shrimad Bhagavad Gita",
            banglaMeaning = "শ্রীমদ্ভগবদ্গীতা",
            content = "ভগবদ্গীতার আসল বা সংস্কৃত নাম হলো 'श्रीमद्भगवद्गीता' (শ্রীমদ্ভগবদ্গীতা)। এটি মহাভারতের ভীষ্মপর্বের অন্তর্ভুক্ত।",
            explanation = "ভগবদ্গীতা হিন্দু ধর্মের অন্যতম প্রধান ধর্মগ্রন্থ। এটি কুরুক্ষেত্রের যুদ্ধে ভগবান শ্রীকৃষ্ণ এবং অর্জুনের মধ্যে হওয়া কথোপকথন।",
            source = "Local Dharma Knowledge Base",
            sourceType = "Primary Scripture",
            verifiedStatus = "Verified",
            tags = "গীতার আসল নাম, গীতার মূল নাম, ভগবদ্গীতার সংস্কৃত নাম, Bhagavad Gita original name, Shrimad Bhagavad Gita, শ্রীমদ্ভগবদ্গীতা, gita name",
            deity = "কৃষ্ণ",
            significance = "মহাভারতের ভীষ্মপর্বের অংশ"
        ),
"""
    
    # insert after `val initialData = listOf(`
    if 'val initialData = listOf(' in text:
        text = text.replace('val initialData = listOf(', 'val initialData = listOf(\n' + new_entity)
        with open(path, 'w') as f:
            f.write(text)
        print("Patched KnowledgeSeeder.kt with Gita name info")
    else:
        print("Could not find initialData in KnowledgeSeeder.kt")
else:
    print("File not found")
