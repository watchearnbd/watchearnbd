import os
import re

ade_path = 'app/src/main/java/com/example/ai/AdvancedDecisionEngine.kt'
with open(ade_path, 'w') as f:
    f.write("""package com.example.ai

import com.example.research.ILocalKnowledgeProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class AdvancedDecisionEngine(
    private val localKnowledgeProvider: ILocalKnowledgeProvider
) {
    suspend fun processPipeline(
        userMessage: String,
        history: List<ChatMessage>,
        isDeepResearch: Boolean,
        onProgress: (String) -> Unit
    ): ChatMessage = withContext(Dispatchers.IO) {
        
        onProgress("Local Knowledge Base-এ খুঁজছি...")
        
        // Simple tokenization
        val keywords = userMessage.split(Regex("\\\\s+")).filter { it.length > 2 }
        
        var results = localKnowledgeProvider.search(userMessage)
        if (results.isEmpty() && keywords.isNotEmpty()) {
            val kwResults = mutableListOf<com.example.data.KnowledgeEntity>()
            for (keyword in keywords) {
                kwResults.addAll(localKnowledgeProvider.search(keyword))
            }
            results = kwResults.distinctBy { it.id }
        }
        
        if (results.isEmpty()) {
            return@withContext ChatMessage(
                isUser = false,
                text = "এই তথ্যটি আমার Verified Knowledge Base-এ নেই।"
            )
        }
        
        onProgress("তথ্য একত্রিত করছি...")
        
        val topResult = results.first()
        val textBuilder = StringBuilder()
        
        textBuilder.append(topResult.title).append("\\n\\n")
        
        if (topResult.scripture.isNotBlank() && topResult.reference.isNotBlank()) {
            textBuilder.append("📖 শাস্ত্র: ").append(topResult.scripture).append("\\n")
            textBuilder.append("📍 Reference: ").append(topResult.reference).append("\\n\\n")
        }
        if (topResult.sanskritText.isNotBlank()) {
            textBuilder.append("🕉️ শ্লোক/মন্ত্র:\\n").append(topResult.sanskritText).append("\\n\\n")
        }
        if (topResult.banglaMeaning.isNotBlank()) {
            textBuilder.append("📝 অর্থ:\\n").append(topResult.banglaMeaning).append("\\n\\n")
        }
        if (topResult.content.isNotBlank()) {
            textBuilder.append("💡 বিস্তারিত:\\n").append(topResult.content).append("\\n\\n")
        }
        if (topResult.explanation.isNotBlank()) {
            textBuilder.append("🔎 ব্যাখ্যা:\\n").append(topResult.explanation).append("\\n")
        }
        
        val answer = textBuilder.toString().trim()
        val localSourceStr = "${topResult.scripture} (${topResult.reference})".trim()
        val sourcesList = if (localSourceStr.length > 3) listOf(localSourceStr) else emptyList()
        
        return@withContext ChatMessage(
            isUser = false,
            text = answer,
            localSources = sourcesList,
            verificationStatus = com.example.research.VerificationStatus.VERIFIED
        )
    }
}
""")

main_activity_path = 'app/src/main/java/com/example/MainActivity.kt'
with open(main_activity_path, 'r') as f:
    main_text = f.read()

main_text = re.sub(
    r'val decisionEngine = remember \{ AdvancedDecisionEngine\(conversationBrain, researchEngine, aiProvider\) \}',
    'val decisionEngine = remember { AdvancedDecisionEngine(localKnowledgeProvider) }',
    main_text
)

with open(main_activity_path, 'w') as f:
    f.write(main_text)

print("Patched knowledge engine successfully.")
