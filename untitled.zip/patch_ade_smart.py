import os
import re

path = 'app/src/main/java/com/example/ai/AdvancedDecisionEngine.kt'
with open(path, 'r') as f:
    text = f.read()

# Replace the KNOWLEDGE BASE SEARCH section
search_section_old = """        // --- 7. KNOWLEDGE BASE SEARCH ---
        onProgress("Internal Brain: Searching Local Knowledge Base...")
        var results = localKnowledgeProvider.search(effectiveQuery)
        
        if (results.isEmpty()) {
            val keywords = effectiveQuery.split(Regex("[\\\\s\\\\p{Punct}]+")).filter { it.length > 2 }
            if (keywords.isNotEmpty()) {
                val kwResults = mutableListOf<KnowledgeEntity>()
                for (keyword in keywords) {
                    kwResults.addAll(localKnowledgeProvider.search(keyword))
                }
                // Sort by keyword match frequency to ensure best match
                results = kwResults.groupBy { it.id }
                    .map { it.value.first() }
                    .sortedByDescending { entity -> 
                        keywords.count { kw -> 
                            entity.title.contains(kw, ignoreCase = true) || 
                            entity.content.contains(kw, ignoreCase = true) ||
                            entity.banglaMeaning.contains(kw, ignoreCase = true) ||
                            entity.explanation.contains(kw, ignoreCase = true)
                        }
                    }.take(3)
            }
        }

        // --- 8. UNKNOWN / OUT OF DOMAIN RESPONSE (MANTRA/SCRIPTURE SAFETY) ---
        if (results.isEmpty()) {"""

search_section_new = """        // --- 7. KNOWLEDGE BASE SEARCH ---
        onProgress("Internal Brain: Searching Local Knowledge Base...")
        val allKnowledge = localKnowledgeProvider.getAllKnowledge()
        val matchResult = SmartKnowledgeMatcher.match(effectiveQuery, allKnowledge)
        
        var results: List<KnowledgeEntity> = emptyList()
        if (matchResult.confidence == MatchConfidence.HIGH) {
            results = listOfNotNull(matchResult.entity)
        } else if (matchResult.confidence == MatchConfidence.MEDIUM) {
            // Clarification needed
            return@withContext buildUnverifiedResponse(matchResult.clarificationMessage)
        }

        // --- 8. UNKNOWN / OUT OF DOMAIN RESPONSE (MANTRA/SCRIPTURE SAFETY) ---
        if (results.isEmpty()) {
            if (matchResult.confidence == MatchConfidence.LOW && matchResult.clarificationMessage.isNotBlank()) {
                val isMantraOrSloka = lowerMessage.contains("মন্ত্র") || lowerMessage.contains("শ্লোক")
                if (isMantraOrSloka) {
                    return@withContext buildUnverifiedResponse(matchResult.clarificationMessage)
                }
            }"""

if search_section_old in text:
    text = text.replace(search_section_old, search_section_new)
    with open(path, 'w') as f:
        f.write(text)
    print("Patched AdvancedDecisionEngine.kt")
else:
    print("Could not find KNOWLEDGE BASE SEARCH section.")

