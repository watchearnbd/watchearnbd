import re
with open('app/src/main/java/com/example/research/ResearchEngine.kt', 'r') as f:
    content = f.read()

replacement = """        } catch (e: Exception) {
            if (localResults.isNotEmpty()) {
                finalAnswerText = "⚠️ Network Error / Offline Mode: ইন্টারনেট সংযোগ না থাকায় AI বিশ্লেষণ সম্ভব হচ্ছে না। নিচে Local Knowledge Base থেকে প্রাপ্ত সরাসরি তথ্য দেওয়া হলো:\\n\\n" + localResults.joinToString("\\n\\n") { "📌 " + it.title + "\\n" + it.content }
            } else {
                throw e
            }
        }"""

# Target the corrupted try catch block
content = re.sub(r'\} catch \(e: Exception\) \{\n\s*if \(localResults\.isNotEmpty\(\)\) \{\n\s*finalAnswerText = [^\n]*\n\s*throw e\n\s*\}\n\s*\}', replacement, content)

with open('app/src/main/java/com/example/research/ResearchEngine.kt', 'w') as f:
    f.write(content)
