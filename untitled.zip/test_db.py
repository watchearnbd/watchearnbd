import sqlite3

def check_db():
    print("This would test the db, but the db is in the emulator.")
    
check_db()
