import os

ade_path = 'app/src/main/java/com/example/ai/AdvancedDecisionEngine.kt'
new_code = """package com.example.ai

import com.example.research.ILocalKnowledgeProvider
import com.example.data.KnowledgeEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class AdvancedDecisionEngine(
    private val localKnowledgeProvider: ILocalKnowledgeProvider,
    private val aiProvider: AiProvider // Retained for constructor signature, but NOT USED to enforce API ban.
) {
    suspend fun processPipeline(
        userMessage: String,
        history: List<ChatMessage>,
        isDeepResearch: Boolean,
        onProgress: (String) -> Unit
    ): ChatMessage = withContext(Dispatchers.IO) {
        
        onProgress("Internal Brain: Analyzing Intent & Context...")
        
        val rawMessage = userMessage.trim()
        val lowerMessage = rawMessage.lowercase()
        
        // --- 1. GREETINGS & SMALL TALK ---
        if (isGreeting(lowerMessage)) {
            return@withContext buildUnverifiedResponse("নমস্কার! আমি Dharma AI. আপনাকে কীভাবে সাহায্য করতে পারি?")
        }
        if (isHowAreYou(lowerMessage)) {
            return@withContext buildUnverifiedResponse("আমি ভালো আছি। আপনার আধ্যাত্মিক জিজ্ঞাসা বা শাস্ত্র সম্পর্কে কোনো প্রশ্ন থাকলে করতে পারেন।")
        }

        // --- 2. CONTEXT AWARENESS & COREFERENCE RESOLUTION ---
        var effectiveQuery = rawMessage
        var isFollowUp = false
        
        val followUpKeywords = listOf("এটা", "ওটা", "এর", "কেন", "আরও", "বিস্তারিত", "মানে", "বুঝলাম না", "তার", "সেটার", "উদাহরণ")
        if (followUpKeywords.any { lowerMessage.contains(it) } || rawMessage.length < 15) {
            isFollowUp = true
            val lastUserMsg = history.lastOrNull { it.isUser }?.text ?: ""
            if (lastUserMsg.isNotBlank() && !lastUserMsg.equals(rawMessage, ignoreCase = true)) {
                effectiveQuery = "$lastUserMsg $rawMessage"
            }
        }

        // --- 3. CLARIFICATION RULE ---
        if (effectiveQuery.length < 3 && !isFollowUp) {
            return@withContext buildUnverifiedResponse("আপনার প্রশ্নটি অস্পষ্ট। আপনি কি আরেকটু বিস্তারিতভাবে বলবেন?")
        }

        // --- 4. KNOWLEDGE BASE SEARCH ---
        onProgress("Internal Brain: Searching Local Knowledge Base...")
        var results = localKnowledgeProvider.search(effectiveQuery)
        
        if (results.isEmpty()) {
            val keywords = effectiveQuery.split(Regex("[\\\\s\\\\p{Punct}]+")).filter { it.length > 2 }
            if (keywords.isNotEmpty()) {
                val kwResults = mutableListOf<KnowledgeEntity>()
                for (keyword in keywords) {
                    kwResults.addAll(localKnowledgeProvider.search(keyword))
                }
                // Sort by keyword match frequency to ensure best match
                results = kwResults.groupBy { it.id }
                    .map { it.value.first() }
                    .sortedByDescending { entity -> 
                        keywords.count { kw -> 
                            entity.title.contains(kw, ignoreCase = true) || 
                            entity.content.contains(kw, ignoreCase = true) ||
                            entity.banglaMeaning.contains(kw, ignoreCase = true) ||
                            entity.explanation.contains(kw, ignoreCase = true)
                        }
                    }.take(3)
            }
        }

        // --- 5. UNKNOWN / OUT OF DOMAIN RESPONSE ---
        if (results.isEmpty()) {
            val religiousTerms = listOf("গীতা", "বেদ", "ঈশ্বর", "ধর্ম", "কৃষ্ণ", "রাম", "পূজা", "মন্ত্র", "শ্লোক", "ভগবান", "শিব", "কালী", "হিন্দু")
            val hasReligiousTerm = religiousTerms.any { effectiveQuery.contains(it) }
            
            if (!hasReligiousTerm && !isFollowUp) {
                return@withContext buildUnverifiedResponse("আমি একটি ধর্মীয় ও শাস্ত্রীয় সহায়ক। আপনার প্রশ্নটি আমার বিষয়ের বাইরের বলে মনে হচ্ছে। শাস্ত্র বা ধর্ম সম্পর্কিত কিছু জানতে চাইলে আমাকে জিজ্ঞেস করতে পারেন।")
            }
            // CRITICAL TRUTH RULE implementation
            return@withContext buildUnverifiedResponse("এই বিষয়টি সম্পর্কে আমার Verified Knowledge Base-এ পর্যাপ্ত তথ্য নেই।")
        }

        // --- 6. RESPONSE GENERATION (RULE-BASED NLG) ---
        onProgress("Internal Brain: Formatting Final Answer...")
        val primaryResult = results.first()
        val sb = java.lang.StringBuilder()
        
        val isDetailed = listOf("বিস্তারিত", "আরও", "সব", "ব্যাখ্যা", "বুঝিয়ে").any { lowerMessage.contains(it) }
        val isMeaning = listOf("মানে", "অর্থ", "বলতে কী", "কি বোঝায়").any { lowerMessage.contains(it) }
        val isExample = listOf("উদাহরণ", "যেমন").any { lowerMessage.contains(it) }
        val isReasoning = listOf("কেন", "কারণ").any { lowerMessage.contains(it) }

        if (isDetailed) {
            if (primaryResult.content.isNotBlank()) sb.append(primaryResult.content).append("\\n\\n")
            if (primaryResult.sanskritText.isNotBlank()) sb.append("মূল শ্লোক/মন্ত্র:\\n${primaryResult.sanskritText}\\n\\n")
            if (primaryResult.banglaMeaning.isNotBlank()) sb.append("অর্থ:\\n${primaryResult.banglaMeaning}\\n\\n")
            if (primaryResult.explanation.isNotBlank()) sb.append("ব্যাখ্যা:\\n${primaryResult.explanation}")
        } else if (isMeaning) {
            if (primaryResult.banglaMeaning.isNotBlank()) {
                sb.append(primaryResult.banglaMeaning)
                if (primaryResult.explanation.isNotBlank()) sb.append("\\n\\nব্যাখ্যা: ").append(primaryResult.explanation)
            } else if (primaryResult.explanation.isNotBlank()) {
                sb.append(primaryResult.explanation)
            } else {
                sb.append(primaryResult.content)
            }
        } else if (isExample || isReasoning) {
             if (primaryResult.explanation.isNotBlank()) {
                 sb.append(primaryResult.explanation)
             } else {
                 sb.append(primaryResult.content)
             }
        } else {
            // Concise response
            if (primaryResult.content.isNotBlank()) {
                sb.append(primaryResult.content)
            } else if (primaryResult.banglaMeaning.isNotBlank()) {
                sb.append(primaryResult.banglaMeaning)
            } else if (primaryResult.explanation.isNotBlank()) {
                sb.append(primaryResult.explanation)
            }
            if (primaryResult.sanskritText.isNotBlank()) {
                 sb.append("\\n\\n(শ্লোক: ${primaryResult.sanskritText})")
            }
        }
        
        var finalResponse = sb.toString().trim()
        if (finalResponse.isEmpty()) {
            return@withContext buildUnverifiedResponse("এই বিষয়টি সম্পর্কে আমার Verified Knowledge Base-এ পর্যাপ্ত তথ্য নেই।")
        }

        val sourcesList = results.map { "${it.scripture} (${it.reference})".trim() }.filter { it.length > 3 }.distinct()

        return@withContext ChatMessage(
            isUser = false,
            text = finalResponse,
            localSources = sourcesList,
            verificationStatus = com.example.research.VerificationStatus.VERIFIED
        )
    }

    private fun isGreeting(text: String): Boolean {
        val greetings = listOf("হাই", "হ্যালো", "নমস্কার", "প্রণাম", "hi", "hello", "nomoshkar")
        val cleanText = text.replace(Regex("\\\\p{Punct}"), "")
        return greetings.any { cleanText == it || cleanText.startsWith("$it ") }
    }

    private fun isHowAreYou(text: String): Boolean {
        val patterns = listOf("কেমন আছো", "কেমন আছেন", "how are you", "কেমন আছ", "ক্যামন আছো")
        return patterns.any { text.contains(it) }
    }

    private fun buildUnverifiedResponse(text: String): ChatMessage {
        return ChatMessage(
            isUser = false,
            text = text,
            localSources = emptyList(),
            verificationStatus = com.example.research.VerificationStatus.NONE
        )
    }
}
"""
with open(ade_path, 'w') as f:
    f.write(new_code)

print("Patch applied.")
