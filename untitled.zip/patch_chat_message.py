import os

repo_path = 'app/src/main/java/com/example/ai/AiRepository.kt'
with open(repo_path, 'r') as f:
    text = f.read()

# Replace ChatMessage definition
old_def = """data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val isUser: Boolean, 
    val text: String, 
    val localSources: List<String> = emptyList(),
    val webSources: List<WebResult> = emptyList(),
    val youtubeSources: List<YouTubeResult> = emptyList(),
    val verificationStatus: VerificationStatus = VerificationStatus.NONE,
    val sourceMetadata: List<SourceMetadata> = emptyList(),
    val suggestedQuestions: List<String> = emptyList()
)"""

new_def = """data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val isUser: Boolean, 
    val text: String, 
    val localSources: List<String> = emptyList(),
    val webSources: List<WebResult> = emptyList(),
    val youtubeSources: List<YouTubeResult> = emptyList(),
    val verificationStatus: VerificationStatus = VerificationStatus.NONE,
    val sourceMetadata: List<SourceMetadata> = emptyList(),
    val suggestedQuestions: List<String> = emptyList(),
    val isLiked: Boolean = false,
    val isDisliked: Boolean = false,
    val isReported: Boolean = false
)"""

if old_def in text:
    text = text.replace(old_def, new_def)
    with open(repo_path, 'w') as f:
        f.write(text)
    print("ChatMessage patched in AiRepository.kt.")
else:
    print("Could not find old_def in AiRepository.kt.")
