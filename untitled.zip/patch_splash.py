import os

build_file = 'app/build.gradle.kts'
with open(build_file, 'r') as f:
    build_text = f.read()

if 'androidx.core.splashscreen' not in build_text:
    build_text = build_text.replace(
        'dependencies {',
        'dependencies {\n    implementation("androidx.core:core-splashscreen:1.0.1")'
    )
    with open(build_file, 'w') as f:
        f.write(build_text)

theme_file = 'app/src/main/res/values/themes.xml'
os.makedirs('app/src/main/res/values', exist_ok=True)
with open(theme_file, 'w') as f:
    f.write('''<?xml version="1.0" encoding="utf-8"?>
<resources>
    <!-- Base application theme. -->
    <style name="Theme.MyApplication" parent="android:Theme.Material.Light.NoActionBar" />
    
    <!-- Splash Screen theme. -->
    <style name="Theme.App.Starting" parent="Theme.SplashScreen">
        <item name="windowSplashScreenBackground">#0B0F19</item>
        <item name="windowSplashScreenAnimatedIcon">@drawable/ic_launcher_foreground</item>
        <item name="postSplashScreenTheme">@style/Theme.MyApplication</item>
    </style>
</resources>
''')

manifest_file = 'app/src/main/AndroidManifest.xml'
with open(manifest_file, 'r') as f:
    manifest_text = f.read()

if '@style/Theme.App.Starting' not in manifest_text:
    manifest_text = manifest_text.replace(
        'android:theme="@style/Theme.MyApplication"',
        'android:theme="@style/Theme.App.Starting"'
    )
    with open(manifest_file, 'w') as f:
        f.write(manifest_text)

main_activity = 'app/src/main/java/com/example/MainActivity.kt'
with open(main_activity, 'r') as f:
    main_text = f.read()

if 'installSplashScreen' not in main_text:
    main_text = main_text.replace(
        'import androidx.activity.compose.setContent',
        'import androidx.activity.compose.setContent\nimport androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen'
    )
    main_text = main_text.replace(
        'super.onCreate(savedInstanceState)',
        'installSplashScreen()\n        super.onCreate(savedInstanceState)'
    )
    with open(main_activity, 'w') as f:
        f.write(main_text)

print("Splash screen setup complete.")
