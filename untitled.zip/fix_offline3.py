with open('app/src/main/java/com/example/research/ResearchEngine.kt', 'r') as f:
    lines = f.readlines()

new_lines = []
skip = False
for i, line in enumerate(lines):
    if i == 150:
        new_lines.append('                finalAnswerText = "⚠️ Network Error / Offline Mode: ইন্টারনেট সংযোগ না থাকায় AI বিশ্লেষণ সম্ভব হচ্ছে না। নিচে Local Knowledge Base থেকে প্রাপ্ত সরাসরি তথ্য দেওয়া হলো:\\n\\n" + localResults.joinToString("\\n\\n") { "📌 " + it.title + "\\n" + it.content }\n')
        skip = True
    elif skip and i == 155:
        skip = False
    elif not skip:
        new_lines.append(line)

with open('app/src/main/java/com/example/research/ResearchEngine.kt', 'w') as f:
    f.writelines(new_lines)
