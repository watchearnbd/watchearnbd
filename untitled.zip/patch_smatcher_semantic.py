import os
import re

path = 'app/src/main/java/com/example/ai/SmartKnowledgeMatcher.kt'
if not os.path.exists(path):
    print("File not found")
    exit(1)

with open(path, 'r') as f:
    text = f.read()

# We need to insert a synonym dictionary and a semantic normalizer
semantic_code = """
    private val stopWords = setOf(
        "কী", "কি", "what", "বলতে", "বোঝায়", "সম্পর্কে", "বলো", "tell", "about", 
        "হলো", "হল", "is", "are", "the", "a", "an", "এর", "টা", "টি"
    )

    private val synonyms = mapOf(
        listOf("গীতা", "ভগবদ্গীতা", "gita", "bhagavad gita") to "gita",
        listOf("আসল", "মূল", "প্রকৃত", "original", "real", "সংস্কৃত", "sanskrit") to "original",
        listOf("নাম", "পরিচয়", "name", "identity") to "name",
        listOf("গায়ত্রী", "gayatri") to "gayatri",
        listOf("মন্ত্র", "mantra", "মন্ত্রটা") to "mantra",
        listOf("কর্মযোগ", "karma yoga", "karmayog") to "karmayoga",
        listOf("সহজ ভাষায়", "সহজ করে", "in simple words", "simply") to "simple"
    )

    private fun semanticNormalize(text: String): String {
        var norm = text.lowercase()
            .replace(Regex("[\\\\p{Punct}]+"), " ")
            .replace(Regex("[\\\\s]+"), " ")
            .trim()
            
        val tokens = norm.split(" ").filter { !stopWords.contains(it) }
        val canonicalTokens = tokens.map { token ->
            var canonical = token
            for ((synList, canon) in synonyms) {
                if (synList.any { it == token || token.contains(it) && it.length > 3 }) {
                    canonical = canon
                    break
                }
            }
            canonical
        }
        return canonicalTokens.joinToString(" ")
    }
"""

if "private fun normalize" in text:
    text = text.replace("private fun normalize", semantic_code + "\n    private fun normalize")

# Use semantic normalization for both the query and the target text
# Wait, we should probably keep original normalize for exact matches, and add a semanticScore.
score_logic = """
        val titleNorm = normalize(entity.title)
        val aliases = entity.tags.split(",").map { normalize(it) }
        
        val querySemantic = semanticNormalize(normalizedQuery)
        val titleSemantic = semanticNormalize(entity.title)
        val aliasesSemantic = entity.tags.split(",").map { semanticNormalize(it) }

        // 1. Exact Title Match
        if (normalizedQuery == titleNorm || querySemantic == titleSemantic) return 1.0
        
        // 2. Exact Alias Match
        if (aliases.any { it == normalizedQuery } || aliasesSemantic.any { it == querySemantic }) return 0.95
"""

text = re.sub(r'val titleNorm = normalize\(entity\.title\)\s*val aliases = entity\.tags\.split\("\,"\)\[^\]]*// 1\. Exact Title Match\s*if \(normalizedQuery == titleNorm\) return 1\.0\s*// 2\. Exact Alias Match\s*if \(aliases\.any \{ it == normalizedQuery \}\) return 0\.95', score_logic, text, flags=re.MULTILINE|re.DOTALL)

with open(path, 'w') as f:
    f.write(text)
print("Patched SmartKnowledgeMatcher.kt with semantic logic")
