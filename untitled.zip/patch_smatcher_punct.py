import os

path = 'app/src/main/java/com/example/ai/SmartKnowledgeMatcher.kt'
if not os.path.exists(path):
    print("File not found")
    exit(1)

with open(path, 'r') as f:
    text = f.read()

text = text.replace('Regex("[\\\\p{Punct}]+")', 'Regex("[\\\\p{Punct}।—-]+")')

with open(path, 'w') as f:
    f.write(text)
print("Patched SmartKnowledgeMatcher.kt punct")
