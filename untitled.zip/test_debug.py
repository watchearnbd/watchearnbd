import os

path = 'app/build/reports/tests/testDebugUnitTest/classes/com.example.ai.SmartKnowledgeMatcherTest.html'
if os.path.exists(path):
    with open(path, 'r') as f:
        html = f.read()
    
    import re
    # Extract failure messages
    failures = re.findall(r'<div class="test"><a name=".*?"></a>\s*<h3 class="failures">.*?</h3>\s*<span class="code">\s*<pre>(.*?)</pre>', html, re.DOTALL)
    for fail in failures:
        print(fail.strip())
else:
    print("Test report not found.")
