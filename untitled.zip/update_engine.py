import re

with open('app/src/main/java/com/example/research/ResearchEngine.kt', 'r') as f:
    content = f.read()

replacement = """            append("CRITICAL RULES:\\n")
            append("1. Never invent scripture references, chapter, verse, shlokas, mantras, sanskrit text, or source. If not in DB or external search, explicitly state it.\\n")
            append("2. Maintain tradition awareness (Vaishnava, Shaiva, Shakta, Smarta, Vedanta, Yoga). Do not present one interpretation as the universal Hindu belief. If sources disagree, state: 'এই বিষয়ে বিভিন্ন tradition-এ ভিন্ন ব্যাখ্যা রয়েছে।'\\n")
            append("3. Do NOT claim you searched Google or YouTube if webResults or youtubeResults are empty.\\n")
            append("4. Use ONLY the provided Local Knowledge Database context to answer if no web results are provided.\\n")
            
            append("5. If a Mantra is asked, format exactly as:\\n🕉️ মন্ত্র\\n📖 শাস্ত্রীয় উৎস\\n📍 Reference\\n🔤 উচ্চারণ / Transliteration\\n📝 সহজ বাংলা অর্থ\\n💡 Traditional Context\\n🔎 Verification\\n📚 Source\\nIf unverified, clearly state 'Not Verified'.\\n")
            append("6. If a Shloka is asked, format exactly as:\\n📖 শাস্ত্র\\n📍 Chapter / Verse\\n🕉️ শ্লোক\\n🔤 Transliteration\\n📝 বাংলা অর্থ\\n💡 ব্যাখ্যা\\n🔎 Verification\\n📚 Source\\nIf unverified, DO NOT guess the chapter/verse. State 'এই reference নির্ভরযোগ্যভাবে যাচাই করা যায়নি।'\\n")
            append("6a. For Bhagavad Gita related questions, use this specific format when appropriate:\\n📖 Bhagavad Gita\\n📍 Chapter / Verse\\n🕉️ শ্লোক\\n🔤 Transliteration\\n📝 বাংলা অর্থ\\n💡 সহজ ব্যাখ্যা\\n🔎 Verification\\n📚 Source\\nDo NOT invent unverified fields.\\n")
            append("7. Transliteration এবং pronunciation একই জিনিস ধরে নেবে না। যদি নির্ভরযোগ্য pronunciation data না থাকে: 'উচ্চারণের তথ্য যাচাই করা হয়নি।' দেখাতে পারবে। নিজে থেকে Sanskrit pronunciation তৈরি করবে না।\\n")
            append("8. YouTube videos are educational resources; their scriptural authenticity must be verified separately. If referencing a video, mention: 'এই ভিডিওটি একটি reference resource; এর বক্তব্যের শাস্ত্রীয় সত্যতা আলাদাভাবে যাচাই করা হয়েছে/হয়নি।'\\n")"""

# Find the start of CRITICAL RULES
start_idx = content.find('append("CRITICAL RULES:\\n")')
if start_idx == -1:
    start_idx = content.find('append("CRITICAL RULES:')

# Find the end of the rules (the line before "if (needsExternalResearch")
end_idx = content.find('if (needsExternalResearch', start_idx)

if start_idx != -1 and end_idx != -1:
    new_content = content[:start_idx] + replacement + "\n\n            " + content[end_idx:]
    with open('app/src/main/java/com/example/research/ResearchEngine.kt', 'w') as f:
        f.write(new_content)
    print("Fixed ResearchEngine.kt")
else:
    print("Could not find blocks")
