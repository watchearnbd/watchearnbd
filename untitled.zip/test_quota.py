import urllib.request
import json
import os

api_key = os.environ.get("GEMINI_API_KEY", "MY_GEMINI_API_KEY")
if api_key == "MY_GEMINI_API_KEY":
    # fallback to build config if possible, or skip
    pass

with open('app/build.gradle.kts', 'r') as f:
    text = f.read()
    for line in text.split('\n'):
        if 'GEMINI_API_KEY' in line and 'buildConfigField' in line:
            parts = line.split('"')
            if len(parts) >= 3:
                api_key = parts[3]

if not api_key or api_key == "MY_GEMINI_API_KEY":
    print("No valid API key found.")
    exit(0)

url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key={api_key}"
payload = {
    "contents": [{"role": "user", "parts": [{"text": "Hello"}]}]
}
req = urllib.request.Request(url, data=json.dumps(payload).encode('utf-8'), headers={'Content-Type': 'application/json'})
try:
    with urllib.request.urlopen(req) as response:
        res_data = json.loads(response.read().decode())
        print("API is working.")
except Exception as e:
    print(f"API Error: {e}")
