import os

path = 'app/src/main/java/com/example/ai/SmartKnowledgeMatcher.kt'
if not os.path.exists(path):
    print("File not found")
    exit(1)

with open(path, 'r') as f:
    text = f.read()

target = """    private fun calculateScore(normalizedQuery: String, entity: KnowledgeEntity): Double {
        val titleNorm = normalize(entity.title)
        val aliases = entity.tags.split(",").map { normalize(it) }
        // 1. Exact Title Match
        if (normalizedQuery == titleNorm) return 1.0
        // 2. Exact Alias Match
        if (aliases.any { it == normalizedQuery }) return 0.95"""

replacement = """    private fun calculateScore(normalizedQuery: String, entity: KnowledgeEntity): Double {
        val titleNorm = normalize(entity.title)
        val aliases = entity.tags.split(",").map { normalize(it) }
        
        val querySemantic = semanticNormalize(normalizedQuery)
        val titleSemantic = semanticNormalize(entity.title)
        val aliasesSemantic = entity.tags.split(",").map { semanticNormalize(it) }

        // 1. Exact Title Match
        if (normalizedQuery == titleNorm || querySemantic == titleSemantic) return 1.0
        
        // 2. Exact Alias Match
        if (aliases.any { it == normalizedQuery } || aliasesSemantic.any { it == querySemantic }) return 0.95"""

if target in text:
    text = text.replace(target, replacement)
    with open(path, 'w') as f:
        f.write(text)
    print("Patched calculateScore")
else:
    print("Could not find target in calculateScore")
