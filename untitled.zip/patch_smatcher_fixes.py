import os

path = 'app/src/main/java/com/example/ai/SmartKnowledgeMatcher.kt'
with open(path, 'r') as f:
    text = f.read()

text = text.replace('Regex("[\\p{Punct}]+")', 'Regex("[\\\\p{Punct}]+")')
text = text.replace('Regex("\\s+")', 'Regex("[\\\\s]+")')
text = text.replace('Regex("\\d+")', 'Regex("\\\\d+")')

with open(path, 'w') as f:
    f.write(text)
print("SmartKnowledgeMatcher escapes patched.")
