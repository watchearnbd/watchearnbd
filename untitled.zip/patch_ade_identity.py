import os

path = 'app/src/main/java/com/example/ai/AdvancedDecisionEngine.kt'
if os.path.exists(path):
    with open(path, 'r') as f:
        text = f.read()

    new_code = """
        if (lowerMessage.contains("তোমার নাম কী") || lowerMessage.contains("তোমার নাম কি") || lowerMessage.contains("what is your name")) {
            return@withContext buildUnverifiedResponse("আমার নাম Dharma AI। 🙏")
        }
        
        if (lowerMessage.contains("তুমি কী করতে পারো") || lowerMessage.contains("তুমি কি করতে পারো") || lowerMessage.contains("what can you do")) {
            return@withContext buildUnverifiedResponse("আমি হিন্দু ধর্ম, শাস্ত্র, দর্শন, মন্ত্র, পূজা, উৎসব ও আধ্যাত্মিক জ্ঞান সম্পর্কে সাহায্য করতে পারি।")
        }
"""
    
    # insert before `if (isWhatDoYouDo(lowerMessage)) {`
    if 'if (isWhatDoYouDo(lowerMessage)) {' in text:
        text = text.replace('if (isWhatDoYouDo(lowerMessage)) {', new_code + '\n        if (isWhatDoYouDo(lowerMessage)) {')
        with open(path, 'w') as f:
            f.write(text)
        print("Patched AdvancedDecisionEngine.kt with identity queries")
    else:
        print("Could not find isWhatDoYouDo in AdvancedDecisionEngine.kt")
else:
    print("File not found")
