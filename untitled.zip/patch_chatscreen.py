import os

path = 'app/src/main/java/com/example/ui/chat/ChatScreen.kt'
if not os.path.exists(path):
    print("File not found")
    exit(1)

with open(path, 'r') as f:
    text = f.read()

target = """                ChatMessageItem(
                    message = message, 
                    showSources = showSources,
                    showScriptureSource = showScriptureSource,
                    showVerificationBadge = showVerificationBadge,
                    textSize = textSize,
                    isSaved = savedItemIds.contains(message.id),
                    onSaveClick = { onSaveMessage(message) },
                    onSuggestionClick = { suggestion -> inputText = suggestion }
                )"""

replacement = """                ChatMessageItem(
                    message = message, 
                    showSources = showSources,
                    showScriptureSource = showScriptureSource,
                    showVerificationBadge = showVerificationBadge,
                    textSize = textSize,
                    isSaved = savedItemIds.contains(message.id),
                    onSaveClick = { onSaveMessage(message) },
                    onSuggestionClick = { suggestion -> inputText = suggestion },
                    isPlaying = playingMessageId == message.id,
                    onPlayClick = {
                        if (playingMessageId == message.id) {
                            ttsManager.stop()
                            playingMessageId = null
                        } else {
                            playingMessageId = message.id
                            ttsManager.speak(message.text, true, 1.0f) {
                                playingMessageId = null
                            }
                        }
                    },
                    onActionClick = { action ->
                        when(action) {
                            "like" -> {
                                viewModel.updateMessageState(message.id, !message.isLiked, false, message.isReported)
                            }
                            "dislike" -> {
                                viewModel.updateMessageState(message.id, false, !message.isDisliked, message.isReported)
                            }
                        }
                    }
                )"""

if target in text:
    text = text.replace(target, replacement)
    with open(path, 'w') as f:
        f.write(text)
    print("Patched ChatScreen.kt successfully.")
else:
    print("Target not found in ChatScreen.kt")
