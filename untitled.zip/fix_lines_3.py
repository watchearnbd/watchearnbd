with open('app/src/main/java/com/example/research/ResearchEngine.kt', 'r') as f:
    lines = f.readlines()

new_lines = []
for i, line in enumerate(lines):
    if '""")' in line and "append" not in line:
        continue
    new_lines.append(line)

with open('app/src/main/java/com/example/research/ResearchEngine.kt', 'w') as f:
    f.writelines(new_lines)
