import os

def write_file(path, content):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w') as f:
        f.write(content.strip() + '\n')

write_file('app/src/main/java/com/example/ai/GeminiRetrofitClient.kt', """
package com.example.ai

import com.squareup.moshi.JsonClass
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

@JsonClass(generateAdapter = true)
data class GenerationConfig(
    val responseMimeType: String? = null
)

@JsonClass(generateAdapter = true)
data class GenerateContentRequest(
    val contents: List<Content>,
    val systemInstruction: Content? = null,
    val generationConfig: GenerationConfig? = null
)

@JsonClass(generateAdapter = true)
data class Content(
    val role: String? = null,
    val parts: List<Part>
)

@JsonClass(generateAdapter = true)
data class Part(
    val text: String? = null
)

@JsonClass(generateAdapter = true)
data class GenerateContentResponse(
    val candidates: List<Candidate>? = null,
    val error: Map<String, Any>? = null
)

@JsonClass(generateAdapter = true)
data class Candidate(
    val content: Content? = null
)

interface GeminiApiService {
    @POST("v1beta/models/gemini-1.5-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GenerateContentRequest
    ): GenerateContentResponse
}

object RetrofitClient {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    val service: GeminiApiService by lazy {
        val retrofit = Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create())
            .build()
        retrofit.create(GeminiApiService::class.java)
    }
}
""")

write_file('app/src/main/java/com/example/research/GoogleApiRetrofitClient.kt', """
package com.example.research

import com.squareup.moshi.JsonClass
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

@JsonClass(generateAdapter = true)
data class GoogleSearchResponse(val items: List<SearchItem>? = null)

@JsonClass(generateAdapter = true)
data class SearchItem(val title: String? = null, val link: String? = null, val displayLink: String? = null, val snippet: String? = null)

@JsonClass(generateAdapter = true)
data class YouTubeSearchResponse(val items: List<YouTubeItem>? = null)

@JsonClass(generateAdapter = true)
data class YouTubeItem(val id: YouTubeId? = null, val snippet: YouTubeSnippet? = null)

@JsonClass(generateAdapter = true)
data class YouTubeId(val videoId: String? = null)

@JsonClass(generateAdapter = true)
data class YouTubeSnippet(
    val title: String? = null,
    val description: String? = null,
    val channelTitle: String? = null,
    val publishedAt: String? = null,
    val thumbnails: YouTubeThumbnails? = null
)

@JsonClass(generateAdapter = true)
data class YouTubeThumbnails(val default: YouTubeThumbnail? = null, val high: YouTubeThumbnail? = null)

@JsonClass(generateAdapter = true)
data class YouTubeThumbnail(val url: String? = null)

interface GoogleApiService {
    @GET("customsearch/v1")
    suspend fun searchWeb(
        @Query("key") apiKey: String,
        @Query("cx") cx: String,
        @Query("q") query: String
    ): GoogleSearchResponse

    @GET("youtube/v3/search")
    suspend fun searchYouTube(
        @Query("key") apiKey: String,
        @Query("q") query: String,
        @Query("part") part: String = "snippet",
        @Query("type") type: String = "video",
        @Query("maxResults") maxResults: Int = 2
    ): YouTubeSearchResponse
}

object GoogleApiClient {
    private const val BASE_URL = "https://www.googleapis.com/"
    val service: GoogleApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(OkHttpClient.Builder().connectTimeout(30, TimeUnit.SECONDS).build())
            .addConverterFactory(MoshiConverterFactory.create())
            .build()
            .create(GoogleApiService::class.java)
    }
}
""")
