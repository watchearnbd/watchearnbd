import os
import re

path = 'app/src/main/java/com/example/data/KnowledgeDao.kt'
with open(path, 'r') as f:
    text = f.read()

if "getAllKnowledge" not in text:
    text = text.replace("suspend fun searchKnowledge(query: String): List<KnowledgeEntity>", 
                        "suspend fun searchKnowledge(query: String): List<KnowledgeEntity>\n\n    @Query(\"SELECT * FROM knowledge\")\n    suspend fun getAllKnowledge(): List<KnowledgeEntity>")
    with open(path, 'w') as f:
        f.write(text)
    print("Patched KnowledgeDao.kt")
