import re

with open('app/src/main/java/com/example/data/KnowledgeEntity.kt', 'r') as f:
    content = f.read()

new_entity = """package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "knowledge")
data class KnowledgeEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val category: String,
    val subcategory: String = "",
    val scripture: String,
    val chapter: String = "",
    val verse: String = "",
    val reference: String,
    val sanskritText: String = "",
    val transliteration: String = "",
    val banglaMeaning: String = "",
    val content: String,
    val explanation: String,
    val source: String,
    val sourceType: String = "",
    val verifiedStatus: String,
    val tags: String,
    val language: String = "Bengali"
)
"""

with open('app/src/main/java/com/example/data/KnowledgeEntity.kt', 'w') as f:
    f.write(new_entity)

print("Updated KnowledgeEntity.kt")
