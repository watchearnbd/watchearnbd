import re
with open('app/src/main/java/com/example/research/ResearchEngine.kt', 'r') as f:
    content = f.read()

# Fix the condition to NOT always search YouTube on Deep Research
content = content.replace(
    "if (analysis.needsYouTube || isDeepResearch) {",
    "if (analysis.needsYouTube) {"
)

with open('app/src/main/java/com/example/research/ResearchEngine.kt', 'w') as f:
    f.write(content)
