import os

path = 'app/src/main/java/com/example/ai/AdvancedDecisionEngine.kt'
with open(path, 'r') as f:
    text = f.read()

target = """    private fun isAgreement(text: String): Boolean {
        val cleanText = text.replace(Regex("\\p{Punct}"), "").trim()
        val patterns = listOf("হ্যাঁ", "হ্যা", "yes", "না", "no", "জি", "জী")
        return patterns.any { cleanText == it }
    }"""

replacement = """    private fun isAgreement(text: String): Boolean {
        val cleanText = text.replace(Regex("\\p{Punct}"), "").trim()
        val patterns = listOf("হ্যাঁ", "হ্যা", "yes", "না", "no", "জি", "জী")
        if (patterns.any { cleanText == it }) return true
        if (cleanText.startsWith("হ্যাঁ ") || cleanText.startsWith("হ্যা ") || cleanText.startsWith("জি ")) return true
        if (cleanText.contains("বলতেছি") && (cleanText.contains("হ্যাঁ") || cleanText.contains("হ্যা") || cleanText.contains("জি"))) return true
        return false
    }"""

text = text.replace(target, replacement)

target2 = """        if (contextState.pendingClarification && contextState.clarificationOptions.size > 1) {
            if (isFirst) {
                val resolvedQuery = contextState.clarificationOptions[0]
                contextState.resetClarification()
                return@withContext processPipeline(resolvedQuery, history, isDeepResearch, contextState, onProgress)
            } else if (isSecond) {
                val resolvedQuery = contextState.clarificationOptions[1]
                contextState.resetClarification()
                return@withContext processPipeline(resolvedQuery, history, isDeepResearch, contextState, onProgress)
            }
        }"""

replacement2 = """        if (contextState.pendingClarification && contextState.clarificationOptions.size > 1) {
            if (isFirst) {
                val resolvedQuery = contextState.clarificationOptions[0]
                contextState.resetClarification()
                return@withContext processPipeline(resolvedQuery, history, isDeepResearch, contextState, onProgress)
            } else if (isSecond) {
                val resolvedQuery = contextState.clarificationOptions[1]
                contextState.resetClarification()
                return@withContext processPipeline(resolvedQuery, history, isDeepResearch, contextState, onProgress)
            }
            
            // Check if they typed part of the option name (e.g. "দুর্গাপূজা" from "'যা দেবী সর্বভূতেষু' না দুর্গাপূজা")
            val matchedOption = contextState.clarificationOptions.find { opt -> 
                val cleanOpt = opt.lowercase().replace("'", "").replace("\"", "")
                lowerMessage.contains(cleanOpt) || cleanOpt.contains(lowerMessage.replace(" বলতেছি", "").replace(" বলছি", "").trim())
            }
            if (matchedOption != null) {
                contextState.resetClarification()
                return@withContext processPipeline(matchedOption, history, isDeepResearch, contextState, onProgress)
            }
        }"""

text = text.replace(target2, replacement2)

with open(path, 'w') as f:
    f.write(text)
print("Updated agreement and option matching")
