import os

path = 'app/src/main/java/com/example/ai/SmartKnowledgeMatcher.kt'
with open(path, 'r') as f:
    text = f.read()

target = """        val aliases = entity.tags.split(",").map { normalize(it) }"""
replacement = """        val aliasesList = entity.tags + "," + entity.aliases + "," + entity.semanticKeywords + "," + entity.phoneticKeywords
        val aliases = aliasesList.split(",").map { normalize(it) }.filter { it.isNotBlank() }"""

text = text.replace(target, replacement)

target2 = """        val aliasesSemantic = entity.tags.split(",").map { semanticNormalize(it) }"""
replacement2 = """        val aliasesSemantic = aliasesList.split(",").map { semanticNormalize(it) }.filter { it.isNotBlank() }"""

text = text.replace(target2, replacement2)

# Update match function for multiple options handling
match_target = """        if (highMatches.size > 1 && bestScore < 1.0) {
            val options = highMatches.keys.take(2).joinToString(" না ")
            return MatchResult(bestMatch, MatchConfidence.MEDIUM, true, "আপনি কি '$options' এর কথা বলছেন?")
        }"""
match_replacement = """        if (highMatches.size > 1 && bestScore < 1.0) {
            val options = highMatches.values.take(5).toList()
            val clarificationMsg = "আপনি ${query} সম্পর্কে কোনটি জানতে চান?\n" + options.mapIndexed { i, opt -> "${i+1}. ${opt.title}" }.joinToString("\n")
            return MatchResult(bestMatch, MatchConfidence.MEDIUM, true, clarificationMsg, options)
        }"""
text = text.replace(match_target, match_replacement)

with open(path, 'w') as f:
    f.write(text)
print("Matcher patched")
