import os

path = 'app/src/main/java/com/example/ai/SmartKnowledgeMatcher.kt'
with open(path, 'r') as f:
    text = f.read()

target = """        if (highMatches.size > 1 && bestScore < 1.0) {
            val options = highMatches.values.take(5).toList()
            val clarificationMsg = "আপনি ${query} সম্পর্কে কোনটি জানতে চান?
" + options.mapIndexed { i, opt -> "${i+1}. ${opt.title}" }.joinToString("
")
            return MatchResult(bestMatch, MatchConfidence.MEDIUM, true, clarificationMsg, options)
        }"""

replacement = '        if (highMatches.size > 1 && bestScore < 1.0) {\n            val options = highMatches.values.take(5).toList()\n            val clarificationMsg = "আপনি ${query} সম্পর্কে কোনটি জানতে চান?\\n" + options.mapIndexed { i, opt -> "${i+1}. ${opt.title}" }.joinToString("\\n")\n            return MatchResult(bestMatch, MatchConfidence.MEDIUM, true, clarificationMsg, options)\n        }'

text = text.replace(target, replacement)
with open(path, 'w') as f:
    f.write(text)
print("Matcher fixed")
