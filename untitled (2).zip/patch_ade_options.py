import os

path = 'app/src/main/java/com/example/ai/AdvancedDecisionEngine.kt'
with open(path, 'r') as f:
    text = f.read()

target = """        contextState.lastUserMessage = rawMessage"""

replacement = """        val isFirst = listOf("প্রথমটা", "1", "১", "প্রথম").any { lowerMessage == it || lowerMessage.contains(it) }
        val isSecond = listOf("দ্বিতীয়টা", "2", "২", "দ্বিতীয়", "শেষেরটা").any { lowerMessage == it || lowerMessage.contains(it) }
        
        if (contextState.pendingClarification && contextState.clarificationOptions.size > 1) {
            if (isFirst) {
                val resolvedQuery = contextState.clarificationOptions[0]
                contextState.resetClarification()
                return@withContext processPipeline(resolvedQuery, history, isDeepResearch, contextState, onProgress)
            } else if (isSecond) {
                val resolvedQuery = contextState.clarificationOptions[1]
                contextState.resetClarification()
                return@withContext processPipeline(resolvedQuery, history, isDeepResearch, contextState, onProgress)
            }
        }
        
        // Handle pronoun resolution like "ওইটার মানে", "তার অর্থ", "নামগুলো"
        var effectiveQuery = lowerMessage
        val hasPronoun = listOf("ওইটার", "এটার", "তার", "এর", "সেটার", "আগেরটা", "আগের", "ওই").any { lowerMessage.contains(it) }
        if (hasPronoun && contextState.conversationTopic.isNotBlank()) {
            effectiveQuery = effectiveQuery.replace(Regex("(ওইটার|এটার|তার|এর|সেটার|আগেরটা|আগের|ওই)"), contextState.conversationTopic)
        }
        val isAskingForNames = listOf("নামগুলো", "নামগুলি").any { lowerMessage.contains(it) }
        if (isAskingForNames && contextState.conversationTopic.isNotBlank()) {
             effectiveQuery = contextState.conversationTopic + " নাম"
        }

        contextState.lastUserMessage = rawMessage"""

text = text.replace(target, replacement)

target_topic = """            contextState.resetClarification()
        }
        
        onProgress("Internal Brain: Knowledge Matching & Verification...")"""

replacement_topic = """            contextState.resetClarification()
            contextState.conversationTopic = matchResult.entity?.title ?: contextState.conversationTopic
        }
        
        onProgress("Internal Brain: Knowledge Matching & Verification...")"""

text = text.replace(target_topic, replacement_topic)

with open(path, 'w') as f:
    f.write(text)
print("ADE options and pronouns updated")
