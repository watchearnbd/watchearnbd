import os

path = 'app/src/main/java/com/example/ai/AdvancedDecisionEngine.kt'
with open(path, 'r') as f:
    text = f.read()

target1 = """    suspend fun processPipeline(
        userMessage: String,
        history: List<ChatMessage>,
        isDeepResearch: Boolean,
        onProgress: (String) -> Unit
    ): ChatMessage = withContext(Dispatchers.IO) {"""

replacement1 = """    suspend fun processPipeline(
        userMessage: String,
        history: List<ChatMessage>,
        isDeepResearch: Boolean,
        contextState: ConversationContext,
        onProgress: (String) -> Unit
    ): ChatMessage = withContext(Dispatchers.IO) {"""

text = text.replace(target1, replacement1)

target2 = """        if (isAgreement(lowerMessage)) {
            val responses = listOf(
                "জি, আপনার আর কোনো প্রশ্ন থাকলে করতে পারেন।",
                "হ্যাঁ, আর কোনো বিষয় জানার থাকলে বলুন।"
            )
            val validResponses = responses.filter { it != lastAiMsg }
            return@withContext buildUnverifiedResponse(validResponses.randomOrNull() ?: responses.first())
        }"""

replacement2 = """        if (isAgreement(lowerMessage)) {
            if (contextState.pendingClarification) {
                if (contextState.clarificationOptions.size == 1 && contextState.pendingTargetId != null) {
                    val resolvedQuery = contextState.pendingTargetId!!
                    contextState.resetClarification()
                    return@withContext processPipeline(resolvedQuery, history, isDeepResearch, contextState, onProgress)
                } else if (contextState.clarificationOptions.size > 1) {
                    val msg = "অবশ্যই। আপনি কোনটি চান—\\n" + contextState.clarificationOptions.mapIndexed { i, opt -> "${i+1}. $opt" }.joinToString("\\n")
                    return@withContext buildUnverifiedResponse(msg)
                }
            } else {
                val responses = listOf(
                    "জি, আপনার আর কোনো প্রশ্ন থাকলে করতে পারেন।",
                    "হ্যাঁ, আর কোনো বিষয় জানার থাকলে বলুন।"
                )
                val validResponses = responses.filter { it != lastAiMsg }
                return@withContext buildUnverifiedResponse(validResponses.randomOrNull() ?: responses.first())
            }
        }
        
        contextState.lastUserMessage = rawMessage
        """

text = text.replace(target2, replacement2)

target3 = """        val matchResult = SmartKnowledgeMatcher.match(effectiveQuery, allKnowledge)
        
        if (matchResult.requiresClarification) {
            return@withContext buildUnverifiedResponse(matchResult.clarificationMessage ?: "আপনি কি আপনার প্রশ্নটি আরেকটু পরিষ্কার করে বলতে পারবেন?")
        }"""

replacement3 = """        val matchResult = SmartKnowledgeMatcher.match(effectiveQuery, allKnowledge)
        
        if (matchResult.requiresClarification) {
            if (matchResult.options.isNotEmpty()) {
                val q = matchResult.clarificationMessage ?: "আপনি কি আপনার প্রশ্নটি আরেকটু পরিষ্কার করে বলতে পারবেন?"
                if (contextState.lastClarificationQuestion == q && contextState.clarificationAttempts > 0) {
                    contextState.clarificationAttempts++
                    return@withContext buildUnverifiedResponse("আমি আগের প্রশ্নটির উত্তর পাওয়ার অপেক্ষায় আছি। আপনি চাইলে নির্দিষ্ট করে বলতে পারেন।")
                }
                contextState.pendingClarification = true
                contextState.lastClarificationQuestion = q
                contextState.clarificationAttempts++
                contextState.clarificationOptions = matchResult.options.map { it.title.split("(").first().trim() }
                if (matchResult.options.size == 1) {
                    contextState.pendingTargetId = matchResult.options.first().title
                }
            }
            return@withContext buildUnverifiedResponse(matchResult.clarificationMessage ?: "আপনি কি আপনার প্রশ্নটি আরেকটু পরিষ্কার করে বলতে পারবেন?")
        } else {
            contextState.resetClarification()
        }"""

text = text.replace(target3, replacement3)

with open(path, 'w') as f:
    f.write(text)
print("ADE updated")
