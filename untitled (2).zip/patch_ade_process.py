import os
path = 'app/src/main/java/com/example/ai/AdvancedDecisionEngine.kt'

with open(path, 'r') as f:
    text = f.read()

# Add conversationContext parameter to processPipeline
target_sig = """    suspend fun processPipeline(
        userMessage: String,
        history: List<ChatMessage>,
        isDeepResearch: Boolean,
        onProgress: (String) -> Unit
    ): ChatMessage = withContext(Dispatchers.IO) {"""

replacement_sig = """    suspend fun processPipeline(
        userMessage: String,
        history: List<ChatMessage>,
        isDeepResearch: Boolean,
        contextState: ConversationContext,
        onProgress: (String) -> Unit
    ): ChatMessage = withContext(Dispatchers.IO) {"""

# Agreement check update
target_agreement = """        if (isAgreement(lowerMessage)) {
            val responses = listOf(
                "জি, আপনার আর কোনো প্রশ্ন থাকলে করতে পারেন।",
                "হ্যাঁ, আর কোনো বিষয় জানার থাকলে বলুন।"
            )
            val validResponses = responses.filter { it != lastAiMsg }
            return@withContext buildUnverifiedResponse(validResponses.randomOrNull() ?: responses.first())
        }"""

replacement_agreement = """        if (isAgreement(lowerMessage)) {
            if (contextState.pendingClarification) {
                // If the user said "yes" and we have exactly 1 option pending
                if (contextState.clarificationOptions.size == 1 && contextState.pendingTargetId != null) {
                    val resolvedQuery = contextState.pendingTargetId!!
                    contextState.resetClarification()
                    return@withContext processPipeline(resolvedQuery, history, isDeepResearch, contextState, onProgress)
                } else if (contextState.clarificationOptions.size > 1) {
                    // Multiple options, cannot just say "yes"
                    val msg = "অবশ্যই। আপনি কোনটি চান—\n" + contextState.clarificationOptions.mapIndexed { i, opt -> "${i+1}. $opt" }.joinToString("\n")
                    return@withContext buildUnverifiedResponse(msg)
                }
            } else {
                val responses = listOf(
                    "জি, আপনার আর কোনো প্রশ্ন থাকলে করতে পারেন।",
                    "হ্যাঁ, আর কোনো বিষয় জানার থাকলে বলুন।"
                )
                val validResponses = responses.filter { it != lastAiMsg }
                return@withContext buildUnverifiedResponse(validResponses.randomOrNull() ?: responses.first())
            }
        }
        
        // Context persistence: update last user message
        contextState.lastUserMessage = rawMessage
        """

target_match = """        val matchResult = SmartKnowledgeMatcher.match(effectiveQuery, allKnowledge)
        
        if (matchResult.requiresClarification) {
            return@withContext buildUnverifiedResponse(matchResult.clarificationMessage ?: "আপনি কি আপনার প্রশ্নটি আরেকটু পরিষ্কার করে বলতে পারবেন?")
        }"""

replacement_match = """        val matchResult = SmartKnowledgeMatcher.match(effectiveQuery, allKnowledge)
        
        if (matchResult.requiresClarification) {
            if (matchResult.options.isNotEmpty()) {
                val q = matchResult.clarificationMessage ?: "আপনি কি আপনার প্রশ্নটি আরেকটু পরিষ্কার করে বলতে পারবেন?"
                if (contextState.lastClarificationQuestion == q && contextState.clarificationAttempts > 0) {
                    // Do not repeat the same clarification question endlessly
                    contextState.clarificationAttempts++
                    return@withContext buildUnverifiedResponse("আমি আগের প্রশ্নটির উত্তর পাওয়ার অপেক্ষায় আছি। আপনি চাইলে নির্দিষ্ট করে বলতে পারেন।")
                }
                contextState.pendingClarification = true
                contextState.lastClarificationQuestion = q
                contextState.clarificationAttempts++
                contextState.clarificationOptions = matchResult.options.map { it.title }
                if (matchResult.options.size == 1) {
                    contextState.pendingTargetId = matchResult.options.first().title // Or some reliable ID
                }
            }
            return@withContext buildUnverifiedResponse(matchResult.clarificationMessage ?: "আপনি কি আপনার প্রশ্নটি আরেকটু পরিষ্কার করে বলতে পারবেন?")
        } else {
            contextState.resetClarification()
        }"""

if target_sig in text and target_agreement in text and target_match in text:
    text = text.replace(target_sig, replacement_sig)
    text = text.replace(target_agreement, replacement_agreement)
    text = text.replace(target_match, replacement_match)
    with open(path, 'w') as f:
        f.write(text)
    print("ADE updated successfully")
else:
    print("Failed to find targets in ADE")
