package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.ai.AiRepository
import com.example.ai.GeminiAiProvider
import com.example.data.AppDatabase
import com.example.data.KnowledgeSeeder
import com.example.research.ResearchEngine
import com.example.research.LocalKnowledgeProviderImpl
import com.example.research.WebSearchProviderImpl
import com.example.research.YouTubeSearchProviderImpl
import com.example.research.ScriptureVerificationProviderImpl
import com.example.ui.chat.ChatScreen
import com.example.ui.chat.ChatViewModel
import com.example.ui.chat.ChatViewModelFactory

import androidx.compose.material.icons.filled.MenuBook
import com.example.ui.knowledge.KnowledgeScreen

import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        
        GlobalScope.launch(Dispatchers.IO) {
            val db = AppDatabase.getDatabase(applicationContext)
            // Force reload for this test phase
            db.knowledgeDao().clearAll()
            db.knowledgeDao().insertAll(KnowledgeSeeder.initialData)
        }
        
        setContent {
            MyApplicationTheme(darkTheme = false) { 
                val navController = rememberNavController()
                
                Scaffold(
                    bottomBar = {
                        NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                            NavigationBarItem(
                                icon = { Icon(Icons.Filled.Chat, contentDescription = "Chat") },
                                label = { Text("Chat") },
                                selected = true,
                                onClick = { navController.navigate("chat") { launchSingleTop = true } }
                            )
                            NavigationBarItem(
                                icon = { Icon(Icons.Filled.MenuBook, contentDescription = "Knowledge") },
                                label = { Text("Knowledge") },
                                selected = false,
                                onClick = { navController.navigate("knowledge") { launchSingleTop = true } }
                            )
                            NavigationBarItem(
                                icon = { Icon(Icons.Filled.History, contentDescription = "History") },
                                label = { Text("History") },
                                selected = false,
                                onClick = { navController.navigate("history") { launchSingleTop = true } }
                            )
                        }
                    }
                ) { paddingValues ->
                    NavHost(
                        navController = navController,
                        startDestination = "chat",
                        modifier = Modifier.padding(paddingValues).fillMaxSize()
                    ) {
                        composable("chat") {
                            val context = LocalContext.current
                            val db = AppDatabase.getDatabase(context)
                            val aiProvider = GeminiAiProvider()
                            
                            val localKnowledgeProvider = LocalKnowledgeProviderImpl(db.knowledgeDao())
                            val webSearchProvider = WebSearchProviderImpl()
                            val youtubeSearchProvider = YouTubeSearchProviderImpl()
                            val scriptureVerificationProvider = ScriptureVerificationProviderImpl()
                            
                            val researchEngine = ResearchEngine(
                                localKnowledgeProvider = localKnowledgeProvider,
                                webSearchProvider = webSearchProvider,
                                youtubeSearchProvider = youtubeSearchProvider,
                                scriptureVerificationProvider = scriptureVerificationProvider,
                                aiProvider = aiProvider
                            )
                            
                            val repository = AiRepository(researchEngine)
                            
                            val viewModel: ChatViewModel = viewModel(
                                factory = ChatViewModelFactory(repository)
                            )
                            
                            ChatScreen(viewModel = viewModel)
                        }
                        composable("knowledge") { com.example.ui.knowledge.KnowledgeScreen() }
                        composable("history") { DummyScreen("History & Saved") }
                    }
                }
            }
        }
    }
}

@Composable
fun DummyScreen(title: String) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(text = title, style = MaterialTheme.typography.headlineMedium)
    }
}
