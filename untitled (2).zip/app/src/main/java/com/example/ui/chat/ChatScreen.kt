package com.example.ui.chat

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ai.ChatMessage
import com.example.research.VerificationStatus
import com.example.research.SourceMetadata
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(viewModel: ChatViewModel) {
    val messages by viewModel.messages.collectAsState()
    val uiState by viewModel.uiState.collectAsState()
    val isDeepResearch by viewModel.isDeepResearch.collectAsState()

    var inputText by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(EditorialBackground)
    ) {
        // Top Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.White)
                .padding(horizontal = 16.dp, vertical = 12.dp)
                .border(1.dp, EditorialOrange50, RoundedCornerShape(12.dp)),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = "DHARMA AI",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = EditorialOrange600,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Hindu Scripture & Knowledge Base",
                    fontSize = 11.sp,
                    color = EditorialSlate500,
                    letterSpacing = 0.5.sp
                )
            }
            
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = if (isDeepResearch) "🔎 Deep Research" else "⚡ Normal Chat", 
                    fontSize = 11.sp, 
                    fontWeight = FontWeight.Bold,
                    color = if (isDeepResearch) EditorialOrange600 else EditorialSlate400,
                    modifier = Modifier.padding(end = 8.dp)
                )
                Switch(
                    checked = isDeepResearch,
                    onCheckedChange = { viewModel.toggleDeepResearch(it) },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = EditorialOrange600
                    ),
                    modifier = Modifier.scale(0.8f)
                )
            }
        }

        // Chat Area
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(messages) { message ->
                ChatMessageItem(message)
            }

            if (uiState is ChatUiState.Loading) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Start
                    ) {
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(topStart = 0.dp, topEnd = 16.dp, bottomEnd = 16.dp, bottomStart = 16.dp))
                                .background(Color.White)
                                .border(1.dp, EditorialOrange100, RoundedCornerShape(topStart = 0.dp, topEnd = 16.dp, bottomEnd = 16.dp, bottomStart = 16.dp))
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                color = EditorialOrange600,
                                strokeWidth = 2.dp
                            )
                            Text(
                                text = (uiState as ChatUiState.Loading).progressMessage, 
                                fontSize = 12.sp, 
                                fontWeight = FontWeight.Medium, 
                                color = Color(0xFF9A3412)
                            )
                        }
                    }
                }
            }
            
            if (uiState is ChatUiState.Error) {
                item {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Error: ${(uiState as ChatUiState.Error).message}",
                            color = MaterialTheme.colorScheme.error,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        // Input Area
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.White)
                .border(width = 1.dp, color = EditorialOrange100)
                .padding(16.dp)
                .padding(bottom = 16.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(EditorialSlate50)
                    .border(1.dp, EditorialSlate200, RoundedCornerShape(16.dp))
                    .padding(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                BasicTextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 12.dp, vertical = 12.dp),
                    textStyle = TextStyle(color = EditorialSlate900, fontSize = 14.sp),
                    cursorBrush = SolidColor(EditorialOrange600),
                    decorationBox = { innerTextField ->
                        if (inputText.isEmpty()) {
                            Text("Ask about scriptures...", color = EditorialSlate400, fontSize = 14.sp)
                        }
                        innerTextField()
                    }
                )
                IconButton(
                    onClick = {
                        if (inputText.isNotBlank() && uiState !is ChatUiState.Loading) {
                            viewModel.sendMessage(inputText)
                            inputText = ""
                        }
                    },
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(EditorialOrange600)
                ) {
                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = Color.White)
                }
            }
            
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 12.dp, start = 4.dp, end = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("RESEARCH", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = EditorialSlate500, letterSpacing = 1.5.sp, modifier = Modifier.background(EditorialSlate100, RoundedCornerShape(4.dp)).padding(horizontal = 8.dp, vertical = 4.dp))
                    Text("PHASE 2", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = EditorialSlate500, letterSpacing = 1.5.sp, modifier = Modifier.background(EditorialSlate100, RoundedCornerShape(4.dp)).padding(horizontal = 8.dp, vertical = 4.dp))
                }
                TextButton(
                    onClick = { viewModel.retry() },
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Text("Retry Engine", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFC2410C), textDecoration = TextDecoration.Underline)
                }
        }
    }
}
}



@Composable
fun ChatMessageItem(message: ChatMessage) {
    if (message.isUser) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.End
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.85f)
                    .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 0.dp, bottomEnd = 16.dp, bottomStart = 16.dp))
                    .background(EditorialOrange600)
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Text(text = message.text, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium, lineHeight = 20.sp)
            }
            Text("Just now", fontSize = 10.sp, color = EditorialSlate400, modifier = Modifier.padding(top = 4.dp, end = 4.dp))
        }
    } else {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.Start
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .clip(RoundedCornerShape(topStart = 0.dp, topEnd = 16.dp, bottomEnd = 16.dp, bottomStart = 16.dp))
                    .background(Color.White)
                    .border(1.dp, EditorialOrange100, RoundedCornerShape(topStart = 0.dp, topEnd = 16.dp, bottomEnd = 16.dp, bottomStart = 16.dp))
                    .padding(16.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(bottom = 8.dp)
                ) {
                    Text("AI RESPONSE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFFC2410C), modifier = Modifier.background(EditorialOrange100, RoundedCornerShape(4.dp)).padding(horizontal = 6.dp, vertical = 2.dp))
                    HorizontalDivider(color = EditorialOrange50, modifier = Modifier.weight(1f))
                }
                
                Text(
                    text = message.text,
                    color = EditorialSlate800,
                    fontSize = 14.sp,
                    lineHeight = 22.sp,
                    fontFamily = FontFamily.Serif
                )
                
                if (message.verificationStatus != VerificationStatus.NONE) {
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("🔎 Verification: ", fontSize = 11.sp, color = EditorialSlate500, fontWeight = FontWeight.Bold)
                        val (statusText, statusColor) = when (message.verificationStatus) {
                            VerificationStatus.VERIFIED -> "✅ Verified" to EditorialGreen500
                            VerificationStatus.PARTIALLY_VERIFIED -> "⚠️ Partially Verified" to Color(0xFFD97706)
                            VerificationStatus.NOT_VERIFIED -> "❓ Not Verified" to Color(0xFFDC2626)
                            else -> "" to Color.Transparent
                        }
                        Text(statusText, fontSize = 11.sp, color = statusColor, fontWeight = FontWeight.Bold)
                    }
                }
                
                if (message.sourceMetadata.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("📚 Sources:", fontSize = 11.sp, color = EditorialSlate500, fontWeight = FontWeight.Bold)
                    message.sourceMetadata.forEach { src ->
                        val icon = if (src.sourceType.contains("web", ignoreCase = true)) "🌐" else "📜"
                        Text(
                            text = "$icon ${src.title} - ${src.reference}\n   (${src.sourceType})", 
                            fontSize = 11.sp, 
                            color = EditorialSlate700,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                        Text(
                            text = "Status: ${src.verificationStatus.name.replace("_", " ")}",
                            fontSize = 9.sp,
                            color = EditorialSlate400,
                            modifier = Modifier.padding(start = 16.dp)
                        )
                    }
                }
                
                if (message.youtubeSources.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("▶️ Related Videos:", fontSize = 11.sp, color = EditorialSlate500, fontWeight = FontWeight.Bold)
                    val uriHandler = androidx.compose.ui.platform.LocalUriHandler.current
                    
                    message.youtubeSources.forEach { y ->
                        Column(
                            modifier = Modifier
                                .padding(top = 8.dp)
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(EditorialSlate50)
                                .padding(12.dp)
                        ) {
                            Text(y.title, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = EditorialSlate800)
                            Text(y.channelTitle, fontSize = 10.sp, color = EditorialSlate500, modifier = Modifier.padding(top = 2.dp, bottom = 8.dp))
                            
                            androidx.compose.material3.TextButton(
                                onClick = { uriHandler.openUri("https://www.youtube.com/watch?v=${y.videoId}") },
                                contentPadding = PaddingValues(0.dp),
                                modifier = Modifier.height(24.dp)
                            ) {
                                Text("▶️ Watch on YouTube", fontSize = 11.sp, color = Color(0xFFC2410C), fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

