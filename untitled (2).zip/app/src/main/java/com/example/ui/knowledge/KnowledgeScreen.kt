package com.example.ui.knowledge

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.AppDatabase
import com.example.data.KnowledgeEntity

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KnowledgeScreen() {
    val context = LocalContext.current
    val dao = remember { AppDatabase.getDatabase(context).knowledgeDao() }
    val viewModel: KnowledgeViewModel = viewModel(factory = KnowledgeViewModelFactory(dao))
    
    val query by viewModel.searchQuery.collectAsState()
    val results by viewModel.knowledgeList.collectAsState()

    Column(modifier = Modifier.fillMaxSize().background(Color(0xFFF9FAFB))) {
        TopAppBar(
            title = { Text("Dharma Knowledge Base", fontWeight = FontWeight.Bold) },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = Color.White,
                titleContentColor = Color(0xFF1F2937)
            )
        )
        
        OutlinedTextField(
            value = query,
            onValueChange = { viewModel.updateSearchQuery(it) },
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            placeholder = { Text("Search scripture, topics, mantras...") },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = "Search") },
            shape = RoundedCornerShape(12.dp),
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = Color.White,
                unfocusedContainerColor = Color.White
            )
        )
        
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(results) { item ->
                KnowledgeCard(item)
            }
        }
    }
}

@Composable
fun KnowledgeCard(entity: KnowledgeEntity) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = entity.category,
                    color = Color(0xFFC2410C),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .background(Color(0xFFFFEDD5), RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                )
                
                val statusColor = when (entity.verifiedStatus.lowercase()) {
                    "verified" -> Color(0xFF15803D)
                    "partially verified" -> Color(0xFFB45309)
                    else -> Color(0xFFB91C1C)
                }
                val statusBg = when (entity.verifiedStatus.lowercase()) {
                    "verified" -> Color(0xFFDCFCE7)
                    "partially verified" -> Color(0xFFFEF3C7)
                    else -> Color(0xFFFEE2E2)
                }
                val statusIcon = when (entity.verifiedStatus.lowercase()) {
                    "verified" -> "✅ "
                    "partially verified" -> "⚠️ "
                    else -> "❓ "
                }
                
                Text(
                    text = statusIcon + entity.verifiedStatus,
                    color = statusColor,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .background(statusBg, RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 4.dp)
                )
            }
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = entity.title,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1F2937)
            )
            
            Spacer(modifier = Modifier.height(4.dp))
            
            Text(
                text = "${entity.scripture} • ${entity.reference}",
                fontSize = 13.sp,
                color = Color(0xFF4B5563),
                fontWeight = FontWeight.Medium
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            if (entity.sanskritText.isNotBlank()) {
                Text(
                    text = entity.sanskritText,
                    fontSize = 15.sp,
                    color = Color(0xFFB91C1C),
                    modifier = Modifier.padding(vertical = 4.dp)
                )
            }
            
            Text(
                text = entity.content,
                fontSize = 14.sp,
                color = Color(0xFF374151),
                lineHeight = 20.sp
            )
            
            if (entity.explanation.isNotBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "ব্যাখ্যা: ${entity.explanation}",
                    fontSize = 13.sp,
                    color = Color(0xFF6B7280),
                    lineHeight = 18.sp
                )
            }
        }
    }
}
