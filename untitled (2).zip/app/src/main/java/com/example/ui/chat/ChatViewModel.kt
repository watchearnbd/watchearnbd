package com.example.ui.chat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.ai.AiRepository
import com.example.ai.AdvancedDecisionEngine
import com.example.ai.ChatMessage
import com.example.data.ChatSessionDao
import com.example.data.ChatSessionEntity
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

sealed class ChatUiState {
    object Idle : ChatUiState()
    data class Loading(val progressMessage: String) : ChatUiState()
    data class Error(val message: String) : ChatUiState()
}

class ChatViewModel(
    private val decisionEngine: AdvancedDecisionEngine,
    private val repository: AiRepository,
    private val chatSessionDao: ChatSessionDao
) : ViewModel() {

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _uiState = MutableStateFlow<ChatUiState>(ChatUiState.Idle)
    val uiState: StateFlow<ChatUiState> = _uiState.asStateFlow()
    
    private val _isDeepResearch = MutableStateFlow(true)
    val isDeepResearch: StateFlow<Boolean> = _isDeepResearch.asStateFlow()
    
    private var lastQuestion: String? = null
    
    private var currentSessionId: String? = null
    private var currentSessionTitle: String = "নতুন আলোচনা"
    private var sessionCreatedDate: Long = 0L
    
    val conversationContext = com.example.ai.ConversationContext()

    fun toggleDeepResearch(enabled: Boolean) { 
        _isDeepResearch.value = enabled 
        if (_messages.value.isNotEmpty()) saveCurrentSession()
    }

    fun startNewChat() {
        currentSessionId = null
        currentSessionTitle = "নতুন আলোচনা"
        _messages.value = emptyList()
        _uiState.value = ChatUiState.Idle
        lastQuestion = null
        conversationContext.resetClarification()
    }

    fun loadSession(session: ChatSessionEntity) {
        currentSessionId = session.id
        currentSessionTitle = session.title
        sessionCreatedDate = session.createdDate
        _isDeepResearch.value = session.chatMode == "DEEP_RESEARCH"
        val type = object : TypeToken<List<ChatMessage>>() {}.type
        val loadedMessages: List<ChatMessage> = try {
            Gson().fromJson(session.messagesJson, type) ?: emptyList()
        } catch (e: Exception) { emptyList() }
        _messages.value = loadedMessages
        _uiState.value = ChatUiState.Idle
        conversationContext.resetClarification()
        conversationContext.conversationTopic = ""
    }

    fun sendMessage(question: String) {
        if (question.isBlank()) return
        lastQuestion = question
        
        if (currentSessionId == null) {
            currentSessionId = UUID.randomUUID().toString()
            sessionCreatedDate = System.currentTimeMillis()
            currentSessionTitle = if (question.length > 30) question.take(30) + "..." else question
        }
        
        _messages.value = _messages.value + ChatMessage(isUser = true, text = question)
        _uiState.value = ChatUiState.Loading("Initializing...")
        
        saveCurrentSession()
        
        viewModelScope.launch {
            try {
                val responseMsg = decisionEngine.processPipeline(question, _messages.value.dropLast(1), _isDeepResearch.value, conversationContext) { progressMsg ->
                    _uiState.value = ChatUiState.Loading(progressMsg)
                }
                _messages.value = _messages.value + responseMsg
                _uiState.value = ChatUiState.Idle
                saveCurrentSession()
            } catch (e: Exception) {
                _uiState.value = ChatUiState.Error(e.message ?: "Unknown error occurred.")
            }
        }
    }
    
    private fun saveCurrentSession() {
        val sessionId = currentSessionId ?: return
        val currentMsgs = _messages.value
        if (currentMsgs.isEmpty()) return
        
        val lastMsgPreview = currentMsgs.last().text.take(50).let { if (it.length == 50) "$it..." else it }
        val gson = Gson()
        
        val entity = ChatSessionEntity(
            id = sessionId,
            title = currentSessionTitle,
            createdDate = sessionCreatedDate,
            updatedDate = System.currentTimeMillis(),
            messageCount = currentMsgs.size,
            chatMode = if (_isDeepResearch.value) "DEEP_RESEARCH" else "NORMAL",
            lastMessagePreview = lastMsgPreview,
            messagesJson = gson.toJson(currentMsgs),
            isPinned = false
        )
        
        viewModelScope.launch {
            chatSessionDao.insert(entity)
        }
    }

    
    fun updateMessageState(messageId: String, isLiked: Boolean, isDisliked: Boolean, isReported: Boolean) {
        val currentMsgs = _messages.value.toMutableList()
        val index = currentMsgs.indexOfFirst { it.id == messageId }
        if (index != -1) {
            val updatedMsg = currentMsgs[index].copy(
                isLiked = isLiked,
                isDisliked = isDisliked,
                isReported = isReported
            )
            currentMsgs[index] = updatedMsg
            _messages.value = currentMsgs
            saveCurrentSession()
        }
    }

    fun retry() {
        lastQuestion?.let {
            if (_messages.value.isNotEmpty() && _messages.value.last().isUser) {
                _messages.value = _messages.value.dropLast(1)
            }
            sendMessage(it)
        }
    }
}

class ChatViewModelFactory(
    private val decisionEngine: AdvancedDecisionEngine,
    private val repository: AiRepository,
    private val chatSessionDao: ChatSessionDao
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return ChatViewModel(decisionEngine, repository, chatSessionDao) as T
    }
}
