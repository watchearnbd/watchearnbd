package com.example.ui.chat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.ai.AiRepository
import com.example.ai.ChatMessage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed class ChatUiState {
    object Idle : ChatUiState()
    data class Loading(val progressMessage: String) : ChatUiState()
    data class Error(val message: String) : ChatUiState()
}

class ChatViewModel(private val repository: AiRepository) : ViewModel() {
    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _uiState = MutableStateFlow<ChatUiState>(ChatUiState.Idle)
    val uiState: StateFlow<ChatUiState> = _uiState.asStateFlow()
    
    private val _isDeepResearch = MutableStateFlow(true)
    val isDeepResearch: StateFlow<Boolean> = _isDeepResearch.asStateFlow()
    
    private var lastQuestion: String? = null

    fun toggleDeepResearch(enabled: Boolean) { 
        _isDeepResearch.value = enabled 
    }

    fun sendMessage(question: String) {
        if (question.isBlank()) return
        lastQuestion = question
        _messages.value = _messages.value + ChatMessage(isUser = true, text = question)
        _uiState.value = ChatUiState.Loading("Initializing...")
        
        viewModelScope.launch {
            try {
                val responseMsg = repository.getAiResponse(question, _messages.value.dropLast(1), _isDeepResearch.value) { progressMsg ->
                    _uiState.value = ChatUiState.Loading(progressMsg)
                }
                _messages.value = _messages.value + responseMsg
                _uiState.value = ChatUiState.Idle
            } catch (e: Exception) {
                _uiState.value = ChatUiState.Error(e.message ?: "Unknown error occurred.")
            }
        }
    }
    
    fun retry() {
        lastQuestion?.let {
            if (_messages.value.isNotEmpty() && _messages.value.last().isUser) {
                _messages.value = _messages.value.dropLast(1)
            }
            sendMessage(it)
        }
    }
}

class ChatViewModelFactory(private val repository: AiRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return ChatViewModel(repository) as T
    }
}
