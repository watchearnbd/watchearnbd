package com.example.ai

data class ConversationContext(
    var lastUserMessage: String = "",
    var lastAiMessage: String = "",
    var currentIntent: String = "",
    var pendingClarification: Boolean = false,
    var clarificationOptions: List<String> = emptyList(),
    var pendingTargetId: String? = null,
    var conversationTopic: String = "",
    var currentDeity: String = "",
    var currentScripture: String = "",
    var pendingIntent: String = "",
    var lastKnowledgeEntryId: Int? = null,
    var lastMentionedEntity: String = "",
    var lastMentionedMantra: String = "",
    var lastMentionedShloka: String = "",
    var responseLanguage: String = "Bengali",
    var language: String = "bn",
    var clarificationAttempts: Int = 0,
    var lastClarificationQuestion: String = ""
) {
    fun resetClarification() {
        pendingClarification = false
        clarificationOptions = emptyList()
        pendingTargetId = null
        clarificationAttempts = 0
        lastClarificationQuestion = ""
    }
}
