package com.example.ai

import com.example.data.KnowledgeEntity
import kotlin.math.max

enum class MatchConfidence {
    HIGH, MEDIUM, LOW, NONE
}

data class MatchResult(
    val entity: KnowledgeEntity?,
    val confidence: MatchConfidence,
    val requiresClarification: Boolean = false,
    val clarificationMessage: String = "",
    val options: List<com.example.data.KnowledgeEntity> = emptyList()
)

object SmartKnowledgeMatcher {

    private val stopWords = setOf(
        "কী", "কি", "what", "বলতে", "বোঝায়", "সম্পর্কে", "বলো", "tell", "about", 
        "হলো", "হল", "is", "are", "the", "a", "an", "এর", "টা", "টি"
    )

    private val synonyms = mapOf(
        listOf("গীতা", "ভগবদ্গীতা", "gita", "bhagavad gita") to "gita",
        listOf("আসল", "মূল", "প্রকৃত", "original", "real", "সংস্কৃত", "sanskrit") to "original",
        listOf("নাম", "পরিচয়", "name", "identity") to "name",
        listOf("গায়ত্রী", "gayatri") to "gayatri",
        listOf("মন্ত্র", "mantra", "মন্ত্রটা") to "mantra",
        listOf("কর্মযোগ", "karma yoga", "karmayog") to "karmayoga",
        listOf("সহজ ভাষায়", "সহজ করে", "in simple words", "simply") to "simple"
    )

    private fun semanticNormalize(text: String): String {
        var norm = text.lowercase()
            .replace(Regex("[\\p{Punct}।—-]+"), " ")
            .replace(Regex("[\\s]+"), " ")
            .trim()
            
        // Pre-replace multi-word synonyms and common variations
        for ((synList, canon) in synonyms) {
            for (syn in synList) {
                if (syn.contains(" ")) {
                    norm = norm.replace(syn, canon)
                }
            }
        }
                    
        val tokens = norm.split(" ").filter { !stopWords.contains(it) }
        val canonicalTokens = tokens.map { token ->
            var canonical = token
            for ((synList, canon) in synonyms) {
                if (synList.any { it == token || (token.contains(it) && it.length > 3) }) {
                    canonical = canon
                    break
                }
            }
            canonical
        }
        return canonicalTokens.joinToString(" ")
    }

    private fun normalize(text: String): String {
        return text.lowercase()
            .replace(Regex("[\\p{Punct}।—-]+"), " ")
            .replace(Regex("[\\s]+"), " ")
            .trim()
    }

    fun match(query: String, knowledgeBase: List<KnowledgeEntity>): MatchResult {
        val normalizedQuery = normalize(query)
        if (normalizedQuery.isBlank()) return MatchResult(null, MatchConfidence.NONE)

        var bestMatch: KnowledgeEntity? = null
        var bestScore = 0.0
        val highMatches = mutableMapOf<String, KnowledgeEntity>()

        for (entity in knowledgeBase) {
            val score = calculateScore(normalizedQuery, query, entity)
            if (score >= 0.80) {
                val baseTitle = entity.title.split("(").first().trim()
                highMatches[baseTitle] = entity
            }
            if (score > bestScore) {
                bestScore = score
                bestMatch = entity
            }
        }

        if (highMatches.size > 1 && bestScore < 1.0) {
            val options = highMatches.values.take(5).toList()
            val clarificationMsg = "আপনি ${query} সম্পর্কে কোনটি জানতে চান?\n" + options.mapIndexed { i, opt -> "${i+1}. ${opt.title}" }.joinToString("\n")
            return MatchResult(bestMatch, MatchConfidence.MEDIUM, true, clarificationMsg, options)
        }

        return when {
            bestScore >= 0.80 -> MatchResult(bestMatch, MatchConfidence.HIGH)
            bestScore >= 0.50 -> MatchResult(bestMatch, MatchConfidence.MEDIUM, true, "আপনি কি '${bestMatch?.title}' এর কথা বলছেন?")
            else -> MatchResult(null, MatchConfidence.LOW, true, "আপনি কোন বিষয়টি বা মন্ত্রটি বোঝাচ্ছেন একটু পরিষ্কার করে বলবেন? নামটা হয়তো একটু ভিন্নভাবে লেখা হয়েছে। 😊")
        }
    }
        
    private fun levenshteinRatio(s1: String, s2: String): Double {
        if (s1 == s2) return 1.0
        if (s1.isEmpty() || s2.isEmpty()) return 0.0
        val maxLen = maxOf(s1.length, s2.length).toDouble()
        
        var costs = IntArray(s2.length + 1) { it }
        var newCosts = IntArray(s2.length + 1)
        for (i in 0 until s1.length) {
            newCosts[0] = i + 1
            for (j in 0 until s2.length) {
                val match = if (s1[i] == s2[j]) 0 else 1
                val costReplace = costs[j] + match
                val costInsert = costs[j + 1] + 1
                val costDelete = newCosts[j] + 1
                newCosts[j + 1] = minOf(costInsert, costDelete, costReplace)
            }
            val swap = costs
            costs = newCosts
            newCosts = swap
        }
        val distance = costs[s2.length]
        return 1.0 - (distance / maxLen)
    }

    private fun calculateScore(normalizedQuery: String, rawQuery: String, entity: KnowledgeEntity): Double {
        val titleNorm = normalize(entity.title)
        val aliasesList = entity.tags + "," + entity.aliases + "," + entity.semanticKeywords + "," + entity.phoneticKeywords
        val aliases = aliasesList.split(",").map { normalize(it) }.filter { it.isNotBlank() }

        val querySemantic = semanticNormalize(rawQuery)
        val titleSemantic = semanticNormalize(entity.title)
        val aliasesSemantic = aliasesList.split(",").map { semanticNormalize(it) }.filter { it.isNotBlank() }

        // 1. Exact Semantic or Exact String Match
        if (normalizedQuery == titleNorm || (querySemantic.isNotBlank() && querySemantic == titleSemantic)) return 1.0

        // 2. Exact Alias Match
        if (aliases.any { it == normalizedQuery } || (querySemantic.isNotBlank() && aliasesSemantic.any { it == querySemantic })) return 0.95
        
        var maxScore = 0.0

        // 3. String similarity (Fuzzy Match) for full strings
        maxScore = maxOf(maxScore, levenshteinRatio(normalizedQuery, titleNorm))
        
        for (alias in aliases) {
            maxScore = maxOf(maxScore, levenshteinRatio(normalizedQuery, alias) * 0.95)
            // Partial match logic (if query is part of alias or vice versa, but long enough)
            if (alias.contains(normalizedQuery) || normalizedQuery.contains(alias)) {
                val ratio = minOf(alias.length, normalizedQuery.length).toDouble() / maxOf(alias.length, normalizedQuery.length)
                if (ratio > 0.3) maxScore = maxOf(maxScore, 0.70 + (ratio * 0.2))
                if (alias.length > 4 && normalizedQuery.contains(alias)) maxScore = maxOf(maxScore, 0.86)
            }
        }
        
        if (titleNorm.contains(normalizedQuery) || normalizedQuery.contains(titleNorm)) {
            val ratio = minOf(titleNorm.length, normalizedQuery.length).toDouble() / maxOf(titleNorm.length, normalizedQuery.length)
            if (ratio > 0.3) maxScore = maxOf(maxScore, 0.75 + (ratio * 0.2))
            if (titleNorm.length > 4 && normalizedQuery.contains(titleNorm)) maxScore = maxOf(maxScore, 0.86)
        }

        // Chapter and verse parsing for scriptures
        val scriptureNorm = normalize(entity.scripture)
        if (scriptureNorm.isNotBlank() && (normalizedQuery.contains(scriptureNorm) || (scriptureNorm.contains("গীতা") && normalizedQuery.contains("গীতা")) || (scriptureNorm.contains("gita") && normalizedQuery.contains("gita")))) {
            val numbers = Regex("\\d+").findAll(normalizedQuery).map { it.value }.toList()
            val entityRefNorm = normalize(entity.reference)
            val entityNumbers = Regex("\\d+").findAll(entityRefNorm).map { it.value }.toList()
            
            if (numbers.isNotEmpty() && entityNumbers.isNotEmpty()) {
                val intersection = numbers.intersect(entityNumbers.toSet())
                if (intersection.size == entityNumbers.size || (intersection.isNotEmpty() && numbers.size <= 2)) {
                    maxScore = maxOf(maxScore, 0.95)
                    return 0.95
                }
            } else if (normalizedQuery.contains(scriptureNorm)) {
               maxScore = maxOf(maxScore, 0.6)
            }
        }

        // 4. Fuzzy Token Matching
        val queryTokens = normalizedQuery.split(" ").filter { it.length > 2 }
        if (queryTokens.isNotEmpty()) {
            val titleTokens = titleNorm.split(" ")
            
            var matchedTokens = 0.0
            for (token in queryTokens) {
                var bestTokenMatch = 0.0
                
                // Compare with title tokens
                for (tToken in titleTokens) {
                    bestTokenMatch = maxOf(bestTokenMatch, levenshteinRatio(token, tToken))
                }
                
                // Compare with alias tokens
                for (alias in aliases) {
                    for (aToken in alias.split(" ")) {
                        bestTokenMatch = maxOf(bestTokenMatch, levenshteinRatio(token, aToken) * 0.9)
                    }
                }
                
                if (bestTokenMatch > 0.75) {
                    matchedTokens += bestTokenMatch
                }
            }
            
            val tokenScore = (matchedTokens / queryTokens.size) * 0.9 // Max 0.9
            maxScore = maxOf(maxScore, tokenScore)
        }

        return maxScore
    }
}
