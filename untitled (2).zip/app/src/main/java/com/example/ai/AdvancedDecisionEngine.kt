package com.example.ai

import com.example.research.ILocalKnowledgeProvider
import com.example.data.KnowledgeEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class AdvancedDecisionEngine(
    private val localKnowledgeProvider: ILocalKnowledgeProvider,
    private val aiProvider: AiProvider // Retained for constructor signature, but NOT USED to enforce API ban.
) {
    suspend fun processPipeline(
        userMessage: String,
        history: List<ChatMessage>,
        isDeepResearch: Boolean,
        contextState: ConversationContext,
        onProgress: (String) -> Unit
    ): ChatMessage = withContext(Dispatchers.IO) {
        
        onProgress("Internal Brain: Analyzing Intent & Context...")
        
        val rawMessage = userMessage.trim()
        val lowerMessage = rawMessage.lowercase()
        val lastAiMsg = history.lastOrNull { !it.isUser }?.text ?: ""
        val lastUserMsg = history.lastOrNull { it.isUser }?.text ?: ""
        
        // --- 1. ACKNOWLEDGMENTS & SHORT RESPONSES ---
        if (isAcknowledgment(lowerMessage)) {
            val responses = listOf(
                "জি, আর কোনো বিষয়ে জানতে চান?",
                "বুঝতে পেরেছি। আপনার আধ্যাত্মিক জিজ্ঞাসা থাকলে করতে পারেন।",
                "আচ্ছা! শাস্ত্র বা ধর্ম সম্পর্কে অন্য কোনো প্রশ্ন আছে কি?",
                "ঠিক আছে। আমি কি আপনাকে অন্য কোনোভাবে সাহায্য করতে পারি?"
            )
            val validResponses = responses.filter { it != lastAiMsg }
            return@withContext buildUnverifiedResponse(validResponses.randomOrNull() ?: responses.first())
        }

        if (isAgreement(lowerMessage)) {
            if (contextState.pendingClarification) {
                if (contextState.clarificationOptions.size == 1 && contextState.pendingTargetId != null) {
                    val resolvedQuery = contextState.pendingTargetId!!
                    contextState.resetClarification()
                    return@withContext processPipeline(resolvedQuery, history, isDeepResearch, contextState, onProgress)
                } else if (contextState.clarificationOptions.size > 1) {
                    val msg = "অবশ্যই। আপনি কোনটি চান—\n" + contextState.clarificationOptions.mapIndexed { i, opt -> "${i+1}. $opt" }.joinToString("\n")
                    return@withContext buildUnverifiedResponse(msg)
                }
            } else {
                val responses = listOf(
                    "জি, আপনার আর কোনো প্রশ্ন থাকলে করতে পারেন।",
                    "হ্যাঁ, আর কোনো বিষয় জানার থাকলে বলুন।"
                )
                val validResponses = responses.filter { it != lastAiMsg }
                return@withContext buildUnverifiedResponse(validResponses.randomOrNull() ?: responses.first())
            }
        }
        
        val isFirst = listOf("প্রথমটা", "1", "১", "প্রথম").any { lowerMessage == it || lowerMessage.contains(it) }
        val isSecond = listOf("দ্বিতীয়টা", "2", "২", "দ্বিতীয়", "শেষেরটা").any { lowerMessage == it || lowerMessage.contains(it) }
        
        if (contextState.pendingClarification && contextState.clarificationOptions.size > 1) {
            if (isFirst) {
                val resolvedQuery = contextState.clarificationOptions[0]
                contextState.resetClarification()
                return@withContext processPipeline(resolvedQuery, history, isDeepResearch, contextState, onProgress)
            } else if (isSecond) {
                val resolvedQuery = contextState.clarificationOptions[1]
                contextState.resetClarification()
                return@withContext processPipeline(resolvedQuery, history, isDeepResearch, contextState, onProgress)
            }
            
            // Check if they typed part of the option name (e.g. "দুর্গাপূজা" from "'যা দেবী সর্বভূতেষু' না দুর্গাপূজা")
            val matchedOption = contextState.clarificationOptions.find { opt -> 
                val cleanOpt = opt.lowercase().replace("'", "").replace("\"", "")
                lowerMessage.contains(cleanOpt) || cleanOpt.contains(lowerMessage.replace(" বলতেছি", "").replace(" বলছি", "").trim())
            }
            if (matchedOption != null) {
                contextState.resetClarification()
                return@withContext processPipeline(matchedOption, history, isDeepResearch, contextState, onProgress)
            }
        }
        
        // Pronouns moved down

        contextState.lastUserMessage = rawMessage
        

        // --- 2. GREETINGS & SMALL TALK ---
        if (isGreeting(lowerMessage)) {
            val responses = listOf(
                "নমস্কার 🙏 হাই! কেমন আছো? আজ কী নিয়ে কথা বলতে চাও?",
                "হ্যালো 🙏 তোমাকে স্বাগতম। কী জানতে বা আলোচনা করতে চাও?",
                "নমস্কার 🙏 শুভেচ্ছা রইল। আজ কী নিয়ে জানতে বা কথা বলতে চাও?"
            )
            val validResponses = responses.filter { it != lastAiMsg }
            return@withContext buildUnverifiedResponse(validResponses.randomOrNull() ?: responses.first())
        }
        if (isHowAreYou(lowerMessage)) {
            val responses = listOf(
                "আমি ভালো আছি 😊 তোমার সঙ্গে কথা বলতে প্রস্তুত। তুমি কেমন আছো?",
                "আমি বেশ ভালো আছি। তুমি কেমন আছো? আজ কী বিষয়ে কথা বলবো?",
                "আমি ভালো আছি 🙏 আপনার দিনটি কেমন যাচ্ছে?"
            )
            val validResponses = responses.filter { it != lastAiMsg }
            return@withContext buildUnverifiedResponse(validResponses.randomOrNull() ?: responses.first())
        }
        
        val identityQueries = listOf("তোমার নাম কী", "তোমার নাম কি", "what is your name", "তুমি কে", "তোমাকে কী নামে ডাকা হয়", "তোমাকে কি নামে ডাকা হয়", "তুমি কী", "তুমি কি")
        if (identityQueries.any { lowerMessage.contains(it) }) {
            return@withContext buildUnverifiedResponse("আমার নাম Dharma AI। 🙏")
        }
        
        if (lowerMessage.contains("তুমি কী করতে পারো") || lowerMessage.contains("তুমি কি করতে পারো") || lowerMessage.contains("what can you do")) {
            return@withContext buildUnverifiedResponse("আমি হিন্দু ধর্ম, শাস্ত্র, দর্শন, মন্ত্র, পূজা, উৎসব ও আধ্যাত্মিক জ্ঞান সম্পর্কে সাহায্য করতে পারি।")
        }

        if (isWhatDoYouDo(lowerMessage)) {
            val responses = listOf(
                "তোমার প্রশ্নের উত্তর দেওয়া আর Dharma ও সাধারণ জ্ঞান নিয়ে সাহায্য করাই আমার কাজ। 😊",
                "আমি তোমার প্রশ্নের উত্তর দিতে এবং ধর্ম, শাস্ত্র ও নানা বিষয় নিয়ে কথা বলার জন্য প্রস্তুত। 😊"
            )
            val validResponses = responses.filter { it != lastAiMsg }
            return@withContext buildUnverifiedResponse(validResponses.randomOrNull() ?: responses.first())
        }

        // --- 3. CORRECTION BRAIN (Specific rules for common misconceptions) ---
        if (lowerMessage.contains("গীতা") && lowerMessage.contains("অধ্যায়")) {
            val hasWrongChapter = listOf("২৫", "25", "কুড়ি", "তিরিশ", "১০০", "100", "১০", "10", "১৫", "15", "৭", "7").any { lowerMessage.contains(it) }
            val hasCorrectChapter = lowerMessage.contains("১৮") || lowerMessage.contains("18") || lowerMessage.contains("আঠারো")
            if (hasWrongChapter && !hasCorrectChapter) {
                return@withContext buildUnverifiedResponse("এখানে একটি ছোট সংশোধন আছে 🙏 ভগবদ্গীতায় মোট ১৮টি অধ্যায় রয়েছে।")
            }
        }
        
        // --- 4. AMBIGUITY BRAIN ---
        if (lowerMessage == "শক্তি কী?" || lowerMessage == "শক্তি কি?" || lowerMessage == "শক্তি কি" || lowerMessage == "শক্তি কী") {
            return@withContext buildUnverifiedResponse("আপনি ‘শক্তি’ বলতে হিন্দু দর্শনের Shakti তত্ত্ব বোঝাচ্ছেন, নাকি Physics-এর energy বোঝাচ্ছেন?")
        }

        // --- 5. CONTEXT AWARENESS & COREFERENCE RESOLUTION ---
        var effectiveQuery = rawMessage
        var isFollowUp = false
        
        val followUpKeywords = listOf("এটা", "ওটা", "এর", "কেন", "আরও", "বিস্তারিত", "মানে", "অর্থ", "বুঝলাম না", "তার", "সেটার", "উদাহরণ", "তারপর", "তারপরে", "ওইটার", "এটার", "আগেরটা", "আগের", "ওই", "এই", "সেই", "উৎস", "কোথায়")
        
        val hasPronoun = followUpKeywords.any { lowerMessage.contains(it) }
        
        if (hasPronoun && contextState.lastKnowledgeEntryId != null) {
            val lastEntity = localKnowledgeProvider.getById(contextState.lastKnowledgeEntryId!!)
            if (lastEntity != null) {
                val isMeaningQuery = listOf("মানে", "অর্থ", "বলতে কী", "কি বোঝায়", "এর মানে", "এটার অর্থ").any { lowerMessage.contains(it) }
                val isSourceQuery = listOf("উৎস", "কোথায়", "শাস্ত্র", "source").any { lowerMessage.contains(it) }
                
                if (isMeaningQuery && (lastEntity.banglaMeaning.isNotBlank() || lastEntity.explanation.isNotBlank())) {
                    val meaning = if (lastEntity.banglaMeaning.isNotBlank()) lastEntity.banglaMeaning else lastEntity.explanation
                    return@withContext buildUnverifiedResponse("${lastEntity.title.split("(").first().trim()}-এর অর্থ:
$meaning")
                } else if (isSourceQuery && lastEntity.scripture.isNotBlank()) {
                    val sourceStr = "${lastEntity.scripture} ${if (lastEntity.reference.isNotBlank()) "(${lastEntity.reference})" else ""}"
                    return@withContext buildUnverifiedResponse("${lastEntity.title.split("(").first().trim()} পাওয়া যায়:
$sourceStr")
                }
            }
        }
        
        if (hasPronoun && contextState.conversationTopic.isNotBlank()) {
            effectiveQuery = effectiveQuery.replace(Regex("(ওইটার|এটার|তার|এর|সেটার|আগেরটা|আগের|ওই|এই|সেই)"), contextState.conversationTopic)
        }
        val isAskingForNames = listOf("নামগুলো", "নামগুলি").any { lowerMessage.contains(it) }
        if (isAskingForNames && contextState.conversationTopic.isNotBlank()) {
             effectiveQuery = contextState.conversationTopic + " নাম"
        }
        
        val isShortQuery = rawMessage.length <= 15

        if (followUpKeywords.any { lowerMessage.contains(it) } || isShortQuery) {
            val isPrevGeneric = isGreeting(lastUserMsg.lowercase()) || isHowAreYou(lastUserMsg.lowercase()) || isWhatDoYouDo(lastUserMsg.lowercase()) || isAcknowledgment(lastUserMsg.lowercase()) || isAgreement(lastUserMsg.lowercase())
            
            if (lastUserMsg.isNotBlank() && !lastUserMsg.equals(rawMessage, ignoreCase = true) && !isPrevGeneric) {
                isFollowUp = true
                effectiveQuery = "$lastUserMsg $rawMessage"
            }
        }

        // --- 6. CLARIFICATION RULE ---
        if (effectiveQuery.length < 3 && !isFollowUp) {
            return@withContext buildUnverifiedResponse("আপনার প্রশ্নটি অস্পষ্ট। আপনি কি আরেকটু বিস্তারিতভাবে বলবেন?")
        }

        // --- 7. KNOWLEDGE BASE SEARCH ---
        onProgress("Internal Brain: Searching Local Knowledge Base...")
        val allKnowledge = localKnowledgeProvider.getAllKnowledge()
        val matchResult = SmartKnowledgeMatcher.match(effectiveQuery, allKnowledge)
        
        var results: List<KnowledgeEntity> = emptyList()
        if (matchResult.confidence == MatchConfidence.HIGH) {
            results = listOfNotNull(matchResult.entity)
            contextState.resetClarification()
            contextState.conversationTopic = matchResult.entity?.title ?: contextState.conversationTopic
        } else if (matchResult.confidence == MatchConfidence.MEDIUM || matchResult.requiresClarification) {
            if (matchResult.options.isNotEmpty()) {
                val q = matchResult.clarificationMessage
                if (contextState.lastClarificationQuestion == q && contextState.clarificationAttempts > 0) {
                    contextState.clarificationAttempts++
                    return@withContext buildUnverifiedResponse("আমি আগের প্রশ্নটির উত্তর পাওয়ার অপেক্ষায় আছি। আপনি চাইলে নির্দিষ্ট করে বলতে পারেন।")
                }
                contextState.pendingClarification = true
                contextState.lastClarificationQuestion = q
                contextState.clarificationAttempts++
                contextState.clarificationOptions = matchResult.options.map { it.title.split("(").first().trim() }
                if (matchResult.options.size == 1) {
                    contextState.pendingTargetId = matchResult.options.first().title
                }
            }
            return@withContext buildUnverifiedResponse(matchResult.clarificationMessage)
        } else {
            contextState.resetClarification()
        }

        // --- 8. UNKNOWN / OUT OF DOMAIN RESPONSE (MANTRA/SCRIPTURE SAFETY) ---
        if (results.isEmpty()) {
            if (matchResult.confidence == MatchConfidence.LOW && matchResult.clarificationMessage.isNotBlank()) {
                val isMantraOrSloka = lowerMessage.contains("মন্ত্র") || lowerMessage.contains("শ্লোক")
                if (isMantraOrSloka) {
                    return@withContext buildUnverifiedResponse(matchResult.clarificationMessage)
                }
            }
            val religiousTerms = listOf("গীতা", "বেদ", "ঈশ্বর", "ধর্ম", "কৃষ্ণ", "রাম", "পূজা", "মন্ত্র", "শ্লোক", "ভগবান", "শিব", "কালী", "হিন্দু")
            val hasReligiousTerm = religiousTerms.any { effectiveQuery.contains(it) }
            
            val isMantraOrSloka = lowerMessage.contains("মন্ত্র") || lowerMessage.contains("শ্লোক")
            
            if (!hasReligiousTerm && !isFollowUp) {
                val outOfDomainResponses = listOf(
                    "আমি একটি ধর্মীয় ও শাস্ত্রীয় সহায়ক। আপনার প্রশ্নটি আমার বিষয়ের বাইরের বলে মনে হচ্ছে। শাস্ত্র বা ধর্ম সম্পর্কিত কিছু জানতে চাইলে আমাকে জিজ্ঞেস করতে পারেন।",
                    "আমার মূল কাজ হলো শাস্ত্র ও ধর্ম নিয়ে আলোচনা করা। এ বিষয়ে কিছু জানতে চাইলে বলতে পারেন।"
                )
                val validOutOfDomain = outOfDomainResponses.filter { it != lastAiMsg }
                return@withContext buildUnverifiedResponse(validOutOfDomain.randomOrNull() ?: outOfDomainResponses.first())
            }
            
            if (isMantraOrSloka) {
                return@withContext buildUnverifiedResponse("এই মন্ত্র বা শ্লোকটির নির্ভরযোগ্য পাঠ বা উৎস আমি নিশ্চিতভাবে যাচাই করতে পারিনি। ভুল তথ্য দেওয়ার চেয়ে আমি সেটা পরিষ্কারভাবে জানাচ্ছি।")
            }
            
            // CRITICAL TRUTH RULE implementation
            return@withContext buildUnverifiedResponse("এই তথ্যটি আমার Verified Knowledge Base-এ নেই।")
        }

        // --- 9. RESPONSE GENERATION (RULE-BASED NLG) ---
        onProgress("Internal Brain: Formatting Final Answer...")
        val primaryResult = results.first()
        
        contextState.lastKnowledgeEntryId = primaryResult.id
        contextState.conversationTopic = primaryResult.title.split("(").first().trim()
        contextState.currentDeity = primaryResult.deity
        
        val sb = java.lang.StringBuilder()
        
        // Handle AI RESPONSE RULE injected in explanation
        if (primaryResult.explanation.contains("AI RESPONSE RULE")) {
            val isCountQuery = listOf("কয়টি নাম", "কতটি নাম", "কতগুলো নাম", "how many names", "how many").any { lowerMessage.contains(it) }
            val isListQuery = listOf("নামগুলো", "108 naam", "108 নাম", "সবগুলো", "তালিকা", "108 name").any { lowerMessage.contains(it) }
            val isMainMantraQuery = listOf("প্রধান মন্ত্র", "main mantra", "কোন মন্ত্র").any { lowerMessage.contains(it) }
            
            if (primaryResult.title.contains("108 Names")) {
                if (isCountQuery && !isListQuery) {
                    sb.append("শ্রীকৃষ্ণের ১০৮ নামের একটি প্রচলিত অষ্টোত্তর শতনামাবলী রয়েছে। বিভিন্ন শাস্ত্রীয় ও ভক্তি-পরম্পরায় নামের তালিকায় কিছু পার্থক্য দেখা যেতে পারে। Dharma AI-তে একটি নির্দিষ্ট উৎসভিত্তিক ১০৮ নামের তালিকা সংরক্ষিত রয়েছে।")
                } else {
                    sb.append(primaryResult.content)
                }
            } else if (primaryResult.title.contains("Hare Krishna")) {
                 if (isMainMantraQuery) {
                     sb.append("শ্রীকৃষ্ণের উপাসনায় বিভিন্ন বৈষ্ণব পরম্পরায় বিভিন্ন মন্ত্র ব্যবহৃত হয়। এর মধ্যে হরে কৃষ্ণ মহামন্ত্র এবং 'ওঁ নমো ভগবতে বাসুদেবায়' বিশেষভাবে পরিচিত।")
                 } else {
                     sb.append(primaryResult.content)
                 }
            } else {
                 sb.append(primaryResult.content)
            }
        } else {
            val isDetailed = listOf("বিস্তারিত", "আরও", "সব", "ব্যাখ্যা", "বুঝিয়ে").any { lowerMessage.contains(it) }
            val isMeaning = listOf("মানে", "অর্থ", "বলতে কী", "কি বোঝায়").any { lowerMessage.contains(it) }
            val isExample = listOf("উদাহরণ", "যেমন").any { lowerMessage.contains(it) }
            val isReasoning = listOf("কেন", "কারণ").any { lowerMessage.contains(it) }
    
            if (isDetailed) {
            if (primaryResult.content.isNotBlank()) sb.append(primaryResult.content).append("\n\n")
            if (primaryResult.sanskritText.isNotBlank()) sb.append("মূল শ্লোক/মন্ত্র:\n${primaryResult.sanskritText}\n\n")
            if (primaryResult.banglaMeaning.isNotBlank()) sb.append("অর্থ:\n${primaryResult.banglaMeaning}\n\n")
            if (primaryResult.explanation.isNotBlank()) sb.append("ব্যাখ্যা:\n${primaryResult.explanation}")
        } else if (isMeaning) {
            if (primaryResult.banglaMeaning.isNotBlank()) {
                sb.append(primaryResult.banglaMeaning)
                if (primaryResult.explanation.isNotBlank()) sb.append("\n\nব্যাখ্যা: ").append(primaryResult.explanation)
            } else if (primaryResult.explanation.isNotBlank()) {
                sb.append(primaryResult.explanation)
            } else {
                sb.append(primaryResult.content)
            }
        } else if (isExample || isReasoning) {
             if (primaryResult.explanation.isNotBlank()) {
                 sb.append(primaryResult.explanation)
             } else {
                 sb.append(primaryResult.content)
             }
        } else {
            // Concise response
            if (primaryResult.content.isNotBlank()) {
                sb.append(primaryResult.content)
            } else if (primaryResult.banglaMeaning.isNotBlank()) {
                sb.append(primaryResult.banglaMeaning)
            } else if (primaryResult.explanation.isNotBlank()) {
                sb.append(primaryResult.explanation)
            }
            if (primaryResult.sanskritText.isNotBlank() && !isShortQuery) {
                 sb.append("\n\n(শ্লোক: ${primaryResult.sanskritText})")
            }
        }
        
        }

        var finalResponse = sb.toString().trim()
        if (finalResponse.isEmpty()) {
            return@withContext buildUnverifiedResponse("এই তথ্যটি আমার Verified Knowledge Base-এ নেই।")
        }

        val sourcesList = results.map { "${it.scripture} (${it.reference})".trim() }.filter { it.length > 3 }.distinct()

        return@withContext ChatMessage(
            isUser = false,
            text = finalResponse,
            localSources = sourcesList,
            verificationStatus = com.example.research.VerificationStatus.VERIFIED
        )
    }

    private fun isGreeting(text: String): Boolean {
        val greetings = listOf("হাই", "হ্যালো", "নমস্কার", "প্রণাম", "hi", "hello", "nomoshkar")
        val cleanText = text.replace(Regex("\\p{Punct}"), "")
        return greetings.any { cleanText == it || cleanText.startsWith("$it ") }
    }

    private fun isHowAreYou(text: String): Boolean {
        val patterns = listOf("কেমন আছো", "কেমন আছেন", "how are you", "কেমন আছ", "ক্যামন আছো", "কেমন চলল", "কেমন চলছে")
        return patterns.any { text.contains(it) }
    }

    private fun isWhatDoYouDo(text: String): Boolean {
        val patterns = listOf("কি করো", "কী করো", "কি খবর", "কী খবর", "কি করছো", "কী করছো", "what do you do", "what are you doing", "whats up", "what's up")
        return patterns.any { text.contains(it) }
    }

    private fun isAcknowledgment(text: String): Boolean {
        val cleanText = text.replace(Regex("\\p{Punct}"), "").trim()
        val patterns = listOf("ঠিক আছে", "আচ্ছা", "ওকে", "ok", "okay", "হুম", "হু", "বুঝলাম", "শুনছি")
        return patterns.any { cleanText == it }
    }

    private fun isAgreement(text: String): Boolean {
        val cleanText = text.replace(Regex("\\p{Punct}"), "").trim()
        val patterns = listOf("হ্যাঁ", "হ্যা", "yes", "জি", "জী", "হুম", "সেটাই", "ওটাই", "ঠিক", "ঠিক আছে", "haan", "जी", "हाँ")
        if (patterns.any { cleanText == it }) return true
        if (cleanText.startsWith("হ্যাঁ ") || cleanText.startsWith("হ্যা ") || cleanText.startsWith("জি ")) return true
        if (cleanText.contains("বলতেছি") && (cleanText.contains("হ্যাঁ") || cleanText.contains("হ্যা") || cleanText.contains("জি"))) return true
        return false
    }

    private fun isNegation(text: String): Boolean {
        val cleanText = text.replace(Regex("\\p{Punct}"), "").trim()
        val patterns = listOf("না", "no", "না সেটা না", "ওটা না", "অন্যটা", "not that", "नहीं", "वह नहीं")
        if (patterns.any { cleanText == it }) return true
        if (cleanText.startsWith("না ")) return true
        return false
    }

    private fun buildUnverifiedResponse(text: String): ChatMessage {
        return ChatMessage(
            isUser = false,
            text = text,
            localSources = emptyList(),
            verificationStatus = com.example.research.VerificationStatus.NONE
        )
    }
}
