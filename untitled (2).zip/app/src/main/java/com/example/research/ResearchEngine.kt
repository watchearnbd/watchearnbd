package com.example.research

import com.example.ai.AiProvider
import com.example.ai.Content
import com.example.ai.Part
import com.example.data.KnowledgeEntity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class ResearchResult(
    val answer: String,
    val webSources: List<WebResult> = emptyList(),
    val youtubeSources: List<YouTubeResult> = emptyList(),
    val localSources: List<KnowledgeEntity> = emptyList(),
    val verificationStatus: VerificationStatus = VerificationStatus.NONE,
    val sourceMetadata: List<SourceMetadata> = emptyList()
)

class ResearchEngine(
    private val localKnowledgeProvider: ILocalKnowledgeProvider,
    private val webSearchProvider: IWebSearchProvider,
    private val youtubeSearchProvider: IYouTubeSearchProvider,
    private val scriptureVerificationProvider: IScriptureVerificationProvider,
    private val aiProvider: AiProvider
) {
    suspend fun conductResearch(
        question: String,
        chatHistory: List<Content>,
        isDeepResearch: Boolean,
        onProgress: (String) -> Unit
    ): ResearchResult {
        onProgress("🔎 প্রশ্ন বিশ্লেষণ করছি...")
        val analysis = aiProvider.analyzeQuery(question)
        
        onProgress("📚 Local Knowledge পরীক্ষা করছি...")
        val localResults = localKnowledgeProvider.search(question)
        
        var webResults: List<WebResult> = emptyList()
        var youtubeResults: List<YouTubeResult> = emptyList()
        
        // If Local Knowledge is insufficient or Deep Research is explicitly enabled, we require deep research.
        val needsExternalResearch = isDeepResearch || analysis.needsWebSearch || localResults.isEmpty()
        
        if (needsExternalResearch) {
            onProgress("🌐 Web sources খুঁজছি...")
            webResults = webSearchProvider.search(analysis.webSearchQuery ?: question)
            if (analysis.needsYouTube) {
                youtubeResults = youtubeSearchProvider.search(analysis.youtubeSearchQuery ?: question)
            }
        }
        
        onProgress("📖 Reference যাচাই করছি...")
        // Simulate comparison
        onProgress("⚖️ Sources তুলনা করছি...")
        
        val sourceMetadataList = mutableListOf<SourceMetadata>()
        var hasVerified = false
        var hasPartiallyVerified = false
        var hasNotVerified = false
        
        // Verification phase for local sources
        localResults.forEach {
            val isVerified = scriptureVerificationProvider.verify(it.content)
            val status = when (it.verifiedStatus.lowercase()) {
                "verified" -> VerificationStatus.VERIFIED
                "partially verified" -> VerificationStatus.PARTIALLY_VERIFIED
                else -> VerificationStatus.NOT_VERIFIED
            }
            
            if (status == VerificationStatus.VERIFIED) hasVerified = true
            else if (status == VerificationStatus.PARTIALLY_VERIFIED) hasPartiallyVerified = true
            else hasNotVerified = true
            
            sourceMetadataList.add(
                SourceMetadata(
                    title = it.title,
                    domain = "Local Knowledge Base",
                    sourceType = it.category,
                    reference = "${it.scripture} (${it.reference})",
                    summary = it.content.take(100) + "...",
                    relevanceScore = 100, // Highest for local
                    verificationStatus = status
                )
            )
        }
        
        // Source ranking and verification for web
        webResults.forEach {
            var relevance = 50
            var sType = "General web source"
            var vStatus = VerificationStatus.NOT_VERIFIED
            
            val domainLower = it.domain.lowercase()
            val titleLower = it.title.lowercase()
            
            // Basic source ranking logic
            if (domainLower.contains("vedabase") || domainLower.contains("sacred-texts") || domainLower.contains("gita-society")) {
                relevance = 90
                sType = "Primary Scripture / authoritative text"
                vStatus = VerificationStatus.PARTIALLY_VERIFIED
            } else if (domainLower.contains("ramakrishna") || domainLower.contains("iskcon") || domainLower.contains("chinmaya") || domainLower.contains("chabad")) {
                relevance = 80
                sType = "Trusted religious source"
                vStatus = VerificationStatus.PARTIALLY_VERIFIED
            } else if (domainLower.contains(".edu") || domainLower.contains("university") || domainLower.contains("scholar") || domainLower.contains("oxford") || domainLower.contains("cambridge")) {
                relevance = 75
                sType = "Academic / educational source"
                vStatus = VerificationStatus.PARTIALLY_VERIFIED
            } else if (domainLower.contains("wikipedia.org") || domainLower.contains("britannica")) {
                relevance = 60
                sType = "Established reference"
                vStatus = VerificationStatus.NOT_VERIFIED
            }
            
            sourceMetadataList.add(
                SourceMetadata(
                    title = it.title,
                    domain = it.domain,
                    sourceType = sType,
                    reference = it.link,
                    summary = it.snippet.take(100) + "...",
                    relevanceScore = relevance,
                    verificationStatus = vStatus
                )
            )
            
            if (vStatus == VerificationStatus.PARTIALLY_VERIFIED) hasPartiallyVerified = true
            else if (vStatus == VerificationStatus.NOT_VERIFIED) hasNotVerified = true
        }
        
        // Sort by relevance score
        sourceMetadataList.sortByDescending { it.relevanceScore }
        
        val overallStatus = when {
            hasVerified && !hasNotVerified -> VerificationStatus.VERIFIED
            hasVerified && hasNotVerified -> VerificationStatus.PARTIALLY_VERIFIED
            hasPartiallyVerified -> VerificationStatus.PARTIALLY_VERIFIED
            sourceMetadataList.isEmpty() -> VerificationStatus.NOT_VERIFIED
            else -> VerificationStatus.NOT_VERIFIED
        }
        
        onProgress("🧠 উত্তর তৈরি করছি...")
        
        
        var finalAnswerText = ""
        try {
            finalAnswerText = generateFinalAnswer(question, chatHistory, localResults, webResults, youtubeResults, isDeepResearch, needsExternalResearch, analysis.needsYouTube)
                } catch (e: Exception) {
            if (localResults.isNotEmpty()) {
                finalAnswerText = "⚠️ Network Error / Offline Mode: ইন্টারনেট সংযোগ না থাকায় AI বিশ্লেষণ সম্ভব হচ্ছে না। নিচে Local Knowledge Base থেকে প্রাপ্ত সরাসরি তথ্য দেওয়া হলো:\n\n" + localResults.joinToString("\n\n") { "📌 " + it.title + "\n" + it.content }
            } else {
                throw e
            }
        }
        val finalAnswer = finalAnswerText

        return ResearchResult(
            answer = finalAnswer, 
            webSources = webResults, 
            youtubeSources = youtubeResults, 
            localSources = localResults.take(3),
            verificationStatus = overallStatus,
            sourceMetadata = sourceMetadataList
        )
    }
    
    private suspend fun generateFinalAnswer(
        question: String,
        chatHistory: List<Content>,
        localResults: List<KnowledgeEntity>,
        webResults: List<WebResult>,
        youtubeResults: List<YouTubeResult>,
        isDeepResearch: Boolean,
        needsExternalResearch: Boolean,
        attemptedYouTubeSearch: Boolean
    ): String {
        val todayDate = SimpleDateFormat("dd MMMM yyyy", Locale("bn", "BD")).format(Date())
        
        val systemInstruction = buildString {
            append("You are Dharma AI, a Research-Based Hindu Dharma AI Assistant. Answer purely in Bengali. Current Date: $todayDate.\n")
                        append("CRITICAL RULES:\n")
            append("1. Never invent scripture references, chapter, verse, shlokas, mantras, sanskrit text, or source. If not in DB or external search, explicitly state it.\n")
            append("2. Maintain tradition awareness (Vaishnava, Shaiva, Shakta, Smarta, Vedanta, Yoga). Do not present one interpretation as the universal Hindu belief. If sources disagree, state: 'এই বিষয়ে বিভিন্ন tradition-এ ভিন্ন ব্যাখ্যা রয়েছে।'\n")
            append("3. Do NOT claim you searched Google or YouTube if webResults or youtubeResults are empty.\n")
            append("4. Use ONLY the provided Local Knowledge Database context to answer if no web results are provided.\n")
            
            append("5. If a Mantra is asked, format exactly as:\n🕉️ মন্ত্র\n📖 শাস্ত্রীয় উৎস\n📍 Reference\n🔤 উচ্চারণ / Transliteration\n📝 সহজ বাংলা অর্থ\n💡 Traditional Context\n🔎 Verification\n📚 Source\nIf unverified, clearly state 'Not Verified'.\n")
            append("6. If a Shloka is asked, format exactly as:\n📖 শাস্ত্র\n📍 Chapter / Verse\n🕉️ শ্লোক\n🔤 Transliteration\n📝 বাংলা অর্থ\n💡 ব্যাখ্যা\n🔎 Verification\n📚 Source\nIf unverified, DO NOT guess the chapter/verse. State 'এই reference নির্ভরযোগ্যভাবে যাচাই করা যায়নি।'\n")
            append("6a. For Bhagavad Gita related questions, use this specific format when appropriate:\n📖 Bhagavad Gita\n📍 Chapter / Verse\n🕉️ শ্লোক\n🔤 Transliteration\n📝 বাংলা অর্থ\n💡 সহজ ব্যাখ্যা\n🔎 Verification\n📚 Source\nDo NOT invent unverified fields.\n")
            append("7. Transliteration এবং pronunciation একই জিনিস ধরে নেবে না। যদি নির্ভরযোগ্য pronunciation data না থাকে: 'উচ্চারণের তথ্য যাচাই করা হয়নি।' দেখাতে পারবে। নিজে থেকে Sanskrit pronunciation তৈরি করবে না।\n")
            append("8. YouTube videos are educational resources; their scriptural authenticity must be verified separately. If referencing a video, mention: 'এই ভিডিওটি একটি reference resource; এর বক্তব্যের শাস্ত্রীয় সত্যতা আলাদাভাবে যাচাই করা হয়েছে/হয়নি।'\n")

            if (needsExternalResearch && webResults.isEmpty() && youtubeResults.isEmpty()) {
                append("\nIMPORTANT FALLBACK INSTRUCTION: External search is currently unavailable. You MUST include this EXACT sentence in your response (either at the start or end): 'বর্তমানে external web research unavailable; verified Dharma Knowledge Base থেকে উত্তর দেওয়া হচ্ছে।'\n")
            }
            
            if (localResults.isEmpty()) {
                append("\nNo exact matching records found in the Local Knowledge Base. Answer respectfully from your general verified Hindu Dharma knowledge, but explicitly mention: 'এই তথ্যের নির্দিষ্ট শাস্ত্রীয় reference Knowledge Base-এ পাওয়া যায়নি।'\n")
            } else {
                append("\n--- Local Dharma Knowledge Base Context ---\n")
                                localResults.take(5).forEach { k -> 
                    append("Title: ${k.title}\n" +
                           "Category: ${k.category}\n" +
                           "Scripture: ${k.scripture}\n" +
                           "Reference: ${k.reference}\n" +
                           "Sanskrit Text: ${k.sanskritText}\n" +
                           "Transliteration: ${k.transliteration}\n" +
                           "Bangla Meaning: ${k.banglaMeaning}\n" +
                           "Content: ${k.content}\n" +
                           "Explanation: ${k.explanation}\n" +
                           "Source: ${k.source}\n" +
                           "Verified Status: ${k.verifiedStatus}\n---\n")
                }
            }
            
            if (webResults.isNotEmpty()) {
                append("\n--- Web Search Results ---\n")
                webResults.forEach { w -> append("- ${w.domain}: ${w.title} (${w.snippet})\n") }
            }

            if (attemptedYouTubeSearch && youtubeResults.isEmpty()) {
                append("\nIf the user specifically asked for a video and YouTube results are empty, you MUST state: 'বর্তমানে YouTube research unavailable।' and answer using other available knowledge.\n")
            }
            if (youtubeResults.isNotEmpty()) {
                append("\n--- YouTube Search Results ---\n")
                youtubeResults.forEach { y -> append("- Channel: ${y.channelTitle}, Title: ${y.title} (${y.description})\n") }
            }

        }
        
        val historyWithQuestion = chatHistory.toMutableList()
        historyWithQuestion.add(Content(role = "user", parts = listOf(Part(text = question))))
        return aiProvider.generateResponse(historyWithQuestion, systemInstruction)
    }
}
