package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface KnowledgeDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(knowledgeList: List<KnowledgeEntity>)

            @Query("""
        SELECT * FROM knowledge 
        WHERE title LIKE '%' || :query || '%' 
        OR content LIKE '%' || :query || '%'
        OR explanation LIKE '%' || :query || '%'
        OR tags LIKE '%' || :query || '%'
        OR scripture LIKE '%' || :query || '%'
        OR category LIKE '%' || :query || '%'
        OR subcategory LIKE '%' || :query || '%'
        OR sanskritText LIKE '%' || :query || '%'
        OR transliteration LIKE '%' || :query || '%'
        OR banglaMeaning LIKE '%' || :query || '%'
        OR chapter LIKE '%' || :query || '%'
        OR verse LIKE '%' || :query || '%'
    """)
    suspend fun searchKnowledge(query: String): List<KnowledgeEntity>
    
    @Query("SELECT COUNT(*) FROM knowledge")
    suspend fun getKnowledgeCount(): Int

    @Query("DELETE FROM knowledge")
    suspend fun clearAll()
}
