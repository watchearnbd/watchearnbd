import os

path = 'app/src/main/java/com/example/ai/AdvancedDecisionEngine.kt'
with open(path, 'r') as f:
    text = f.read()

target = """        // --- 9. RESPONSE GENERATION (RULE-BASED NLG) ---
        onProgress("Internal Brain: Formatting Final Answer...")
        val primaryResult = results.first()
        val sb = java.lang.StringBuilder()"""

replacement = """        // --- 9. RESPONSE GENERATION (RULE-BASED NLG) ---
        onProgress("Internal Brain: Formatting Final Answer...")
        val primaryResult = results.first()
        
        contextState.lastKnowledgeEntryId = primaryResult.id
        contextState.conversationTopic = primaryResult.title.split("(").first().trim()
        contextState.currentDeity = primaryResult.deity
        
        val sb = java.lang.StringBuilder()"""

text = text.replace(target, replacement)

with open(path, 'w') as f:
    f.write(text)
print("ADE V2 patched part 2")
