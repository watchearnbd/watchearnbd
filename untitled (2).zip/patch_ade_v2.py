import os

path = 'app/src/main/java/com/example/ai/AdvancedDecisionEngine.kt'
with open(path, 'r') as f:
    text = f.read()

# Replace Context Awareness logic
target_start = "        // --- 5. CONTEXT AWARENESS & COREFERENCE RESOLUTION ---"
target_end = "        // --- 6. CLARIFICATION RULE ---"

start_idx = text.find(target_start)
end_idx = text.find(target_end)

if start_idx != -1 and end_idx != -1:
    new_logic = """        // --- 5. CONTEXT AWARENESS & COREFERENCE RESOLUTION ---
        var effectiveQuery = rawMessage
        var isFollowUp = false
        
        val followUpKeywords = listOf("এটা", "ওটা", "এর", "কেন", "আরও", "বিস্তারিত", "মানে", "অর্থ", "বুঝলাম না", "তার", "সেটার", "উদাহরণ", "তারপর", "তারপরে", "ওইটার", "এটার", "আগেরটা", "আগের", "ওই", "এই", "সেই", "উৎস", "কোথায়")
        
        val hasPronoun = followUpKeywords.any { lowerMessage.contains(it) }
        
        if (hasPronoun && contextState.lastKnowledgeEntryId != null) {
            val lastEntity = localKnowledgeProvider.getById(contextState.lastKnowledgeEntryId!!)
            if (lastEntity != null) {
                val isMeaningQuery = listOf("মানে", "অর্থ", "বলতে কী", "কি বোঝায়", "এর মানে", "এটার অর্থ").any { lowerMessage.contains(it) }
                val isSourceQuery = listOf("উৎস", "কোথায়", "শাস্ত্র", "source").any { lowerMessage.contains(it) }
                
                if (isMeaningQuery && (lastEntity.banglaMeaning.isNotBlank() || lastEntity.explanation.isNotBlank())) {
                    val meaning = if (lastEntity.banglaMeaning.isNotBlank()) lastEntity.banglaMeaning else lastEntity.explanation
                    return@withContext buildUnverifiedResponse("${lastEntity.title.split("(").first().trim()}-এর অর্থ:\n$meaning")
                } else if (isSourceQuery && lastEntity.scripture.isNotBlank()) {
                    val sourceStr = "${lastEntity.scripture} ${if (lastEntity.reference.isNotBlank()) "(${lastEntity.reference})" else ""}"
                    return@withContext buildUnverifiedResponse("${lastEntity.title.split("(").first().trim()} পাওয়া যায়:\n$sourceStr")
                }
            }
        }
        
        if (hasPronoun && contextState.conversationTopic.isNotBlank()) {
            effectiveQuery = effectiveQuery.replace(Regex("(ওইটার|এটার|তার|এর|সেটার|আগেরটা|আগের|ওই|এই|সেই)"), contextState.conversationTopic)
        }
        val isAskingForNames = listOf("নামগুলো", "নামগুলি").any { lowerMessage.contains(it) }
        if (isAskingForNames && contextState.conversationTopic.isNotBlank()) {
             effectiveQuery = contextState.conversationTopic + " নাম"
        }
        
        val isShortQuery = rawMessage.length <= 15

        if (followUpKeywords.any { lowerMessage.contains(it) } || isShortQuery) {
            val isPrevGeneric = isGreeting(lastUserMsg.lowercase()) || isHowAreYou(lastUserMsg.lowercase()) || isWhatDoYouDo(lastUserMsg.lowercase()) || isAcknowledgment(lastUserMsg.lowercase()) || isAgreement(lastUserMsg.lowercase())
            
            if (lastUserMsg.isNotBlank() && !lastUserMsg.equals(rawMessage, ignoreCase = true) && !isPrevGeneric) {
                isFollowUp = true
                effectiveQuery = "$lastUserMsg $rawMessage"
            }
        }

"""
    text = text[:start_idx] + new_logic + text[end_idx:]

with open(path, 'w') as f:
    f.write(text)
print("ADE V2 patched part 1")
