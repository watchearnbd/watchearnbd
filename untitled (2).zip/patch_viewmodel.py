import os
path = 'app/src/main/java/com/example/ui/chat/ChatViewModel.kt'

with open(path, 'r') as f:
    text = f.read()

target = """    private var currentSessionTitle: String = "নতুন আলোচনা"
    private var sessionCreatedDate: Long = 0L"""

replacement = """    private var currentSessionTitle: String = "নতুন আলোচনা"
    private var sessionCreatedDate: Long = 0L
    
    val conversationContext = com.example.ai.ConversationContext()"""

target2 = """                val responseMsg = decisionEngine.processPipeline(question, _messages.value.dropLast(1), _isDeepResearch.value) { progressMsg ->"""

replacement2 = """                val responseMsg = decisionEngine.processPipeline(question, _messages.value.dropLast(1), _isDeepResearch.value, conversationContext) { progressMsg ->"""

target3 = """    fun startNewChat() {
        currentSessionId = null
        currentSessionTitle = "নতুন আলোচনা"
        _messages.value = emptyList()
        _uiState.value = ChatUiState.Idle
        lastQuestion = null"""

replacement3 = """    fun startNewChat() {
        currentSessionId = null
        currentSessionTitle = "নতুন আলোচনা"
        _messages.value = emptyList()
        _uiState.value = ChatUiState.Idle
        lastQuestion = null
        conversationContext.resetClarification()"""

if target in text and target2 in text and target3 in text:
    text = text.replace(target, replacement).replace(target2, replacement2).replace(target3, replacement3)
    with open(path, 'w') as f:
        f.write(text)
    print("ChatViewModel updated")
else:
    print("Target not found in ChatViewModel")
