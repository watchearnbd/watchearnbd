import os, re
path = 'app/src/main/java/com/example/ai/SmartKnowledgeMatcher.kt'

with open(path, 'r') as f:
    text = f.read()

target = """data class MatchResult(
    val entity: KnowledgeEntity?,
    val confidence: MatchConfidence,
    val requiresClarification: Boolean = false,
    val clarificationMessage: String = ""
)"""

replacement = """data class MatchResult(
    val entity: KnowledgeEntity?,
    val confidence: MatchConfidence,
    val requiresClarification: Boolean = false,
    val clarificationMessage: String = "",
    val options: List<com.example.data.KnowledgeEntity> = emptyList()
)"""

text = text.replace(target, replacement)

target2 = """        if (highMatches.size > 1 && bestScore < 1.0) {
            val options = highMatches.keys.take(2).joinToString(" না ")
            return MatchResult(bestMatch, MatchConfidence.MEDIUM, true, "আপনি কি '$options' এর কথা বলছেন?")
        }
        
        return when {
            bestScore >= 0.80 -> MatchResult(bestMatch, MatchConfidence.HIGH)
            bestScore >= 0.50 -> MatchResult(bestMatch, MatchConfidence.MEDIUM, true, "আপনি কি '${bestMatch?.title}' এর কথা বলছেন?")
            else -> MatchResult(null, MatchConfidence.LOW, true, "আপনি কোন বিষয়টি বা মন্ত্রটি বোঝাচ্ছেন একটু পরিষ্কার করে বলবেন? নামটা হয়তো একটু ভিন্নভাবে লেখা হয়েছে। 😊")
        }"""

replacement2 = """        if (highMatches.size > 1 && bestScore < 1.0) {
            val opts = highMatches.values.take(2).toList()
            val titles = opts.map { it.title.split("(").first().trim() }.joinToString(" না ")
            return MatchResult(bestMatch, MatchConfidence.MEDIUM, true, "আপনি কি '$titles' এর কথা বলছেন?", opts)
        }
        
        return when {
            bestScore >= 0.80 -> MatchResult(bestMatch, MatchConfidence.HIGH)
            bestScore >= 0.50 -> MatchResult(bestMatch, MatchConfidence.MEDIUM, true, "আপনি কি '${bestMatch?.title}' এর কথা বলছেন?", listOfNotNull(bestMatch))
            else -> MatchResult(null, MatchConfidence.LOW, true, "আপনি কোন বিষয়টি বা মন্ত্রটি বোঝাচ্ছেন একটু পরিষ্কার করে বলবেন? নামটা হয়তো একটু ভিন্নভাবে লেখা হয়েছে। 😊")
        }"""

text = text.replace(target2, replacement2)
with open(path, 'w') as f:
    f.write(text)
print("SKM updated")
