import os

path = 'app/src/main/java/com/example/ai/AdvancedDecisionEngine.kt'
with open(path, 'r') as f:
    text = f.read()

target = """        // Handle pronoun resolution like "ওইটার মানে", "তার অর্থ", "নামগুলো"
        var effectiveQuery = lowerMessage
        val hasPronoun = listOf("ওইটার", "এটার", "তার", "এর", "সেটার", "আগেরটা", "আগের", "ওই").any { lowerMessage.contains(it) }
        if (hasPronoun && contextState.conversationTopic.isNotBlank()) {
            effectiveQuery = effectiveQuery.replace(Regex("(ওইটার|এটার|তার|এর|সেটার|আগেরটা|আগের|ওই)"), contextState.conversationTopic)
        }
        val isAskingForNames = listOf("নামগুলো", "নামগুলি").any { lowerMessage.contains(it) }
        if (isAskingForNames && contextState.conversationTopic.isNotBlank()) {
             effectiveQuery = contextState.conversationTopic + " নাম"
        }"""

replacement = """        // Pronouns moved down"""

text = text.replace(target, replacement)

target2 = """        // --- 5. CONTEXT AWARENESS & COREFERENCE RESOLUTION ---
        var effectiveQuery = rawMessage
        var isFollowUp = false
        
        val followUpKeywords = listOf("এটা", "ওটা", "এর", "কেন", "আরও", "বিস্তারিত", "মানে", "বুঝলাম না", "তার", "সেটার", "উদাহরণ", "তারপর", "তারপরে")"""

replacement2 = """        // --- 5. CONTEXT AWARENESS & COREFERENCE RESOLUTION ---
        var effectiveQuery = rawMessage
        var isFollowUp = false
        
        val followUpKeywords = listOf("এটা", "ওটা", "এর", "কেন", "আরও", "বিস্তারিত", "মানে", "বুঝলাম না", "তার", "সেটার", "উদাহরণ", "তারপর", "তারপরে", "ওইটার", "এটার", "আগেরটা", "আগের", "ওই")
        
        val hasPronoun = followUpKeywords.any { lowerMessage.contains(it) }
        if (hasPronoun && contextState.conversationTopic.isNotBlank()) {
            effectiveQuery = effectiveQuery.replace(Regex("(ওইটার|এটার|তার|এর|সেটার|আগেরটা|আগের|ওই)"), contextState.conversationTopic)
        }
        val isAskingForNames = listOf("নামগুলো", "নামগুলি").any { lowerMessage.contains(it) }
        if (isAskingForNames && contextState.conversationTopic.isNotBlank()) {
             effectiveQuery = contextState.conversationTopic + " নাম"
        }
        """

text = text.replace(target2, replacement2)

with open(path, 'w') as f:
    f.write(text)
print("ADE fixed")
