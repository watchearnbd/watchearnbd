package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.ui.graphics.Color
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Language
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.Alignment
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.Brush
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.getValue
import androidx.compose.animation.core.animateFloat
import androidx.compose.foundation.Canvas
import androidx.compose.ui.geometry.Offset
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.Icon
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Person
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ui.theme.*

import androidx.compose.runtime.collectAsState
import androidx.compose.ui.platform.LocalContext
import android.app.Activity

class MainActivity : ComponentActivity() {
  private lateinit var billingManager: BillingManager

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    billingManager = BillingManager(this)
    setContent {
      AlorPathTheme {
        AlorPathApp(billingManager)
      }
    }
  }
}
data class PremiumFeature(val title: String, val icon: ImageVector, val isLocked: Boolean)

val premiumFeatures = listOf(
    PremiumFeature("AI Pronunciation", Icons.Default.Build, true),
    PremiumFeature("AI Quiz", Icons.Default.Star, true),
    PremiumFeature("Writing Practice Pro", Icons.Default.Edit, true),
    PremiumFeature("100+ Games", Icons.Default.PlayArrow, true),
    PremiumFeature("500+ Quiz", Icons.Default.Star, true),
    PremiumFeature("Stories", Icons.Default.Edit, true),
    PremiumFeature("Rhymes", Icons.Default.PlayArrow, true),
    PremiumFeature("Video Lessons", Icons.Default.PlayArrow, true),
    PremiumFeature("Certificate", Icons.Default.DateRange, true),
    PremiumFeature("Offline Learning", Icons.Default.Lock, true)
)
@Composable
fun AlorPathApp(billingManager: BillingManager) {
  val navController = rememberNavController()
  val isPremium by billingManager.isPremium.collectAsState()

  val items = listOf("home", "learn", "games", "profile")
    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.8f),
                modifier = Modifier.height(80.dp)
            ) {
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentDestination = navBackStackEntry?.destination
                items.forEach { screen ->
                    NavigationBarItem(
                        icon = {
                            when (screen) {
                                "home" -> Icon(Icons.Default.Home, contentDescription = "Home")
                                "learn" -> Icon(Icons.Default.School, contentDescription = "Learn")
                                "games" -> Icon(Icons.Default.SportsEsports, contentDescription = "Games")
                                "profile" -> Icon(Icons.Default.Person, contentDescription = "Profile")
                            }
                        },
                        label = { Text(screen.replaceFirstChar { it.uppercase() }) },
                        selected = currentDestination?.hierarchy?.any { it.route == screen } == true,
                        onClick = {
                            navController.navigate(screen) {
                                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Indigo600,
                            indicatorColor = Indigo600.copy(alpha = 0.2f)
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
    NavHost(navController, startDestination = "home", modifier = Modifier.padding(innerPadding)) {
      composable("home") { HomeScreen(navController, isPremium) }
      composable("learn") { LearnScreen(isPremium) }
      composable("games") { GamesScreen(isPremium) }
      composable("profile") { ProfileScreen(billingManager, isPremium) }
      composable("premium") { PremiumScreen(billingManager, isPremium) }
    }
  }
}

@Composable
fun LearnScreen(isPremium: Boolean) {
    val subjects = listOf("বাংলা", "English", "Math", "Science", "Art", "Islamic Studies")
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("আজকে কী শিখবে?", style = MaterialTheme.typography.headlineMedium)
        Spacer(modifier = Modifier.height(16.dp))
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(subjects) { subject ->
                Card(
                    modifier = Modifier.height(120.dp),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = subject, style = MaterialTheme.typography.titleLarge)
                        LinearProgressIndicator(progress = { 0.5f }, modifier = Modifier.padding(8.dp).fillMaxWidth(0.8f))
                    }
                }
            }
        }
    }
}

@Composable
fun GamesScreen(isPremium: Boolean) {
    val games = listOf("Word Puzzle", "Number Game", "Color Match", "Memory Game")
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("মজার খেলা 🎮", style = MaterialTheme.typography.headlineMedium)
        Spacer(modifier = Modifier.height(16.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(16.dp)) {
            items(games.size) { index ->
                Card(
                    modifier = Modifier.fillMaxWidth().height(100.dp),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
                ) {
                    Row(modifier = Modifier.fillMaxSize().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(40.dp))
                        Spacer(modifier = Modifier.width(16.dp))
                        Text(text = games[index], style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                        Button(onClick = {}) { Text("খেলো") }
                    }
                }
            }
        }
    }
}

@Composable
fun ProfileScreen(billingManager: BillingManager, isPremium: Boolean) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Surface(modifier = Modifier.size(100.dp), shape = RoundedCornerShape(50.dp), color = MaterialTheme.colorScheme.primary) {}
        Spacer(modifier = Modifier.height(16.dp))
        Text("আলো", style = MaterialTheme.typography.headlineLarge)
        Spacer(modifier = Modifier.height(24.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("120", style = MaterialTheme.typography.titleLarge)
                Text("Stars", style = MaterialTheme.typography.bodySmall)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("15", style = MaterialTheme.typography.titleLarge)
                Text("Lessons", style = MaterialTheme.typography.bodySmall)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("5", style = MaterialTheme.typography.titleLarge)
                Text("Streak", style = MaterialTheme.typography.bodySmall)
            }
        }
        Spacer(modifier = Modifier.height(24.dp))
        Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp)) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Settings", style = MaterialTheme.typography.titleMedium)
                Spacer(modifier = Modifier.height(16.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Language, contentDescription = null)
                    Spacer(modifier = Modifier.width(16.dp))
                    Text("ভাষা পরিবর্তন")
                }
                Spacer(modifier = Modifier.height(16.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Notifications, contentDescription = null)
                    Spacer(modifier = Modifier.width(16.dp))
                    Text("Notification")
                }
            }
        }
    }
}


@Composable
fun PremiumScreen(billingManager: BillingManager, isPremium: Boolean) {
    val scrollState = rememberScrollState()
    val activity = LocalContext.current as Activity
    
    // In real scenario observe errors
    val errorMessage by billingManager.errorMessage.collectAsState()
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8F9FF))
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        // Banner
        Card(
            modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color.Transparent)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Brush.horizontalGradient(listOf(Gold700, Orange400, Gold500)))
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                // Sparkle animation overlay
                SparkleEffect()
                
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.WorkspacePremium, contentDescription = null, tint = Color.White, modifier = Modifier.size(64.dp))
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        "Unlock Everything with One Premium Subscription", 
                        style = MaterialTheme.typography.headlineSmall, 
                        color = Color.White, 
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }
        }
        
        Text(
            text = "Purchase one Premium subscription to unlock all Premium features in the app.",
            style = MaterialTheme.typography.bodyLarge,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        Card(
            modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(24.dp)) {
                Text(
                    text = "Your Premium Access Includes:",
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(bottom = 16.dp)
                )

                val features = listOf(
                    "Unlimited access to all lessons",
                    "All Bangla, English, and Number courses",
                    "All writing practice",
                    "All quizzes",
                    "All educational games",
                    "AI Learning Features",
                    "AI Pronunciation Check",
                    "Stories & Rhymes",
                    "Video Lessons",
                    "Progress Reports",
                    "Certificates",
                    "Offline Learning",
                    "Cloud Backup",
                    "Ad-Free Experience",
                    "All future Premium updates at no extra cost"
                )

                features.forEach { feature ->
                    Row(
                        modifier = Modifier.padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Star, contentDescription = null, tint = Gold500, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(text = feature, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
        
        Text(
            text = "One Subscription Unlocks Everything. No Hidden Charges. Lifetime updates included for Lifetime members.",
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.primary,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp)
        )

        errorMessage?.let { msg ->
            androidx.compose.material3.Snackbar(
                modifier = Modifier.padding(bottom = 16.dp),
                action = {
                    androidx.compose.material3.TextButton(onClick = { billingManager.clearError() }) {
                        Text("Dismiss")
                    }
                }
            ) {
                Text(msg)
            }
        }

        if (isPremium) {
            Card(
                modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                colors = CardDefaults.cardColors(containerColor = Emerald100),
                shape = RoundedCornerShape(24.dp)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp).fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Star, contentDescription = null, tint = Color(0xFF047857)) // Emerald 700 equivalent
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Premium Active", style = MaterialTheme.typography.titleLarge, color = Color(0xFF047857))
                }
            }
        } else {
            Button(
                onClick = { billingManager.restorePurchases() },
                modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondaryContainer, contentColor = MaterialTheme.colorScheme.onSecondaryContainer)
            ) {
                Text("Restore Purchases")
            }
        }

        // Plans
        PlanCard(
            title = "Monthly",
            price = "$4.99",
            features = listOf(),
            backgroundColor = PurplePremium,
            badge = "Premium",
            onClick = { billingManager.launchBillingFlow(activity, "premium_monthly") }
        )
        
        PlanCard(
            title = "Yearly (Most Popular)",
            price = "$39.99",
            features = listOf(),
            backgroundColor = Indigo600,
            isPopular = true,
            badge = "50% OFF",
            onClick = { billingManager.launchBillingFlow(activity, "premium_yearly") }
        )
        
        PlanCard(
            title = "Lifetime",
            price = "$99.99",
            features = listOf(),
            backgroundColor = Gold600,
            badge = "Lifetime",
            isLifetime = true,
            onClick = { billingManager.launchBillingFlow(activity, "premium_lifetime") }
        )
    }
}

@Composable
fun SparkleEffect() {
    // Simple pulse animation for sparkle
    val infiniteTransition = androidx.compose.animation.core.rememberInfiniteTransition()
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 0.8f,
        animationSpec = androidx.compose.animation.core.infiniteRepeatable(
            animation = androidx.compose.animation.core.tween(1000, easing = androidx.compose.animation.core.FastOutSlowInEasing),
            repeatMode = androidx.compose.animation.core.RepeatMode.Reverse
        )
    )
    Canvas(modifier = Modifier.fillMaxSize().graphicsLayer(alpha = alpha)) {
        // Drawing random sparkles
        drawCircle(Color.White, radius = 5f, center = androidx.compose.ui.geometry.Offset(size.width * 0.1f, size.height * 0.2f))
        drawCircle(Color.White, radius = 8f, center = androidx.compose.ui.geometry.Offset(size.width * 0.8f, size.height * 0.7f))
        drawCircle(Color.White, radius = 4f, center = androidx.compose.ui.geometry.Offset(size.width * 0.5f, size.height * 0.5f))
    }
}

@Composable
fun PlanCard(title: String, price: String, features: List<String>, backgroundColor: Color, isPopular: Boolean = false, badge: String = "", isLifetime: Boolean = false, onClick: () -> Unit = {}) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .then(if (isPopular) Modifier.border(4.dp, Color.White, RoundedCornerShape(24.dp)) else Modifier),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = if(isLifetime) Gold500 else backgroundColor),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
        Column(modifier = Modifier.padding(24.dp)) {
            if (badge.isNotEmpty()) {
                Surface(color = Color.White.copy(alpha = 0.3f), shape = RoundedCornerShape(12.dp)) {
                    Text(badge, modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp), color = Color.White, style = MaterialTheme.typography.labelLarge)
                }
            }
            Text(title, style = MaterialTheme.typography.titleLarge, color = Color.White)
            Text(price, style = MaterialTheme.typography.headlineLarge, color = Color.White, modifier = Modifier.padding(vertical = 8.dp))
            features.forEach { 
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Star, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("- $it", color = Color.White, style = MaterialTheme.typography.bodyMedium)
                }
            }
            Button(
                onClick = onClick,
                colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = backgroundColor),
                modifier = Modifier.fillMaxWidth().padding(top = 16.dp)
            ) {
                Text("Buy Now")
            }
        }
    }
}


@Composable
fun HomeScreen(navController: androidx.navigation.NavController, isPremium: Boolean) {
    Column(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        // Top Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Brush.horizontalGradient(listOf(Indigo600, Purple600)))
                .padding(16.dp)
                .statusBarsPadding(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "AlorPath", style = MaterialTheme.typography.headlineMedium, color = Color.White)
            Row {
                Icon(Icons.Default.Search, contentDescription = "Search", tint = Color.White)
                Spacer(modifier = Modifier.width(16.dp))
                Icon(
                    Icons.Default.WorkspacePremium,
                    contentDescription = "Premium",
                    tint = Color(0xFFFFD700),
                    modifier = androidx.compose.ui.Modifier.clickable { navController.navigate("premium") }
                )
            }
        }

        // Banner
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .height(180.dp),
            shape = RoundedCornerShape(40.dp)
        ) {
            Box {
                Image(
                    painter = painterResource(id = R.drawable.img_welcome_banner),
                    contentDescription = "Welcome Banner",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.linearGradient(
                                listOf(
                                    Orange400.copy(alpha = 0.8f),
                                    Pink500.copy(alpha = 0.8f),
                                    Rose500.copy(alpha = 0.8f)
                                )
                            )
                        )
                )
                Text(
                    text = "হ্যালো, আরিয়ান! 👋\nআজ নতুন কি শিখতে চাও?",
                    style = MaterialTheme.typography.headlineSmall,
                    color = Color.White,
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(24.dp)
                )
            }
        }

        // Categories
        Text(
            text = "Categories",
            style = MaterialTheme.typography.headlineSmall,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            CategoryCard("বর্ণমালা", Blue100, "Alphabet", modifier = Modifier.size(160.dp).weight(1f))
            CategoryCard("সংখ্যা", Emerald100, "Numbers", modifier = Modifier.size(160.dp).weight(1f))
        }

        // Premium Preview
        Text(
            text = "Premium Features",
            style = MaterialTheme.typography.headlineSmall,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
        )
        LazyColumn(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(premiumFeatures.size) { index ->
                FeatureItem(premiumFeatures[index], navController, isPremium)
            }
        }
    }
}

@Composable
fun FeatureItem(feature: PremiumFeature, navController: androidx.navigation.NavController, isPremium: Boolean) {
    val actuallyLocked = feature.isLocked && !isPremium
    Card(
        modifier = Modifier.fillMaxWidth().clickable { if (actuallyLocked) navController.navigate("premium") },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(feature.icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.width(16.dp))
            Text(text = feature.title, modifier = Modifier.weight(1f))
            if (actuallyLocked) Icon(Icons.Default.Lock, contentDescription = "Locked", tint = Color.Gray)
        }
    }
}

@Composable
fun CategoryCard(title: String, color: Color, subtitle: String, modifier: Modifier = Modifier) {
    var isPressed by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    val scale by androidx.compose.animation.core.animateFloatAsState(if (isPressed) 0.95f else 1f)
    
    Card(
        modifier = modifier
            .graphicsLayer(scaleX = scale, scaleY = scale)
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        isPressed = true
                        tryAwaitRelease()
                        isPressed = false
                    }
                )
            },
        shape = RoundedCornerShape(32.dp),
        colors = CardDefaults.cardColors(containerColor = color),
        border = androidx.compose.foundation.BorderStroke(2.dp, color.copy(alpha = 0.5f))
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .background(color.copy(alpha = 0.5f), RoundedCornerShape(16.dp)),
                contentAlignment = Alignment.Center
            ) {
                // Placeholder for icon
            }
            Column {
                Text(text = title, style = MaterialTheme.typography.titleLarge, color = Color(0xFF1E3A8A))
                Text(text = subtitle, style = MaterialTheme.typography.bodySmall, color = Color(0xFF3B82F6))
            }
        }
    }
}
