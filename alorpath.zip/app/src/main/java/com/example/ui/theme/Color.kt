package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

val Indigo600 = Color(0xFF4F46E5)
val Purple600 = Color(0xFF9333EA)
val Orange400 = Color(0xFFFB923C)
val Pink500 = Color(0xFFEC4899)
val Rose500 = Color(0xFFF43F5E)
val Blue100 = Color(0xFFDBEAFE)
val Emerald100 = Color(0xFFD1FAE5)
val Purple100 = Color(0xFFE9D5FF)
val Amber100 = Color(0xFFFDE68A)

val Gold500 = Color(0xFFFFD700)
val Gold600 = Color(0xFFFFC107)
val Gold700 = Color(0xFFFFB300)
val PurplePremium = Color(0xFF7E57C2)
