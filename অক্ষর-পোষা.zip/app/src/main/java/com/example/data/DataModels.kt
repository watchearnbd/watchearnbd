package com.example.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "user_progress")
data class UserProgress(
    @PrimaryKey val id: Int = 1,
    val xp: Int = 0,
    val level: Int = 1,
    val isPremium: Boolean = false,
    val currentPet: String = "🐯",
    val currentOutfit: String = "সাধারণ",
    val currentRoom: String = "সাধারণ",
    val foodCount: Int = 0,
    val happiness: Int = 80,
    val unlockedPets: String = "🐯",
    val unlockedOutfits: String = "সাধারণ",
    val unlockedRooms: String = "সাধারণ",
    val name: String = "সোনামণি",
    val age: String = "৫",
    val avatar: String = "👦",
    val streak: Int = 0,
    val lastPlayedDate: Long = 0,
    val learnedLetters: Int = 0
)

@Dao
interface UserProgressDao {
    @Query("SELECT * FROM user_progress WHERE id = 1")
    fun getProgress(): Flow<UserProgress?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProgress(progress: UserProgress)

    @Query("UPDATE user_progress SET xp = xp + :gainedXp, level = :newLevel WHERE id = 1")
    suspend fun updateXpAndLevel(gainedXp: Int, newLevel: Int)
}

@Database(entities = [UserProgress::class], version = 3, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userProgressDao(): UserProgressDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "akshor_posha_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}

class ProgressRepository(private val progressDao: UserProgressDao) {
    val progressFlow: Flow<UserProgress?> = progressDao.getProgress()

    suspend fun initializeProgress() {
        progressDao.insertProgress(UserProgress())
    }

    suspend fun updateProgress(progress: UserProgress) {
        progressDao.insertProgress(progress)
    }

    suspend fun addXp(amount: Int, currentXp: Int) {
        val newXp = currentXp + amount
        val newLevel = calculateLevel(newXp)
        progressDao.updateXpAndLevel(amount, newLevel)
    }

    private fun calculateLevel(xp: Int): Int {
        return (xp / 10) + 1
    }
}
