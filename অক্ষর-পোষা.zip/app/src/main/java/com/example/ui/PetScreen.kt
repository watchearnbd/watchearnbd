package com.example.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import java.util.Calendar

val DarkBg = Color(0xFF1A1A2E)
val CardBg = Color(0xFF16213E)
val BorderLight = Color(0xFF0F3460)
val BorderGreen = Color(0xFF4CAF50)
val BorderRed = Color(0xFFE53935)
val TextWhite = Color.White
val TextYellow = Color(0xFFFFC107)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PetScreen(viewModel: MainViewModel) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val state = uiState ?: return

    val currentHour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    val isSleeping = currentHour >= 22 || currentHour < 6

    var currentFolder by remember { mutableStateOf<String?>(null) }

    val folderTitle = when (currentFolder) {
        "my_pet" -> "আমার পেট"
        "pet_care" -> "পেটের যত্ন"
        "outfits" -> "পোশাক"
        "unlock_pet" -> "নতুন পেট আনলক"
        "pet_room" -> "পেটের ঘর"
        else -> "আমার পোষা প্রাণী"
    }

    Scaffold(
        containerColor = DarkBg,
        topBar = {
            TopAppBar(
                title = { Text(folderTitle, fontWeight = FontWeight.Bold, color = TextWhite) },
                navigationIcon = {
                    if (currentFolder != null) {
                        IconButton(onClick = { currentFolder = null }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextWhite)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DarkBg
                )
            )
        }
    ) { padding ->
        if (currentFolder == null) {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item { FolderCard("আমার পেট", "📁") { currentFolder = "my_pet" } }
                item { FolderCard("পেটের যত্ন", "📁") { currentFolder = "pet_care" } }
                item { FolderCard("পোশাক", "📁") { currentFolder = "outfits" } }
                item { FolderCard("নতুন পেট আনলক", "📁") { currentFolder = "unlock_pet" } }
                item { FolderCard("পেটের ঘর", "📁") { currentFolder = "pet_room" } }
                
                item(span = { GridItemSpan(2) }) {
                    Spacer(modifier = Modifier.height(24.dp))
                }
                item(span = { GridItemSpan(2) }) {
                    Button(
                        onClick = { viewModel.testModeUnlockAll() },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE91E63))
                    ) {
                        Text("🧪 টেস্ট মোড (সব আনলক করুন)", color = Color.White)
                    }
                }
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(padding)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(24.dp)
            ) {
                when (currentFolder) {
                    "my_pet" -> {
                        val petFace = when {
                            isSleeping -> "😴"
                            state.happiness >= 80 -> "😊"
                            state.happiness < 40 -> "😢"
                            else -> "🙂"
                        }
                        
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(2.dp, BorderLight, RoundedCornerShape(24.dp)),
                            shape = RoundedCornerShape(24.dp),
                            colors = CardDefaults.cardColors(containerColor = CardBg)
                        ) {
                            Column(
                                modifier = Modifier.padding(24.dp).fillMaxWidth(),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                val infiniteTransition = rememberInfiniteTransition()
                                val bounce by infiniteTransition.animateFloat(
                                    initialValue = 0f,
                                    targetValue = if (state.happiness >= 80 && !isSleeping) -20f else 0f,
                                    animationSpec = infiniteRepeatable(
                                        animation = tween(1000, easing = FastOutSlowInEasing),
                                        repeatMode = RepeatMode.Reverse
                                    ), label = "bounce"
                                )

                                Box(
                                    modifier = Modifier
                                        .size(150.dp)
                                        .offset(y = bounce.dp)
                                        .clip(CircleShape)
                                        .background(Color.White.copy(alpha = 0.1f))
                                        .border(2.dp, BorderLight, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(text = state.currentPet, fontSize = 80.sp)
                                }
                                Spacer(modifier = Modifier.height(16.dp))
                                Text(
                                    text = "নাম: পুটু বাঘ $petFace",
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextWhite
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "খুশি: ${state.happiness}%",
                                    fontSize = 18.sp,
                                    color = TextYellow
                                )
                                Text(
                                    text = "⭐ লেভেল: ${state.level}",
                                    fontSize = 18.sp,
                                    color = TextYellow
                                )
                                Text(
                                    text = "✨ XP: ${state.xp}",
                                    fontSize = 18.sp,
                                    color = TextYellow
                                )
                            }
                        }
                    }
                    "pet_care" -> {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            CareItem(
                                icon = "🍎",
                                title = "খাবার দাও (${state.foodCount}টি আছে)",
                                desc = "১টি অক্ষর শিখলে = ১ খাবার",
                                onClick = { viewModel.feedPet() }
                            )
                            CareItem(icon = "🛁", title = "গোসল করাও", desc = "৫টি অক্ষর শিখলে = গোসল")
                            CareItem(icon = "🎮", title = "খেলাও", desc = "দৈনিক চ্যালেঞ্জ শেষে")
                        }
                    }
                    "outfits" -> {
                        val outfitsList = listOf(
                            Pair("👕", "সাধারণ"),
                            Pair("👑", "রাজকীয় পোশাক"),
                            Pair("🚀", "মহাকাশ পোশাক"),
                            Pair("✨", "জাদুকরী পোশাক")
                        )
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            outfitsList.forEach { (emoji, outfit) ->
                                val isUnlocked = state.unlockedOutfits.contains(outfit)
                                val isSelected = state.currentOutfit == outfit
                                UnlockableItem(
                                    title = outfit,
                                    icon = emoji,
                                    isUnlocked = isUnlocked,
                                    isSelected = isSelected,
                                    isPremium = outfit != "সাধারণ",
                                    onClick = { if (isUnlocked) viewModel.setOutfit(outfit) }
                                )
                            }
                        }
                    }
                    "unlock_pet" -> {
                        val petsList = listOf(
                            Triple("🐯", "বাঘ", "ফ্রি"),
                            Triple("🐶", "কুকুর", "লেভেল ৫ লাগবে"),
                            Triple("🐱", "বিড়াল", "প্রিমিয়াম"),
                            Triple("🐼", "পান্ডা", "প্রিমিয়াম"),
                            Triple("🦊", "শেয়াল", "প্রিমিয়াম")
                        )
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            petsList.forEach { (emoji, name, requirement) ->
                                val isUnlocked = state.unlockedPets.contains(emoji)
                                val isSelected = state.currentPet == emoji
                                UnlockableItem(
                                    title = name,
                                    icon = emoji,
                                    isUnlocked = isUnlocked,
                                    isSelected = isSelected,
                                    isPremium = requirement.contains("প্রিমিয়াম"),
                                    subtitle = requirement,
                                    onClick = { if (isUnlocked) viewModel.setPet(emoji) }
                                )
                            }
                        }
                    }
                    "pet_room" -> {
                        val roomsList = listOf(
                            Pair("🏠", "সাধারণ"),
                            Pair("🌳", "বাগান ঘর"),
                            Pair("🏰", "মহলের ঘর")
                        )
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            roomsList.forEach { (emoji, room) ->
                                val isUnlocked = state.unlockedRooms.contains(room)
                                val isSelected = state.currentRoom == room
                                UnlockableItem(
                                    title = room,
                                    icon = emoji,
                                    isUnlocked = isUnlocked,
                                    isSelected = isSelected,
                                    isPremium = room != "সাধারণ",
                                    onClick = { if (isUnlocked) viewModel.setRoom(room) }
                                )
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(40.dp))
            }
        }
    }
}

@Composable
fun FolderCard(title: String, icon: String, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(1f)
            .clickable { onClick() }
            .border(2.dp, BorderLight, RoundedCornerShape(24.dp)),
        colors = CardDefaults.cardColors(containerColor = CardBg),
        shape = RoundedCornerShape(24.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(icon, fontSize = 64.sp)
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = title,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                textAlign = TextAlign.Center,
                color = TextWhite
            )
        }
    }
}

@Composable
fun CareItem(icon: String, title: String, desc: String, onClick: (() -> Unit)? = null) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
            .border(2.dp, BorderLight, RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = CardBg),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(icon, fontSize = 32.sp)
            Spacer(modifier = Modifier.width(16.dp))
            Column {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = TextWhite)
                Text(desc, fontSize = 14.sp, color = TextYellow)
            }
        }
    }
}

@Composable
fun UnlockableItem(
    title: String,
    icon: String,
    isUnlocked: Boolean,
    isSelected: Boolean,
    isPremium: Boolean,
    subtitle: String? = null,
    onClick: () -> Unit
) {
    val borderColor = if (isSelected) BorderGreen else if (!isUnlocked) BorderRed else BorderLight
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = isUnlocked) { onClick() }
            .border(2.dp, borderColor, RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = CardBg),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(icon, fontSize = 32.sp)
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text(
                        text = title,
                        fontWeight = FontWeight.Bold,
                        color = if (isUnlocked) TextWhite else Color.Gray,
                        fontSize = 18.sp
                    )
                    if (subtitle != null) {
                        Text(subtitle, fontSize = 14.sp, color = if (isPremium) TextYellow else Color.Gray)
                    } else if (isPremium && !isUnlocked) {
                        Text("প্রিমিয়াম", fontSize = 14.sp, color = TextYellow)
                    }
                }
            }
            if (isSelected) {
                Text("✅", fontSize = 24.sp)
            } else if (!isUnlocked) {
                Text("🔒", fontSize = 24.sp)
            }
        }
    }
}
