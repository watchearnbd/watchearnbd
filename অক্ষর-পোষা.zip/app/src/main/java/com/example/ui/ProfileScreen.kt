package com.example.ui

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(viewModel: MainViewModel) {
    val context = LocalContext.current
    val prefs = context.getSharedPreferences("profile_prefs", Context.MODE_PRIVATE)
    
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val state = uiState ?: return
    
    var soundEnabled by remember { mutableStateOf(prefs.getBoolean("sound_enabled", true)) }
    var notifEnabled by remember { mutableStateOf(prefs.getBoolean("notif_enabled", true)) }
    
    var showEditProfile by remember { mutableStateOf(false) }
    var showResetDialog by remember { mutableStateOf(false) }
    
    // Edit dialog states
    var editName by remember { mutableStateOf(state.name) }
    var editAge by remember { mutableStateOf(state.age) }
    var editAvatar by remember { mutableStateOf(state.avatar) }
    
    // Badge Dialog state
    var selectedBadge by remember { mutableStateOf<Pair<String, String>?>(null) }

    val saveSettings = {
        prefs.edit()
            .putBoolean("sound_enabled", soundEnabled)
            .putBoolean("notif_enabled", notifEnabled)
            .apply()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("প্রোফাইল", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            // SECTION 1: শিশুর প্রোফাইল
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp).fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(100.dp)
                            .clip(CircleShape)
                            .background(Color.White)
                            .clickable {
                                editName = state.name
                                editAge = state.age
                                editAvatar = state.avatar
                                showEditProfile = true
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = state.avatar, fontSize = 60.sp)
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = state.name,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Text(
                        text = "বয়স: ${state.age} বছর",
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedButton(
                        onClick = {
                            editName = state.name
                            editAge = state.age
                            editAvatar = state.avatar
                            showEditProfile = true
                        },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("প্রোফাইল এডিট করুন")
                    }
                }
            }

            // SECTION 2: আমার অগ্রগতি
            Text("আমার অগ্রগতি", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                StatCard(modifier = Modifier.weight(1f), icon = "⭐", value = "${state.xp}", label = "XP")
                StatCard(modifier = Modifier.weight(1f), icon = "🏆", value = "${state.level}", label = "লেভেল")
                StatCard(modifier = Modifier.weight(1f), icon = "🔥", value = "${state.streak}", label = "স্ট্রিক")
            }

            // SECTION 3: অর্জিত ব্যাজ
            Text("অর্জিত ব্যাজ", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    val hasFirstLesson = state.learnedLetters >= 1
                    val hasTenLetters = state.learnedLetters >= 10
                    val hasHurricane = state.streak >= 3
                    
                    BadgeItem(
                        icon = "🌟",
                        title = "প্রথম পাঠ",
                        earned = hasFirstLesson,
                        onClick = { selectedBadge = "প্রথম পাঠ" to if (hasFirstLesson) "আপনি প্রথম অক্ষরটি শিখেছেন!" else "১টি অক্ষর শিখলে এই ব্যাজটি পাবেন।" }
                    )
                    BadgeItem(
                        icon = "🎯",
                        title = "১০টি অক্ষর",
                        earned = hasTenLetters,
                        onClick = { selectedBadge = "১০টি অক্ষর" to if (hasTenLetters) "আপনি ১০টি অক্ষর শিখেছেন!" else "১০টি অক্ষর শিখলে এই ব্যাজটি পাবেন।" }
                    )
                    BadgeItem(
                        icon = "🌪️",
                        title = "হারিকেন",
                        earned = hasHurricane,
                        onClick = { selectedBadge = "হারিকেন" to if (hasHurricane) "আপনি টানা ৩ দিন পড়েছেন!" else "টানা ৩ দিন পড়লে এই ব্যাজটি পাবেন।" }
                    )
                    BadgeItem(
                        icon = "👑",
                        title = "মাস্টার",
                        earned = false,
                        onClick = { selectedBadge = "মাস্টার" to "লেভেল ২০ এ পৌঁছালে এই ব্যাজটি পাবেন।" }
                    )
                }
            }

            // SECTION 4: সেটিংস
            Text("সেটিংস", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column {
                    ListItem(
                        headlineContent = { Text("শব্দ (Sound)") },
                        leadingContent = { Icon(Icons.Default.VolumeUp, contentDescription = null) },
                        trailingContent = {
                            Switch(
                                checked = soundEnabled,
                                onCheckedChange = { soundEnabled = it; saveSettings() }
                            )
                        }
                    )
                    HorizontalDivider()
                    ListItem(
                        headlineContent = { Text("নোটিফিকেশন") },
                        leadingContent = { Icon(Icons.Default.Notifications, contentDescription = null) },
                        trailingContent = {
                            Switch(
                                checked = notifEnabled,
                                onCheckedChange = { notifEnabled = it; saveSettings() }
                            )
                        }
                    )
                    HorizontalDivider()
                    ListItem(
                        modifier = Modifier.clickable { showResetDialog = true },
                        headlineContent = { Text("অগ্রগতি মুছুন", color = MaterialTheme.colorScheme.error) },
                        leadingContent = { Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) }
                    )
                }
            }

            // SECTION 5: প্ল্যান
            Text("প্ল্যান", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = if (state.isPremium) MaterialTheme.colorScheme.tertiaryContainer else MaterialTheme.colorScheme.secondaryContainer)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp).fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = if (state.isPremium) "প্রিমিয়াম সদস্য" else "ফ্রি সদস্য",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        Text(
                            text = if (state.isPremium) "সব ফিচার আনলক করা আছে" else "আরো ফিচার পেতে আপগ্রেড করুন",
                            fontSize = 14.sp
                        )
                    }
                    if (!state.isPremium) {
                        Button(onClick = { /* Navigate to Premium */ }) {
                            Text("প্রিমিয়াম নিন")
                        }
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(40.dp))
        }
    }

    // Badge Details Dialog
    if (selectedBadge != null) {
        AlertDialog(
            onDismissRequest = { selectedBadge = null },
            title = { Text(selectedBadge!!.first, fontWeight = FontWeight.Bold) },
            text = { Text(selectedBadge!!.second, fontSize = 16.sp) },
            confirmButton = {
                TextButton(onClick = { selectedBadge = null }) {
                    Text("ঠিক আছে")
                }
            }
        )
    }

    // Edit Profile Dialog
    if (showEditProfile) {
        AlertDialog(
            onDismissRequest = { showEditProfile = false },
            title = { Text("প্রোফাইল আপডেট") },
            text = {
                Column {
                    Text("অবতার নির্বাচন করুন:", fontWeight = FontWeight.Medium)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        val avatars = listOf("👦", "👧", "🐯", "🐱", "🐼", "🐸")
                        avatars.forEach { a ->
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(if (editAvatar == a) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
                                    .clickable { editAvatar = a },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(a, fontSize = 24.sp)
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    OutlinedTextField(
                        value = editName,
                        onValueChange = { editName = it },
                        label = { Text("নাম") },
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = editAge,
                        onValueChange = { editAge = it },
                        label = { Text("বয়স") },
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.updateProfile(editName, editAge, editAvatar)
                        showEditProfile = false
                    }
                ) {
                    Text("সেভ করুন")
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditProfile = false }) {
                    Text("বাতিল")
                }
            }
        )
    }

    // Reset Progress Dialog
    if (showResetDialog) {
        AlertDialog(
            onDismissRequest = { showResetDialog = false },
            icon = { Icon(Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
            title = { Text("সতর্কতা") },
            text = { Text("আপনি কি নিশ্চিত যে আপনি সমস্ত অগ্রগতি মুছে ফেলতে চান? এটি আর ফিরে পাওয়া যাবে না।") },
            confirmButton = {
                Button(
                    onClick = {
                        showResetDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("হ্যাঁ, মুছুন")
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetDialog = false }) {
                    Text("না")
                }
            }
        )
    }
}

@Composable
fun StatCard(modifier: Modifier = Modifier, icon: String, value: String, label: String) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            modifier = Modifier.padding(16.dp).fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = icon, fontSize = 24.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = value, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(text = label, fontSize = 14.sp)
        }
    }
}

@Composable
fun BadgeItem(icon: String, title: String, earned: Boolean, onClick: () -> Unit) {
    Column(
        modifier = Modifier.clickable { onClick() },
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(60.dp)
                .clip(CircleShape)
                .background(if (earned) MaterialTheme.colorScheme.primaryContainer else Color.LightGray.copy(alpha = 0.5f)),
            contentAlignment = Alignment.Center
        ) {
            if (earned) {
                Text(text = icon, fontSize = 32.sp)
            } else {
                Text(text = "🔒", fontSize = 24.sp)
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = title,
            fontSize = 12.sp,
            color = if (earned) MaterialTheme.colorScheme.onSurface else Color.Gray,
            textAlign = TextAlign.Center
        )
    }
}
