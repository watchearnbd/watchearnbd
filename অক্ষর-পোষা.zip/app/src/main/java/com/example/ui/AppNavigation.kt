package com.example.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.VideogameAsset
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController

@Composable
fun AppNavigation(viewModel: MainViewModel) {
    val navController = rememberNavController()
    
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    Scaffold(
        bottomBar = {
            if (currentRoute in listOf("home", "learning_tab", "pet", "premium", "profile")) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.background,
                ) {
                    NavigationBarItem(
                        icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                        label = { Text("হোম") },
                        selected = currentRoute == "home",
                        onClick = { navController.navigate("home") { popUpTo(navController.graph.startDestinationId) } }
                    )
                    NavigationBarItem(
                        icon = { Icon(Icons.Default.MenuBook, contentDescription = "Learning") },
                        label = { Text("শেখা") },
                        selected = currentRoute == "learning_tab",
                        onClick = { navController.navigate("learning_tab") { popUpTo(navController.graph.startDestinationId) } }
                    )
                    NavigationBarItem(
                        icon = { Icon(Icons.Default.VideogameAsset, contentDescription = "Pet") },
                        label = { Text("পোষা প্রাণী") },
                        selected = currentRoute == "pet",
                        onClick = { navController.navigate("pet") { popUpTo(navController.graph.startDestinationId) } }
                    )
                    NavigationBarItem(
                        icon = { Icon(Icons.Default.Star, contentDescription = "Premium") },
                        label = { Text("প্রিমিয়াম") },
                        selected = currentRoute == "premium",
                        onClick = { navController.navigate("premium") { popUpTo(navController.graph.startDestinationId) } }
                    )
                    NavigationBarItem(
                        icon = { Icon(Icons.Default.Person, contentDescription = "Profile") },
                        label = { Text("প্রোফাইল") },
                        selected = currentRoute == "profile",
                        onClick = { navController.navigate("profile") { popUpTo(navController.graph.startDestinationId) } }
                    )
                }
            }
        }
    ) { paddingValues ->
        NavHost(navController = navController, startDestination = "home", modifier = Modifier.padding(paddingValues)) {
            composable("home") {
                HomeScreen(
                    viewModel = viewModel,
                    onNavigateToCategory = { categoryId ->
                        navController.navigate("category/$categoryId")
                    },
                    onNavigateToPremium = { navController.navigate("premium") }
                )
            }
            composable("learning_tab") {
                QuizScreen(viewModel = viewModel)
            }
            composable("pet") {
                PetScreen(viewModel = viewModel)
            }
            composable("profile") {
                ProfileScreen(viewModel = viewModel)
            }
            composable("learning/{letter}") { backStackEntry ->
                val letter = backStackEntry.arguments?.getString("letter") ?: "অ"
                LearningScreen(
                    letter = letter,
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }
            composable("premium") {
                PremiumScreen(
                    onNavigateBack = { navController.popBackStack() }
                )
            }
            composable("category/{categoryId}") { backStackEntry ->
                val categoryId = backStackEntry.arguments?.getString("categoryId") ?: "vowels"
                CategoryDetailScreen(
                    categoryId = categoryId,
                    onNavigateBack = { navController.popBackStack() },
                    onNavigateToPractice = { letter -> navController.navigate("learning/$letter") }
                )
            }
        }
    }
}

@Composable
fun PlaceholderScreen(title: String) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(title, style = MaterialTheme.typography.headlineMedium)
    }
}
