package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuizScreen(viewModel: MainViewModel) {
    var selectedCategory by remember { mutableStateOf<String?>(null) }
    var selectedFolder by remember { mutableStateOf<String?>(null) }

    val categories = listOf(
        Pair("🔤", "বাংলা বর্ণ"),
        Pair("🔢", "সংখ্যা"),
        Pair("🔡", "ইংরেজি বর্ণ"),
        Pair("🐾", "প্রাণী"),
        Pair("🌿", "রঙ শিখি"),
        Pair("🎨", "ফল-সবজি")
    )

    val categoryGames = mapOf(
        "বাংলা বর্ণ" to listOf(
            "অক্ষর চেনো কুইজ", "অক্ষর মেলাও", "শব্দ সাজাও", "অক্ষর খোঁজো",
            "কোন অক্ষর নেই", "ছবি দেখে অক্ষর বলো", "অক্ষর শুনে বেছে নাও",
            "ভুল অক্ষর ধরো", "অক্ষর পূরণ করো", "দ্রুত অক্ষর বলো ⏱️"
        ),
        "সংখ্যা" to listOf(
            "সংখ্যা চেনো", "গণনা করো", "ছোট-বড় সংখ্যা", "যোগ করো",
            "বিয়োগ করো", "সংখ্যা মেলাও", "কোন সংখ্যা নেই", "ক্রম সাজাও",
            "সংখ্যা লুকানো", "দ্রুত গণনা ⏱️"
        ),
        "ইংরেজি বর্ণ" to listOf(
            "Letter চেনো", "Capital-Small মেলাও", "Word খোঁজো", "Letter পূরণ করো",
            "ছবি দেখে Letter বলো", "Letter শুনে বেছে নাও", "ভুল Letter ধরো",
            "Word সাজাও", "Letter Quiz", "দ্রুত Letter বলো ⏱️"
        ),
        "প্রাণী" to listOf(
            "প্রাণী চেনো", "প্রাণীর ডাক", "প্রাণী কোথায় থাকে", "প্রাণীর খাবার",
            "কোন প্রাণী নেই", "প্রাণী মেলাও", "ছবি দেখে নাম বলো",
            "প্রাণীর বাচ্চা", "জলের প্রাণী", "দ্রুত প্রাণী চেনো ⏱️"
        ),
        "রঙ শিখি" to listOf(
            "রঙ চেনো", "রঙ মেলাও", "কোন রঙ নেই", "ছবির রঙ বলো",
            "রঙ শুনে বেছে নাও", "ভুল রঙ ধরো", "রঙ পূরণ করো",
            "রঙ দিয়ে আঁকো", "রঙিন জিনিস খোঁজো", "দ্রুত রঙ বলো ⏱️"
        ),
        "ফল-সবজি" to listOf(
            "ফল চেনো", "সবজি চেনো", "ফল না সবজি?", "ফলের রঙ",
            "সবজির রঙ", "নাম মেলাও", "কোনটি আলাদা?",
            "ছবি দেখে নাম বলো", "ফল-সবজি খোঁজো", "দ্রুত চেনো ⏱️"
        )
    )

    Scaffold(
        containerColor = DarkBg,
        topBar = {
            if (selectedFolder != null) {
                TopAppBar(
                    title = { Text(selectedFolder!!, fontWeight = FontWeight.Bold, color = TextWhite) },
                    navigationIcon = {
                        IconButton(onClick = { selectedFolder = null }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextWhite)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBg)
                )
            }
        }
    ) { padding ->
        if (selectedFolder == null) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = Icons.Default.EmojiEvents,
                    contentDescription = "Trophy",
                    tint = TextYellow,
                    modifier = Modifier.size(64.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "বাংলা কুইজ গেম",
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextYellow
                )
                Text(
                    text = "একটি বিষয় বেছে নিন",
                    fontSize = 16.sp,
                    color = Color.LightGray
                )
                Spacer(modifier = Modifier.height(24.dp))

                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(categories.size) { index ->
                        val (icon, title) = categories[index]
                        val isSelected = selectedCategory == title
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .aspectRatio(1.2f)
                                .clickable {
                                    if (selectedCategory == title) {
                                        selectedFolder = title
                                    } else {
                                        selectedCategory = title
                                    }
                                }
                                .border(
                                    width = if (isSelected) 3.dp else 2.dp,
                                    color = if (isSelected) TextYellow else BorderLight,
                                    shape = RoundedCornerShape(16.dp)
                                ),
                            colors = CardDefaults.cardColors(containerColor = CardBg),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Column(
                                modifier = Modifier.fillMaxSize(),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Text(icon, fontSize = 48.sp)
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = title,
                                    color = TextWhite,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                }

                if (selectedCategory != null) {
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = { selectedFolder = selectedCategory },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = TextYellow),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Text(
                            text = "শুরু করুন →",
                            color = DarkBg,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        } else {
            val games = categoryGames[selectedFolder] ?: emptyList()
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(games) { gameName ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { /* Start game */ }
                            .border(2.dp, BorderLight, RoundedCornerShape(16.dp)),
                        colors = CardDefaults.cardColors(containerColor = CardBg),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .background(BorderLight, RoundedCornerShape(8.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.PlayArrow, contentDescription = null, tint = TextYellow)
                                }
                                Spacer(modifier = Modifier.width(16.dp))
                                Text(
                                    text = gameName,
                                    color = TextWhite,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
