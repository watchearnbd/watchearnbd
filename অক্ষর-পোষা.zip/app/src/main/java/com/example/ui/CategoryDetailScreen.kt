package com.example.ui

import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.platform.LocalContext
import android.speech.tts.TextToSpeech
import java.util.Locale
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Create
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CategoryDetailScreen(
    categoryId: String,
    onNavigateBack: () -> Unit,
    onNavigateToPractice: (String) -> Unit
) {
    val context = LocalContext.current
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }
    
    DisposableEffect(context) {
        val textToSpeech = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("bn", "BD")
            }
        }
        tts = textToSpeech
        onDispose {
            textToSpeech.stop()
            textToSpeech.shutdown()
        }
    }
    val (title, itemsList) = when (categoryId) {
        "vowels" -> "বাংলা স্বরবর্ণ" to listOf("অ", "আ", "ই", "ঈ", "উ", "ঊ", "ঋ", "এ", "ঐ", "ও", "ঔ")
        "consonants" -> "বাংলা ব্যঞ্জনবর্ণ" to listOf("ক", "খ", "গ", "ঘ", "ঙ", "চ", "ছ", "জ", "ঝ", "ঞ", "ট", "ঠ", "ড", "ঢ", "ণ", "ত", "থ", "দ", "ধ", "ন", "প", "ফ", "ব", "ভ", "ম", "য", "র", "ল", "শ", "ষ", "স", "হ", "ড়", "ঢ়", "য়", "ৎ", "ং", "ঃ", "ঁ")
        "english_cap" -> "ইংরেজি বড় হাতের অক্ষর" to ('A'..'Z').map { it.toString() }
        "english_small" -> "ইংরেজি ছোট হাতের অক্ষর" to ('a'..'z').map { it.toString() }
        "numbers" -> "সংখ্যা শিখি" to (1..100).map { convertToBengaliNumber(it) }
        else -> "শেখার বিষয়" to listOf()
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    titleContentColor = MaterialTheme.colorScheme.onBackground
                ),
                title = { Text(title, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = MaterialTheme.colorScheme.primary)
                    }
                }
            )
        }
    ) { paddingValues ->
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(vertical = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(itemsList) { itemStr ->
                LetterTile(
                    letter = itemStr,
                    onPractice = { onNavigateToPractice(itemStr) },
                    onSpeak = {
                        tts?.speak(itemStr, TextToSpeech.QUEUE_FLUSH, null, null)
                    }
                )
            }
        }
    }
}

@Composable
fun LetterTile(
    letter: String,
    onPractice: () -> Unit,
    onSpeak: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(1f),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(2.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = letter,
                        fontSize = 72.sp,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = getEmojiForLetter(letter), fontSize = 24.sp)
                }
            }
            
            // Actions Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.primaryContainer)
                    .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                IconButton(onClick = onSpeak) {
                    Icon(
                        imageVector = Icons.Default.VolumeUp,
                        contentDescription = "শুনুন",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(32.dp)
                    )
                }
                IconButton(onClick = onPractice) {
                    Icon(
                        imageVector = Icons.Default.Create,
                        contentDescription = "লিখুন",
                        tint = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.size(32.dp)
                    )
                }
            }
        }
    }
}

fun getEmojiForLetter(letter: String): String {
    return when (letter) {
        "অ" -> "🐍" // অজগর
        "আ" -> "🥭" // আম
        "ই" -> "🐁" // ইঁদুর
        "ঈ" -> "🦅" // ঈগল
        "উ" -> "🐪" // উট
        "ঊ" -> "🌅" // ঊষা
        "ঋ" -> "🐂" // ঋষভ (ষাঁড়)
        "এ" -> "1️⃣" // একতারা
        "ঐ" -> "🐘" // ঐরাবত
        "ও" -> "⚖️" // ওজন
        "ঔ" -> "💊" // ঔষধ
        "ক" -> "🐦" // কাক
        "খ" -> "🐰" // খরগোশ
        "গ" -> "🐄" // গরু
        "ঘ" -> "🐎" // ঘোড়া
        "ঙ" -> "🐸" // ব্যাঙ
        "A", "a" -> "🍎"
        "B", "b" -> "🎈"
        "C", "c" -> "🐱"
        "D", "d" -> "🐶"
        "E", "e" -> "🐘"
        "F", "f" -> "🐟"
        "G", "g" -> "🦒"
        else -> "🌟"
    }
}

fun convertToBengaliNumber(number: Int): String {
    val englishToBengaliMap = mapOf(
        '0' to '০', '1' to '১', '2' to '২', '3' to '৩', '4' to '৪',
        '5' to '৫', '6' to '৬', '7' to '৭', '8' to '৮', '9' to '৯'
    )
    return number.toString().map { englishToBengaliMap[it] ?: it }.joinToString("")
}
