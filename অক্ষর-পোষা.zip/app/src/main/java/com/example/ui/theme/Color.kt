package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val PrimaryGreen = Color(0xFF8BAA7A)
val OnPrimaryGreen = Color.White
val PrimaryContainerGreen = Color(0xFFE7F3DD)
val OnPrimaryContainerGreen = Color(0xFF3D4B32)

val SecondaryOrange = Color(0xFFFF9800)
val OnSecondaryOrange = Color.White
val SecondaryContainerOrange = Color(0xFFFFF0E0)
val OnSecondaryContainerOrange = Color(0xFFE65100)

val BackgroundCream = Color(0xFFFCF9F1)
val OnBackgroundSlate = Color(0xFF1E293B) // slate-800

val SurfaceWhite = Color(0xFFFFFFFF)
val OnSurfaceSlate = Color(0xFF1E293B)

val SurfaceVariantGray = Color(0xFFF1F0E8)
val OnSurfaceVariantSlate = Color(0xFF64748B) // slate-500

val OutlineGray = Color(0xFFE9E4D5)
