import androidx.compose.ui.graphics.PathEffect

fun test() {
    PathEffect.dashPath(floatArrayOf(1f, 1f))
}
