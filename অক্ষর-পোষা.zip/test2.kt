import androidx.compose.ui.graphics.PathEffect
fun test() { PathEffect.dashPathEffect(floatArrayOf(1f), 0f) }
