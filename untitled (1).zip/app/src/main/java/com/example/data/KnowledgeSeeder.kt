package com.example.data

object KnowledgeSeeder {
    val initialData = listOf(
        KnowledgeEntity(
            title = "গায়ত্রী মন্ত্র",
            category = "Mantra",
            scripture = "ঋগ্বেদ",
            reference = "৩.৬২.১০",
            content = "ওঁ ভূর্ভুবঃ স্বঃ তৎ সবিতুর্বরেণ্যং ভর্গো দেবস্য ধীমহি ধিয়ো য়ো নঃ প্রচোদয়াৎ।",
            explanation = "আমরা সেই পরমেশ্বরের (সূর্যদেব বা সবিতা) তেজ ধ্যান করি, যিনি আমাদের বুদ্ধিকে সঠিক পথে চালিত করেন। এটি অন্যতম পবিত্র বৈদিক মন্ত্র।",
            source = "Local Dharma Knowledge Base",
            verifiedStatus = "Verified",
            tags = "গায়ত্রী, মন্ত্র, সূর্য, বৈদিক, প্রার্থনা, Gayatri"
        ),
        KnowledgeEntity(
            title = "মহামৃত্যুঞ্জয় মন্ত্র",
            category = "Mantra",
            scripture = "ঋগ্বেদ",
            reference = "৭.৫৯.১২",
            content = "ওঁ ত্র্যম্বকং যজামহে সুগন্ধিং পুষ্টিবর্ধনম্। উর্বারুকমিব বন্ধনান্ মৃত্যোর্মুক্ষীয় মামৃতাৎ।।",
            explanation = "আমরা ত্রিনেত্র শিবের আরাধনা করি, যিনি সুগন্ধি ও পুষ্টিদাতা। শশা যেমন বোঁটা থেকে মুক্ত হয়, তেমনি তিনি যেন আমাদের মৃত্যু থেকে মুক্ত করেন এবং অমরত্ব প্রদান করেন।",
            source = "Local Dharma Knowledge Base",
            verifiedStatus = "Verified",
            tags = "মৃত্যুঞ্জয়, শিব, মন্ত্র, মহাদেব, ত্র্যম্বক, Mahamrityunjaya"
        ),
        KnowledgeEntity(
            title = "কর্মযোগ (নিষ্কাম কর্ম)",
            category = "Hindu Philosophy",
            scripture = "ভগবদ্গীতা",
            reference = "অধ্যায় ২, শ্লোক ৪৭",
            content = "কর্মণ্যেवाधिकारस्ते मा फलेषु कदाचन। मा कर्मफलहेतुर्भूर्मा ते सङ्गोऽस्त्वकर्मणि।।",
            explanation = "কর্মে তোমার অধিকার আছে, কিন্তু কর্মফলে কখনোই তোমার অধিকার নেই। তুমি নিজেকে কর্মফলের কারণ ভেবো না, আবার কর্মত্যাগেও যেন তোমার আসক্তি না হয়। এটি নিষ্কাম কর্মের মূল ভিত্তি।",
            source = "Local Dharma Knowledge Base",
            verifiedStatus = "Verified",
            tags = "কর্মযোগ, কর্ম, গীতা, নিষ্কাম কর্ম, দায়িত্ব, Karma, Bhagavad Gita"
        ),
        KnowledgeEntity(
            title = "অবতার তত্ত্ব (যদা যদা হি ধর্মস্য)",
            category = "Hindu Philosophy",
            scripture = "ভগবদ্গীতা",
            reference = "অধ্যায় ৪, শ্লোক ৭-৮",
            content = "যদা যদা হি ধর্মস্য গ্লানির্ভবতি ভারত। ... পরিত্রাণায় সাধূনাং বিনাশায় চ দুষ্কৃতাম্। ধর্মসংস্থাপনার্থায় সম্ভবামি যুগে যুগে।।",
            explanation = "যখনই ধর্মের পতন হয় এবং অধর্মের উত্থান হয়, তখন আমি নিজেকে প্রকাশ করি। সাধুদের রক্ষা, দুর্বৃত্তদের বিনাশ এবং ধর্ম সংস্থাপনের জন্য আমি যুগে যুগে অবতীর্ণ হই।",
            source = "Local Dharma Knowledge Base",
            verifiedStatus = "Verified",
            tags = "অবতার, ধর্ম, গ্লানি, শ্রীকৃষ্ণ, Avatar, Krishna"
        ),
        KnowledgeEntity(
            title = "দুর্গাপূজা (শারদীয়া নবরাত্রি)",
            category = "Festivals",
            scripture = "মার্কণ্ডেয় পুরাণ (দেবী মাহাত্ম্যম্)",
            reference = "দেবী মাহাত্ম্যম্ / চণ্ডী",
            content = "দুর্গাপূজা অশুভ শক্তির ওপর শুভ শক্তির বিজয়ের প্রতীক। মহিষাসুরকে বধ করার জন্য দেবী দুর্গার এই আরাধনা করা হয়।",
            explanation = "শরৎকালে এই পূজা হয় বলে একে শারদীয়া দুর্গাপূজাও বলা হয়। দেবী দুর্গা হলেন আদ্যাশক্তি মহামায়ার রূপ।",
            source = "Local Dharma Knowledge Base",
            verifiedStatus = "Verified",
            tags = "দুর্গা, পূজা, উৎসব, মহিষাসুর, নবরাত্রি, Durga Puja"
        ),
        KnowledgeEntity(
            title = "যোগ দর্শন",
            category = "Yoga",
            scripture = "পতঞ্জলি যোগসূত্র",
            reference = "১.২",
            content = "যোগশ্চিত্তবৃত্তিনিরোধঃ",
            explanation = "চিত্তের বা মনের বৃত্তিগুলোকে (চঞ্চলতা বা চিন্তা) নিরোধ বা নিয়ন্ত্রণ করাই হলো যোগ।",
            source = "Local Dharma Knowledge Base",
            verifiedStatus = "Verified",
            tags = "যোগ, পতঞ্জলি, চিত্ত, মন, ધ્યાન, Yoga"
        ),
        KnowledgeEntity(
            title = "তত্ত্বমসি (মহাবাক্য)",
            category = "Upanishads",
            scripture = "ছান্দোগ্য উপনিষদ",
            reference = "৬.৮.৭",
            content = "তৎ ত্বম্ অসি",
            explanation = "এর আক্ষরিক অর্থ 'তুমিই সেই'। এটি বোঝায় যে জীবাত্মা (ব্যক্তির আত্মা) এবং পরমাত্মা (ব্রহ্ম) মূলত এক এবং অভিন্ন। এটি অদ্বৈত বেদান্তের একটি অন্যতম মূলভিত্তি।",
            source = "Local Dharma Knowledge Base",
            verifiedStatus = "Verified",
            tags = "তত্ত্বমসি, উপনিষদ, বেদান্ত, অদ্বৈত, ব্রহ্ম, আত্মা, Tat Tvam Asi"
        ),
        KnowledgeEntity(
            title = "শিব পূজা",
            category = "Puja",
            scripture = "শিব পুরাণ",
            reference = "বিদ্যেশ্বর সংহিতা",
            content = "শিব পূজা হলো দেবাদিদেব মহাদেবের উপাসনা। সাধারণত শিবলিঙ্গে জল, দুধ, মধু ও বিল্বপত্র বা বেলপাতা অর্পণের মাধ্যমে এই পূজা করা হয়।",
            explanation = "শিবকে অত্যন্ত অল্পে সন্তুষ্ট দেবতা বা আশুতোষ বলা হয়। ভক্তিভরে যে কেউ তাঁর পূজা করতে পারে। মহামৃত্যুঞ্জয় মন্ত্র জপ শিব পূজার একটি প্রধান অংশ।",
            source = "Local Dharma Knowledge Base",
            verifiedStatus = "Verified",
            tags = "শিব, মহাদেব, লিঙ্গ, পূজা, বেলপাতা, Shiva"
        )
    )
}
