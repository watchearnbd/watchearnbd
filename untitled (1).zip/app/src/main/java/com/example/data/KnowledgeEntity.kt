package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "knowledge")
data class KnowledgeEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val category: String,
    val scripture: String,
    val reference: String,
    val content: String,
    val explanation: String,
    val source: String,
    val verifiedStatus: String,
    val tags: String
)
