import re

with open("app/src/main/java/com/example/research/ResearchEngine.kt", "r") as f:
    content = f.read()

content = content.replace('onProgress("🔎 প্রশ্ন বিশ্লেষণ করছি (Question Analyzer)...")', 'onProgress("🔎 প্রশ্ন বিশ্লেষণ করছি...")')
content = content.replace('onProgress("🌐 Research Required: External resources খুঁজছি...")', 'onProgress("🌐 Web sources খুঁজছি...")')
content = content.replace('onProgress("📖 Scripture reference যাচাই করছি...")', 'onProgress("📖 Reference যাচাই করছি...")\n        // Simulate comparison\n        onProgress("⚖️ Sources তুলনা করছি...")')

with open("app/src/main/java/com/example/research/ResearchEngine.kt", "w") as f:
    f.write(content)

